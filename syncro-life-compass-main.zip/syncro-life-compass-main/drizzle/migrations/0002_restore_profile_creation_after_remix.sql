create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.sincro_create_profile();

grant execute on function public.sincro_create_profile() to supabase_auth_admin, service_role;

insert into public.profiles(id, display_name)
select u.id, left(coalesce(u.raw_user_meta_data->>'display_name', u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name', ''), 100)
from auth.users u
on conflict (id) do nothing;