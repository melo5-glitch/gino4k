ALTER TABLE public.profiles
 ADD COLUMN IF NOT EXISTS salary_cents integer NOT NULL DEFAULT 0 CHECK (salary_cents BETWEEN 0 AND 100000000),
 ADD COLUMN IF NOT EXISTS extra_income_cents integer NOT NULL DEFAULT 0 CHECK (extra_income_cents BETWEEN 0 AND 100000000),
 ADD COLUMN IF NOT EXISTS pac_monthly_cents integer NOT NULL DEFAULT 0 CHECK (pac_monthly_cents BETWEEN 0 AND 100000000),
 ADD COLUMN IF NOT EXISTS pac_invested_cents integer NOT NULL DEFAULT 0 CHECK (pac_invested_cents BETWEEN 0 AND 1000000000),
 ADD COLUMN IF NOT EXISTS pac_risk text NOT NULL DEFAULT 'mid' CHECK (pac_risk IN ('low','mid','high')),
 ADD COLUMN IF NOT EXISTS height_cm integer CHECK (height_cm BETWEEN 50 AND 260),
 ADD COLUMN IF NOT EXISTS weight_dg integer CHECK (weight_dg BETWEEN 200 AND 4000),
 ADD COLUMN IF NOT EXISTS birth_year integer CHECK (birth_year BETWEEN 1900 AND 2100),
 ADD COLUMN IF NOT EXISTS diet_goal text NOT NULL DEFAULT 'keep' CHECK (diet_goal IN ('lose','keep','gain'));
CREATE INDEX IF NOT EXISTS chat_messages_user_created ON public.chat_messages(user_id, created_at);