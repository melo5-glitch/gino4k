import { describe, expect, it } from 'vitest';
import { validPhoto, ownedPhoto, aiFailure } from '@/lib/sincro/profile-rules';
describe('profile and autonomy rules', () => {
  it('accepts images up to 5 MB only', () => { expect(validPhoto({ size: 5 * 1024 * 1024, type: 'image/png' })).toBe(true); expect(validPhoto({ size: 5 * 1024 * 1024 + 1, type: 'image/png' })).toBe(false); expect(validPhoto({ size: 10, type: 'image/gif' })).toBe(false); });
  it('rejects photos outside the owner folder', () => { expect(ownedPhoto('u1/a.png', 'u1')).toBe(true); expect(ownedPhoto('u2/a.png', 'u1')).toBe(false); });
  it('pauses on credit exhaustion', () => { expect(aiFailure(402).pause).toBe(true); expect(aiFailure(429).pause).toBe(false); });
});
