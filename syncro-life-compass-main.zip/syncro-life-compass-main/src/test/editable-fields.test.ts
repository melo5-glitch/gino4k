import { describe, expect, it } from 'vitest';
import { parseMoney } from '@/components/sincro/EditDialog';
import { bmi, dailyCalories } from '@/lib/sincro/schemas';
describe('editable fields', () => {
  it('parses Italian and dotted amounts to cents', () => { expect(parseMoney('2.450,50')).toBe(245050); expect(parseMoney('150.5')).toBe(15050); expect(parseMoney('')).toBe(0); expect(parseMoney('abc')).toBeNull(); });
  it('computes BMI from height and weight', () => { expect(bmi(178, 740)).toBe(23.4); expect(bmi(null, 740)).toBeNull(); });
  it('calorie estimate lowers for weight loss and needs all body data', () => {
    const keep = dailyCalories({ height_cm: 178, weight_dg: 740, birth_year: 1994, diet_goal: 'keep' }, 2026)!;
    expect(dailyCalories({ height_cm: 178, weight_dg: 740, birth_year: 1994, diet_goal: 'lose' }, 2026)).toBeLessThan(keep);
    expect(dailyCalories({ height_cm: 178, weight_dg: null, birth_year: 1994, diet_goal: 'keep' }, 2026)).toBeNull();
  });
});
