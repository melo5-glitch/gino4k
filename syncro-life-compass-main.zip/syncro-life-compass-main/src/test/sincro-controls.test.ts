import { describe, expect, it } from 'vitest';
import { maskSensitive, cloudState, inactivityExpired } from '@/lib/sincro/controls';
import { greeting } from '@/lib/sincro/schemas';
describe('Sincro control rules', () => {
  it('masks financial and health values with exactly four asterisks', () => { expect(maskSensitive('2.450,00 €', true)).toBe('****'); expect(maskSensitive('72 BPM', true)).toBe('****'); expect(maskSensitive('72 BPM', false)).toBe('72 BPM'); });
  it('uses device hours for greeting', () => { expect(greeting(9, 'it')).toBe('Buongiorno'); expect(greeting(19, 'it')).toBe('Buonasera'); expect(greeting(14, 'en')).toBe('Good afternoon'); });
  it('locks at the two-minute inactivity boundary', () => { expect(inactivityExpired(1000, 120999, 2)).toBe(false); expect(inactivityExpired(1000, 121000, 2)).toBe(true); expect(inactivityExpired(1000, 999999, 0)).toBe(false); });
  it('only reports synchronized after a successful completed Cloud read', () => { expect(cloudState(true, true, 'pending', true)).toBe('pending'); expect(cloudState(true, true, 'success', false)).toBe('synced'); expect(cloudState(false, true, 'success', false)).toBe('offline'); expect(cloudState(true, true, 'error', false)).toBe('error'); expect(cloudState(true, false, 'success', false)).toBe('signed-out'); });
});