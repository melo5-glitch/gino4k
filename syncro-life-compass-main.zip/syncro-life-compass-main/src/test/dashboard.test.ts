import { describe, expect, it } from 'vitest';
import { budgetFigures, groceryFigures, project } from '@/lib/sincro/dashboard';
const now = new Date(2026, 9, 24, 12);
const e = (kind: string, category: string, amount: number, discount = 0, date = now) => ({ kind, category, amount_cents: amount, discount_cents: discount, roundup_cents: 0, created_at: date.toISOString() });
describe('dashboard figures', () => {
  it('remaining budget excludes income, transfers and past months', () => {
    const r = budgetFigures([e('expense', 'Alimentari', 30000), e('income', 'Entrate', 99999), e('expense', 'Trasferimento', 5000), e('expense', 'Casa', 7000, 0, new Date(2026, 8, 3))], 120000, now);
    expect(r.remaining).toBe(90000); expect(r.daily).toBe(11250);
  });
  it('grocery savings count only discounts on groceries', () => { expect(groceryFigures([e('expense', 'Alimentari', 2000, 300), e('expense', 'Casa', 1000, 500)], now).saved).toBe(300); });
  it('projection without return is plain sum', () => { expect(project(10000, 1000, 0, 1)).toBe(22000); });
});
