export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      ai_usage: {
        Row: {
          day: string
          requests: number
          user_id: string
        }
        Insert: {
          day?: string
          requests?: number
          user_id: string
        }
        Update: {
          day?: string
          requests?: number
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          parts: Json
          role: string
          run_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          parts: Json
          role: string
          run_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          parts?: Json
          role?: string
          run_id?: string
          user_id?: string
        }
        Relationships: []
      }
      consent_events: {
        Row: {
          accepted: boolean
          created_at: string
          id: string
          kind: string
          user_id: string
          version: string
        }
        Insert: {
          accepted: boolean
          created_at?: string
          id?: string
          kind: string
          user_id: string
          version: string
        }
        Update: {
          accepted?: boolean
          created_at?: string
          id?: string
          kind?: string
          user_id?: string
          version?: string
        }
        Relationships: []
      }
      financial_accounts: {
        Row: {
          account_type: string
          created_at: string
          household_id: string | null
          id: string
          name: string
          opening_cents: number
          user_id: string
        }
        Insert: {
          account_type: string
          created_at?: string
          household_id?: string | null
          id?: string
          name: string
          opening_cents?: number
          user_id: string
        }
        Update: {
          account_type?: string
          created_at?: string
          household_id?: string | null
          id?: string
          name?: string
          opening_cents?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "financial_accounts_household_id_fkey"
            columns: ["household_id"]
            isOneToOne: false
            referencedRelation: "households"
            referencedColumns: ["id"]
          },
        ]
      }
      goal_allocations: {
        Row: {
          amount_cents: number
          goal_id: string
          id: string
          transaction_id: string
        }
        Insert: {
          amount_cents: number
          goal_id: string
          id?: string
          transaction_id: string
        }
        Update: {
          amount_cents?: number
          goal_id?: string
          id?: string
          transaction_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "goal_allocations_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "saving_goals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "goal_allocations_transaction_id_fkey"
            columns: ["transaction_id"]
            isOneToOne: true
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      household_invites: {
        Row: {
          created_at: string
          expires_at: string
          household_id: string
          id: string
          role: string
          used_by: string | null
        }
        Insert: {
          created_at?: string
          expires_at?: string
          household_id: string
          id?: string
          role: string
          used_by?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string
          household_id?: string
          id?: string
          role?: string
          used_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "household_invites_household_id_fkey"
            columns: ["household_id"]
            isOneToOne: false
            referencedRelation: "households"
            referencedColumns: ["id"]
          },
        ]
      }
      household_members: {
        Row: {
          household_id: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          household_id: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          household_id?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "household_members_household_id_fkey"
            columns: ["household_id"]
            isOneToOne: false
            referencedRelation: "households"
            referencedColumns: ["id"]
          },
        ]
      }
      households: {
        Row: {
          created_at: string
          id: string
          name: string
          owner_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          owner_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          dedupe_key: string
          id: string
          read: boolean
          title: string
          user_id: string
        }
        Insert: {
          body?: string
          created_at?: string
          dedupe_key: string
          id?: string
          read?: boolean
          title: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          dedupe_key?: string
          id?: string
          read?: boolean
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          autonomous_ai: boolean
          avatar_key: string
          birth_year: number | null
          currency: string
          diet_goal: string
          display_name: string
          emergency: boolean
          extra_income_cents: number
          height_cm: number | null
          id: string
          locale: string
          lock_minutes: number
          monthly_budget_cents: number
          onboarded: boolean
          pac_invested_cents: number
          pac_monthly_cents: number
          pac_risk: string
          photo_path: string | null
          postal_code: string
          quiet_end: string
          quiet_start: string
          round_up: boolean
          salary_cents: number
          stock_threshold: number
          theme: string
          timezone: string
          updated_at: string
          weight_dg: number | null
        }
        Insert: {
          autonomous_ai?: boolean
          avatar_key?: string
          birth_year?: number | null
          currency?: string
          diet_goal?: string
          display_name?: string
          emergency?: boolean
          extra_income_cents?: number
          height_cm?: number | null
          id: string
          locale?: string
          lock_minutes?: number
          monthly_budget_cents?: number
          onboarded?: boolean
          pac_invested_cents?: number
          pac_monthly_cents?: number
          pac_risk?: string
          photo_path?: string | null
          postal_code?: string
          quiet_end?: string
          quiet_start?: string
          round_up?: boolean
          salary_cents?: number
          stock_threshold?: number
          theme?: string
          timezone?: string
          updated_at?: string
          weight_dg?: number | null
        }
        Update: {
          autonomous_ai?: boolean
          avatar_key?: string
          birth_year?: number | null
          currency?: string
          diet_goal?: string
          display_name?: string
          emergency?: boolean
          extra_income_cents?: number
          height_cm?: number | null
          id?: string
          locale?: string
          lock_minutes?: number
          monthly_budget_cents?: number
          onboarded?: boolean
          pac_invested_cents?: number
          pac_monthly_cents?: number
          pac_risk?: string
          photo_path?: string | null
          postal_code?: string
          quiet_end?: string
          quiet_start?: string
          round_up?: boolean
          salary_cents?: number
          stock_threshold?: number
          theme?: string
          timezone?: string
          updated_at?: string
          weight_dg?: number | null
        }
        Relationships: []
      }
      receipt_drafts: {
        Row: {
          created_at: string
          file_name: string
          id: string
          merchant: string
          status: string
          total_cents: number
          user_id: string
        }
        Insert: {
          created_at?: string
          file_name: string
          id?: string
          merchant?: string
          status?: string
          total_cents?: number
          user_id: string
        }
        Update: {
          created_at?: string
          file_name?: string
          id?: string
          merchant?: string
          status?: string
          total_cents?: number
          user_id?: string
        }
        Relationships: []
      }
      saving_goals: {
        Row: {
          created_at: string
          id: string
          name: string
          target_cents: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          target_cents: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          target_cents?: number
          user_id?: string
        }
        Relationships: []
      }
      shopping_items: {
        Row: {
          category: string
          checked: boolean
          deleted: boolean
          expires_on: string | null
          favorite: boolean
          household_id: string | null
          id: string
          name: string
          quantity: number
          recurring: boolean
          stock: number
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string
          checked?: boolean
          deleted?: boolean
          expires_on?: string | null
          favorite?: boolean
          household_id?: string | null
          id?: string
          name: string
          quantity?: number
          recurring?: boolean
          stock?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          checked?: boolean
          deleted?: boolean
          expires_on?: string | null
          favorite?: boolean
          household_id?: string | null
          id?: string
          name?: string
          quantity?: number
          recurring?: boolean
          stock?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "shopping_items_household_id_fkey"
            columns: ["household_id"]
            isOneToOne: false
            referencedRelation: "households"
            referencedColumns: ["id"]
          },
        ]
      }
      sincro_ai_control: {
        Row: {
          category: string | null
          id: number
          paused: boolean
          reason: string | null
        }
        Insert: {
          category?: string | null
          id: number
          paused?: boolean
          reason?: string | null
        }
        Update: {
          category?: string | null
          id?: number
          paused?: boolean
          reason?: string | null
        }
        Relationships: []
      }
      sincro_ai_jobs: {
        Row: {
          completed_at: string | null
          error_message: string | null
          last_day: string | null
          lease_token: string | null
          lease_until: string | null
          status: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          error_message?: string | null
          last_day?: string | null
          lease_token?: string | null
          lease_until?: string | null
          status?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          error_message?: string | null
          last_day?: string | null
          lease_token?: string | null
          lease_until?: string | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sincro_ai_jobs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      transactions: {
        Row: {
          account_id: string | null
          amount_cents: number
          category: string
          created_at: string
          description: string
          discount_cents: number
          goal_id: string | null
          household_id: string | null
          id: string
          kind: string
          operation_id: string
          reference_cents: number
          roundup_cents: number
          user_id: string
        }
        Insert: {
          account_id?: string | null
          amount_cents: number
          category?: string
          created_at?: string
          description: string
          discount_cents?: number
          goal_id?: string | null
          household_id?: string | null
          id?: string
          kind: string
          operation_id: string
          reference_cents?: number
          roundup_cents?: number
          user_id: string
        }
        Update: {
          account_id?: string | null
          amount_cents?: number
          category?: string
          created_at?: string
          description?: string
          discount_cents?: number
          goal_id?: string | null
          household_id?: string | null
          id?: string
          kind?: string
          operation_id?: string
          reference_cents?: number
          roundup_cents?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "financial_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "saving_goals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_household_id_fkey"
            columns: ["household_id"]
            isOneToOne: false
            referencedRelation: "households"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      sincro_ai_snapshot: { Args: { u: string }; Returns: Json }
      sincro_claim_ai:
        | { Args: never; Returns: boolean }
        | { Args: { u: string }; Returns: string }
      sincro_complete_ai: {
        Args: { body_text: string; t: string; u: string }
        Returns: boolean
      }
      sincro_evaluate_rules: { Args: never; Returns: undefined }
      sincro_family_access: {
        Args: { edit?: boolean; funds?: boolean; h: string }
        Returns: boolean
      }
      sincro_invite: { Args: { h: string; r: string }; Returns: string }
      sincro_join: { Args: { invite: string }; Returns: string }
      sincro_post_entry: {
        Args: {
          a: string
          cat: string
          cents: number
          descr: string
          g?: string
          k: string
          op: string
          reference: number
        }
        Returns: {
          account_id: string | null
          amount_cents: number
          category: string
          created_at: string
          description: string
          discount_cents: number
          goal_id: string | null
          household_id: string | null
          id: string
          kind: string
          operation_id: string
          reference_cents: number
          roundup_cents: number
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "transactions"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      sincro_record_transaction: {
        Args: {
          cat: string
          cents: number
          descr: string
          g?: string
          h?: string
          k: string
          op: string
          reference?: number
        }
        Returns: {
          account_id: string | null
          amount_cents: number
          category: string
          created_at: string
          description: string
          discount_cents: number
          goal_id: string | null
          household_id: string | null
          id: string
          kind: string
          operation_id: string
          reference_cents: number
          roundup_cents: number
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "transactions"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      sincro_remove_member: { Args: { member: string }; Returns: undefined }
      sincro_transfer: {
        Args: { cents: number; destination: string; op: string; source: string }
        Returns: {
          account_id: string | null
          amount_cents: number
          category: string
          created_at: string
          description: string
          discount_cents: number
          goal_id: string | null
          household_id: string | null
          id: string
          kind: string
          operation_id: string
          reference_cents: number
          roundup_cents: number
          user_id: string
        }[]
        SetofOptions: {
          from: "*"
          to: "transactions"
          isOneToOne: false
          isSetofReturn: true
        }
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
