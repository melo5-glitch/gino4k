import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Auth } from '@/components/sincro/Auth';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/auth')({head:()=>pageHead('Accesso','Gestisci il tuo accesso personale a Sincro.'),component:()=> <Page><Auth/></Page>});
