import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { ResetPassword } from '@/components/sincro/Auth';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/reset-password')({head:()=>pageHead('Recupero password','Gestisci il tuo accesso personale a Sincro.'),component:()=> <Page><ResetPassword/></Page>});
