import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Ledger } from '@/components/sincro/Foundation';
import { AccountSurface } from '@/lib/sincro/account';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/spese')({head:()=>pageHead('Spese','Entrate, uscite e registro contabile personale.'),component:()=> <Page><h1 className="mb-8 text-2xl font-bold">Spese</h1><AccountSurface><Ledger/></AccountSurface></Page>});
