import { createFileRoute, Link } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { SecuritySettings } from '@/components/sincro/Security';
import { useAccount } from '@/lib/sincro/account';
import { useI18n } from '@/lib/i18n';
import { pageHead } from '@/lib/sincro/schemas';
import { Button } from '@/components/ui/button';
export const Route = createFileRoute('/sicurezza')({ head: () => pageHead('Sicurezza', 'Blocco dell’account Sincro, verifica della password e timeout di inattività.'), component: SecurityPage });
function SecurityPage() { const { user, ready } = useAccount(); const { lang } = useI18n(); return <Page><h1 className="mb-8 text-2xl font-bold">{lang === 'it' ? 'Sicurezza' : 'Security'}</h1>{!ready ? <p>…</p> : user ? <SecuritySettings /> : <Button asChild><Link to="/auth">{lang === 'it' ? 'Accedi' : 'Sign in'}</Link></Button>}</Page>; }