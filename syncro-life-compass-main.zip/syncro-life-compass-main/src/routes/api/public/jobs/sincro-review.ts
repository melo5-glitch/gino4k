import { createFileRoute } from '@tanstack/react-router';
import { authenticateCronRequest } from '@/integrations/supabase/cron-auth';
export const Route = createFileRoute('/api/public/jobs/sincro-review')({
  server: { handlers: { POST: async ({ request }) => {
    const denied = await authenticateCronRequest(request);
    if (denied) return denied;
    const key = process.env['LOVABLE_API_KEY'];
    if (!key) return Response.json({ error: 'Configurazione IA mancante.' }, { status: 500 });
    const { reviewAccounts } = await import('@/lib/sincro/ai/worker.server');
    const result = await reviewAccounts(request, key);
    return Response.json(result, { status: 'status' in result ? result.status : 200 });
  } } },
});