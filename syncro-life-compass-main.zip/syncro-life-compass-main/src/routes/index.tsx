import { createFileRoute } from "@tanstack/react-router";
import SyncroApp from "@/SyncroApp";
import { AccountSurface } from "@/lib/sincro/account";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sincro — Il tuo assistente personale" },
      { name: "description", content: "Spesa intelligente, salute, budget e PAC in un'unica dashboard Sincro." },
      { property: "og:title", content: "Sincro — Il tuo assistente personale" },
      { property: "og:description", content: "Spesa intelligente, salute, budget e PAC in un'unica dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="px-4 pb-32 pt-6">
      <AccountSurface>
        <SyncroApp />
      </AccountSurface>
    </main>
  );
}

