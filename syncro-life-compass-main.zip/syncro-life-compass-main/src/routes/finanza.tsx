import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/sincro/Shell";
import { LiveBudget, LiveIncome, LivePac } from "@/components/sincro/LiveDashboard";
import { AccountSurface } from "@/lib/sincro/account";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/finanza")({
  head: () => ({
    meta: [
      { title: "PAC & Finanza — Sincro" },
      { name: "description", content: "Entrate, budget mensile, piani di accumulo e profilo di rischio." },
      { property: "og:title", content: "PAC & Finanza — Sincro" },
      { property: "og:description", content: "Entrate, budget, PAC e profilo di rischio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Page>
        <h1 className="mb-6 text-2xl font-bold">{t("finance")}</h1>
        <AccountSurface><div className="grid gap-4 lg:grid-cols-3">
          <LiveIncome />
          <LiveBudget />
          <LivePac />
        </div></AccountSurface>
      </Page>
    );
  },
});
