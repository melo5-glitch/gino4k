import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Accounts } from '@/components/sincro/Foundation';
import { AccountSurface } from '@/lib/sincro/account';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/portafoglio')({head:()=>pageHead('Portafoglio e PAC','Conti personali e condivisi e obiettivi di risparmio.'),component:()=> <Page><h1 className="mb-8 text-2xl font-bold">Portafoglio e PAC</h1><AccountSurface><Accounts/></AccountSurface></Page>});
