import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/sincro/Shell";
import { GroceryModule } from "@/components/sincro/Modules";
import { AmazonModule, DeliveryModule } from "@/components/sincro/HomeModules";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/negozi")({
  head: () => ({
    meta: [
      { title: "Negozi & Spesa — Sincro" },
      { name: "description", content: "Confronta i supermercati e trova le offerte migliori vicino a te." },
      { property: "og:title", content: "Negozi & Spesa — Sincro" },
      { property: "og:description", content: "Confronta i supermercati e trova le offerte migliori." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Page>
        <h1 className="mb-6 text-2xl font-bold">{t("shops")}</h1>
        <div className="grid gap-4 lg:grid-cols-2"><GroceryModule /><DeliveryModule /><AmazonModule /></div>
      </Page>
    );
  },
});
