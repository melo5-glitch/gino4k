import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Profile } from '@/components/sincro/Foundation';
import { ProfileIdentity } from '@/components/sincro/ProfileIdentity';
import { AccountSurface } from '@/lib/sincro/account';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/profilo')({head:()=>pageHead('Profilo','Nome, preferenze e gestione della famiglia.'),component:()=> <Page><h1 className="mb-8 text-2xl font-bold">Profilo</h1><AccountSurface><div className="space-y-8"><ProfileIdentity/><Profile/></div></AccountSurface></Page>});
