import { createFileRoute } from "@tanstack/react-router";
import { Page } from "@/components/sincro/Shell";
import { HealthModule } from "@/components/sincro/Modules";
import { LiveBio } from "@/components/sincro/LiveHealth";
import { AccountSurface } from "@/lib/sincro/account";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/salute")({
  head: () => ({
    meta: [
      { title: "Salute — Sincro" },
      { name: "description", content: "Calorie, passi, sonno, stress e nutrizione personalizzata sincronizzati dal tuo smartwatch." },
      { property: "og:title", content: "Salute — Sincro" },
      { property: "og:description", content: "Calorie, passi, sonno, stress e nutrizione dal tuo smartwatch." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => {
    const { t } = useI18n();
    return (
      <Page>
        <h1 className="mb-6 text-2xl font-bold">{t("health")}</h1>
        <div className="grid gap-4 lg:grid-cols-2">
          <HealthModule />
          <AccountSurface><LiveBio /></AccountSurface>
        </div>
      </Page>
    );
  },
});
