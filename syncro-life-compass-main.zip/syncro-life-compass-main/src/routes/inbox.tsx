import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Inbox } from '@/components/sincro/Foundation';
import { AccountSurface } from '@/lib/sincro/account';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/inbox')({head:()=>pageHead('Notifiche','Avvisi personali sulle scorte e sul risparmio.'),component:()=> <Page><h1 className="mb-8 text-2xl font-bold">Notifiche</h1><AccountSurface><Inbox/></AccountSurface></Page>});
