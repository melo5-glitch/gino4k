import { createFileRoute } from '@tanstack/react-router';
import { Page } from '@/components/sincro/Shell';
import { Receipts } from '@/components/sincro/Foundation';
import { AccountSurface } from '@/lib/sincro/account';
import { pageHead } from '@/lib/sincro/schemas';
export const Route=createFileRoute('/scontrini')({head:()=>pageHead('Scontrini','Preparazione di scontrini e fatture alla revisione.'),component:()=> <Page><h1 className="mb-8 text-2xl font-bold">Scontrini</h1><AccountSurface><Receipts/></AccountSurface></Page>});
