import React, { useCallback, useEffect, useRef, useState } from 'react';

/* ======================================================================
 * Bridge nativo
 *
 * Un browser NON può leggere HealthKit / Health Connect. Il wrapper nativo
 * (Capacitor, React Native WebView, ecc.) deve iniettare `window.SyncroHealthBridge`
 * con questa interfaccia. Se manca, il modulo resta in stato "non attivo".
 * ==================================================================== */

export type HealthDataType = 'blood_pressure' | 'ecg';

export interface Biometrics {
  systolic?: number;
  diastolic?: number;
  /** Classificazione prodotta dal dispositivo: l’app non interpreta l’ECG. */
  ecg?: { classification: string; avgHeartRate?: number };
  takenAt?: number;
}

export interface HealthBridge {
  platform: 'HealthKit' | 'HealthConnect';
  isAvailable(): Promise<boolean>;
  requestPermissions(types: HealthDataType[]): Promise<boolean>;
  readLatest(): Promise<Biometrics>;
}

declare global {
  interface Window {
    SyncroHealthBridge?: HealthBridge;
  }
}

export type HealthStatus =
  | { state: 'checking' }
  | { state: 'active'; platform: HealthBridge['platform'] }
  | { state: 'inactive'; reason: string };

/** Polling delle capacità hardware: si ferma appena il bridge risulta disponibile. */
export function useHealthCapabilities(bridgeProp?: HealthBridge, intervalMs = 10_000) {
  const [status, setStatus] = useState<HealthStatus>({ state: 'checking' });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    let timer: number | undefined;

    const probe = async () => {
      const bridge = bridgeProp ?? window.SyncroHealthBridge;
      let next: HealthStatus;
      if (!bridge) {
        next = { state: 'inactive', reason: 'Non attivo: nessun accesso a HealthKit o Health Connect da questo dispositivo. Apri SYNCRO dall’app iOS/Android con uno smartwatch collegato.' };
      } else {
        try {
          next = (await bridge.isAvailable())
            ? { state: 'active', platform: bridge.platform }
            : { state: 'inactive', reason: 'Non attivo: il dispositivo non rende disponibili pressione ed ECG.' };
        } catch {
          next = { state: 'inactive', reason: 'Non attivo: impossibile verificare le capacità del dispositivo.' };
        }
      }
      if (cancelled) return;
      setStatus(next);
      if (next.state !== 'active') timer = window.setTimeout(probe, intervalMs);
    };

    void probe();
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [bridgeProp, intervalMs, tick]);

  return { status, recheck: useCallback(() => setTick(t => t + 1), []) };
}

/* ======================================================================
 * Classificazione pressione (indicativa, soglie in stile AHA)
 * ==================================================================== */

export type BpLevel = 'normal' | 'elevated' | 'stage1' | 'stage2' | 'crisis';

export function classifyBloodPressure(sys: number, dia: number): { level: BpLevel; label: string } {
  if (sys > 180 || dia > 120) return { level: 'crisis', label: 'Valori molto alti: contatta subito un medico' };
  if (sys >= 140 || dia >= 90) return { level: 'stage2', label: 'Ipertensione stadio 2' };
  if (sys >= 130 || dia >= 80) return { level: 'stage1', label: 'Ipertensione stadio 1' };
  if (sys >= 120) return { level: 'elevated', label: 'Leggermente elevata' };
  return { level: 'normal', label: 'Nella norma' };
}

const BP_COLOR: Record<BpLevel, string> = {
  normal: 'text-emerald-400',
  elevated: 'text-amber-300',
  stage1: 'text-amber-400',
  stage2: 'text-orange-400',
  crisis: 'text-rose-400',
};

/* ======================================================================
 * Integrazione clinico-nutrizionale
 *
 * Il motore predefinito è un set di regole prudenti e verificabili. Può essere
 * sostituito da un servizio IA lato server (`advisor`): in tal caso i dati sanitari
 * lasciano il dispositivo, quindi serve un consenso esplicito dell’utente (GDPR art. 9).
 * Non propone MAI di avviare, sospendere o modificare farmaci o dosaggi.
 * ==================================================================== */

export interface NutritionInput {
  medications: string[];
  biometrics?: Biometrics;
}

export interface ShoppingAdjustments {
  increase: string[];
  reduce: string[];
  avoid: string[];
}

export interface NutritionAdjustment {
  notes: { source: string; text: string }[];
  shopping: ShoppingAdjustments;
  urgentMedicalAdvice?: string;
  disclaimer: string;
}

export interface NutritionAdvisor {
  recalibrate(input: NutritionInput): Promise<NutritionAdjustment>;
}

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

interface MedRule {
  match: RegExp;
  note: string;
  reduce?: string[];
  avoid?: string[];
}

const MED_RULES: MedRule[] = [
  { match: /warfarin|coumadin|acenocumarolo|sintrom/, note: 'Anticoagulanti antagonisti della vitamina K: mantieni COSTANTE l’apporto di verdure a foglia verde, senza eliminarle né aumentarle bruscamente.' },
  { match: /simvastatin|atorvastatin|lovastatin/, note: 'Con alcune statine il pompelmo può aumentarne i livelli nel sangue.', avoid: ['pompelmo e succo di pompelmo'] },
  { match: /ramipril|enalapril|lisinopril|losartan|valsartan|olmesartan|spironolattone|canrenone|eplerenone/, note: 'Questi farmaci possono aumentare il potassio: evita i sali dietetici a base di potassio e chiedi al medico prima di integratori.', reduce: ['sostituti del sale a base di potassio'] },
  { match: /levotiroxina|eutirox|synthroid/, note: 'Assumi a digiuno e distanzia di 30–60 minuti caffè, latticini e integratori di calcio o ferro, come indicato dal foglietto.' },
  { match: /metformina|glucophage/, note: 'Con la metformina è utile ripartire i carboidrati nei pasti; a lungo termine il medico può controllare la vitamina B12.' },
  { match: /furosemide|idroclorotiazide|lasix/, note: 'I diuretici aumentano la perdita di liquidi: mantieni una buona idratazione, salvo diversa indicazione medica.' },
];

const DISCLAIMER = 'Suggerimenti informativi basati su regole generali: non sono una diagnosi né una prescrizione. Confermali con il tuo medico o farmacista.';

export const localNutritionAdvisor: NutritionAdvisor = {
  async recalibrate({ medications, biometrics }) {
    const notes: NutritionAdjustment['notes'] = [];
    const increase = new Set<string>();
    const reduce = new Set<string>();
    const avoid = new Set<string>();
    let urgent: string | undefined;

    for (const med of medications) {
      const rule = MED_RULES.find(r => r.match.test(norm(med)));
      if (!rule) {
        notes.push({ source: med, text: 'Nessuna regola nota: la spesa non è stata modificata. Chiedi al farmacista o al medico se ci sono indicazioni alimentari.' });
        continue;
      }
      notes.push({ source: med, text: rule.note });
      rule.reduce?.forEach(x => reduce.add(x));
      rule.avoid?.forEach(x => avoid.add(x));
    }

    const b = biometrics;
    if (b?.systolic && b.diastolic) {
      const { level, label } = classifyBloodPressure(b.systolic, b.diastolic);
      if (level === 'crisis') {
        urgent = 'La pressione rilevata è molto alta. Contatta subito un medico o il numero di emergenza: l’app non modifica la spesa in questo caso.';
      } else if (level === 'stage1' || level === 'stage2') {
        notes.push({ source: `Pressione ${b.systolic}/${b.diastolic}`, text: `${label}: riduci il sale e i cibi molto lavorati, privilegia verdura, legumi e cereali integrali.` });
        ['sale da cucina', 'insaccati e salumi', 'snack salati'].forEach(x => reduce.add(x));
        ['verdure di stagione', 'legumi', 'cereali integrali'].forEach(x => increase.add(x));
      }
    }
    if (b?.ecg && /fibrill|afib|irregolar|anomal|inconclus|alta|bassa/i.test(b.ecg.classification) && !urgent) {
      urgent = `Il dispositivo ha segnalato: “${b.ecg.classification}”. Parlane con il tuo medico. SYNCRO non interpreta l’ECG.`;
    }

    // Se un farmaco impone di evitare qualcosa, ha la precedenza sulle aggiunte
    avoid.forEach(a => increase.delete(a));

    return {
      notes,
      shopping: { increase: [...increase], reduce: [...reduce], avoid: [...avoid] },
      urgentMedicalAdvice: urgent,
      disclaimer: DISCLAIMER,
    };
  },
};

/* ======================================================================
 * Componente
 * ==================================================================== */

export interface SyncroHealthProps {
  bridge?: HealthBridge;
  advisor?: NutritionAdvisor;
  /**
   * Chiamata SOLO quando l’utente preme “Applica alla spesa”.
   * Riceve esclusivamente le voci di spesa: farmaci e valori biometrici non escono dal modulo.
   */
  onApplyToShopping?: (shopping: ShoppingAdjustments) => void;
}

const card = 'rounded-xl border border-slate-800 bg-slate-900/60 p-4';
const focusRing = 'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

export default function SyncroHealth({ bridge, advisor = localNutritionAdvisor, onApplyToShopping }: SyncroHealthProps) {
  const { status, recheck } = useHealthCapabilities(bridge);
  const activeBridge = bridge ?? (typeof window !== 'undefined' ? window.SyncroHealthBridge : undefined);

  const [granted, setGranted] = useState(false);
  const [bio, setBio] = useState<Biometrics | undefined>();
  const [readError, setReadError] = useState<string | null>(null);

  const [meds, setMeds] = useState<string[]>([]);
  const [draft, setDraft] = useState('');

  const [adjustment, setAdjustment] = useState<NutritionAdjustment | null>(null);
  const [loading, setLoading] = useState(false);
  const [adviceError, setAdviceError] = useState<string | null>(null);
  const reqId = useRef(0);

  /* Permessi e lettura periodica (solo se il bridge è attivo) */
  const connect = async () => {
    if (!activeBridge) return;
    setReadError(null);
    try {
      const ok = await activeBridge.requestPermissions(['blood_pressure', 'ecg']);
      setGranted(ok);
      if (!ok) setReadError('Permesso negato. Puoi riattivarlo dalle impostazioni salute del telefono.');
    } catch {
      setReadError('Impossibile richiedere i permessi.');
    }
  };

  useEffect(() => {
    if (status.state !== 'active' || !granted || !activeBridge) return;
    let cancelled = false;
    const read = async () => {
      try {
        const data = await activeBridge.readLatest();
        if (!cancelled) {
          setBio(data);
          setReadError(null);
        }
      } catch {
        if (!cancelled) setReadError('Lettura dei parametri non riuscita.');
      }
    };
    void read();
    const id = window.setInterval(read, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [status.state, granted, activeBridge]);

  /* Farmaci: testo libero */
  const addMed = () => {
    const v = draft.trim().slice(0, 80);
    if (!v) return;
    if (!meds.some(m => m.toLowerCase() === v.toLowerCase()) && meds.length < 30) setMeds([...meds, v]);
    setDraft('');
  };

  /* Ricalibrazione automatica (debounce + scarto delle risposte superate) */
  useEffect(() => {
    if (meds.length === 0 && !bio) {
      setAdjustment(null);
      setLoading(false);
      return;
    }
    const id = ++reqId.current;
    setLoading(true);
    setAdviceError(null);
    const t = window.setTimeout(async () => {
      try {
        const result = await advisor.recalibrate({ medications: meds, biometrics: bio });
        if (id === reqId.current) setAdjustment(result);
      } catch {
        if (id === reqId.current) setAdviceError('Impossibile elaborare i suggerimenti ora.');
      } finally {
        if (id === reqId.current) setLoading(false);
      }
    }, 400);
    return () => window.clearTimeout(t);
  }, [meds, bio, advisor]);

  const bp = bio?.systolic && bio.diastolic ? classifyBloodPressure(bio.systolic, bio.diastolic) : null;
  const chips = (list: string[], tone: string) =>
    list.map(x => (
      <span key={x} className={`rounded px-1.5 py-0.5 text-[10px] ${tone}`}>
        {x}
      </span>
    ));

  return (
    <div className="mx-auto my-4 max-w-md space-y-3 text-slate-100">
      {/* Biometria */}
      <section className={card} aria-label="Parametri biometrici">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Smartwatch e biometria</h3>
          <span
            role="status"
            className={`flex items-center gap-1.5 rounded-full border border-slate-800 bg-slate-950/60 px-2.5 py-1 text-[11px] ${
              status.state === 'active' ? 'text-emerald-300' : 'text-slate-400'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${status.state === 'active' ? 'bg-emerald-400' : status.state === 'checking' ? 'bg-amber-400' : 'bg-slate-600'}`} aria-hidden="true" />
            {status.state === 'active' ? status.platform === 'HealthKit' ? 'HealthKit' : 'Health Connect' : status.state === 'checking' ? 'Verifica…' : 'Non attivo'}
          </span>
        </div>

        {status.state === 'inactive' && (
          <div className="mt-2 space-y-2">
            <p className="text-[11px] text-slate-400">{status.reason}</p>
            <button type="button" onClick={recheck} className={`rounded-lg border border-slate-700 px-3 py-1.5 text-[11px] text-slate-200 hover:bg-slate-800 ${focusRing}`}>
              Riprova ora
            </button>
          </div>
        )}

        {status.state === 'active' && !granted && (
          <button type="button" onClick={connect} className={`mt-3 w-full rounded-lg bg-blue-600 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
            Consenti lettura di pressione ed ECG
          </button>
        )}

        {status.state === 'active' && granted && (
          <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-3">
              <dt className="text-[11px] text-slate-400">Pressione</dt>
              <dd className="mt-1 text-lg font-semibold tabular-nums">{bio?.systolic && bio.diastolic ? `${bio.systolic}/${bio.diastolic}` : '—'}</dd>
              {bp && <dd className={`text-[11px] ${BP_COLOR[bp.level]}`}>{bp.label}</dd>}
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-3">
              <dt className="text-[11px] text-slate-400">ECG</dt>
              <dd className="mt-1 text-sm font-medium">{bio?.ecg?.classification ?? '—'}</dd>
              {bio?.ecg?.avgHeartRate && <dd className="text-[11px] text-slate-400">{bio.ecg.avgHeartRate} bpm medi</dd>}
            </div>
          </dl>
        )}
        {readError && <p className="mt-2 text-[11px] text-rose-300" role="alert">{readError}</p>}
        {bio?.takenAt && <p className="mt-2 text-[10px] text-slate-500">Ultima misura: {new Date(bio.takenAt).toLocaleString('it-IT')}</p>}
      </section>

      {/* Farmaci */}
      <section className={card} aria-label="Farmaci in corso">
        <h3 className="text-sm font-semibold">Farmaci in corso</h3>
        <p className="mt-1 text-[11px] text-slate-500">Dati sanitari: restano su questo dispositivo, solo per questa sessione, e non vengono condivisi con lo spazio di gruppo.</p>
        <form
          onSubmit={e => {
            e.preventDefault();
            addMed();
          }}
          className="mt-3 flex gap-2"
        >
          <input
            value={draft}
            onChange={e => setDraft(e.target.value)}
            maxLength={80}
            placeholder="Es. Farmaco X"
            aria-label="Nome del farmaco"
            className={`min-w-0 flex-1 rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs ${focusRing}`}
          />
          <button type="submit" className={`rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
            Aggiungi
          </button>
        </form>
        <ul className="mt-2 flex flex-wrap gap-1.5">
          {meds.map(m => (
            <li key={m} className="flex items-center gap-1 rounded-full border border-slate-700 bg-slate-950/70 py-1 pl-2.5 pr-1 text-xs">
              {m}
              <button type="button" onClick={() => setMeds(meds.filter(x => x !== m))} aria-label={`Rimuovi ${m}`} className={`rounded-full px-1.5 text-slate-500 hover:text-rose-400 ${focusRing}`}>
                ✕
              </button>
            </li>
          ))}
          {meds.length === 0 && <li className="text-[11px] text-slate-500">Nessun farmaco inserito.</li>}
        </ul>
      </section>

      {/* Ricalibrazione clinico-nutrizionale */}
      <section className={card} aria-label="Ricalibrazione nutrizionale" aria-live="polite">
        <h3 className="text-sm font-semibold">Fabbisogni e spesa</h3>
        {!adjustment && !loading && <p className="mt-1 text-[11px] text-slate-400">Inserisci un farmaco o collega lo smartwatch: i suggerimenti compaiono qui in automatico.</p>}
        {loading && <p className="mt-1 text-[11px] text-slate-400">Elaboro i suggerimenti…</p>}
        {adviceError && <p className="mt-1 text-[11px] text-rose-300" role="alert">{adviceError}</p>}

        {adjustment && (
          <div className="mt-2 space-y-3">
            {adjustment.urgentMedicalAdvice && (
              <p className="rounded-lg border border-rose-500/40 bg-rose-500/10 p-3 text-xs text-rose-100" role="alert">
                {adjustment.urgentMedicalAdvice}
              </p>
            )}
            <ul className="space-y-1.5">
              {adjustment.notes.map((n, i) => (
                <li key={`${n.source}-${i}`} className="rounded-lg border border-slate-800 bg-slate-950/70 p-2.5 text-xs">
                  <span className="font-medium text-slate-200">{n.source}</span>
                  <p className="mt-0.5 text-slate-400">{n.text}</p>
                </li>
              ))}
            </ul>
            {(adjustment.shopping.increase.length > 0 || adjustment.shopping.reduce.length > 0 || adjustment.shopping.avoid.length > 0) && (
              <div className="space-y-1.5 text-[11px]">
                {adjustment.shopping.increase.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1">
                    <span className="mr-1 text-slate-400">Privilegia</span>
                    {chips(adjustment.shopping.increase, 'bg-emerald-500/15 text-emerald-300')}
                  </div>
                )}
                {adjustment.shopping.reduce.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1">
                    <span className="mr-1 text-slate-400">Riduci</span>
                    {chips(adjustment.shopping.reduce, 'bg-amber-500/15 text-amber-300')}
                  </div>
                )}
                {adjustment.shopping.avoid.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1">
                    <span className="mr-1 text-slate-400">Evita</span>
                    {chips(adjustment.shopping.avoid, 'bg-rose-500/15 text-rose-300')}
                  </div>
                )}
                {onApplyToShopping && !adjustment.urgentMedicalAdvice && (
                  <button type="button" onClick={() => onApplyToShopping(adjustment.shopping)} className={`mt-1 w-full rounded-lg bg-blue-600 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
                    Applica alla spesa
                  </button>
                )}
              </div>
            )}
            <p className="text-[10px] text-slate-500">{adjustment.disclaimer}</p>
          </div>
        )}
      </section>
    </div>
  );
}
