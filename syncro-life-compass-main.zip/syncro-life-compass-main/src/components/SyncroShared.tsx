import React, { useEffect, useState } from 'react';
import {
  createDemoSnapshot,
  createInvite,
  createMockTransport,
  createWebSocketTransport,
  detectPushPlatform,
  isValidInviteCode,
  normalizeInviteCode,
  useSharedSpace,
} from './syncroSpaceEngine';
import type { ConnStatus, Invite } from './syncroSpaceEngine';
import type { Member, SpaceSnapshot } from './syncroTypes';

/* ---------- Piccoli componenti di presentazione ---------- */

function Avatar({ member, size = 32 }: { member?: Member; size?: number }) {
  const initials = (member?.name ?? '?')
    .split(' ')
    .map(p => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  return (
    <span
      aria-hidden="true"
      className="inline-flex shrink-0 items-center justify-center rounded-full text-[11px] font-semibold text-white"
      style={{ width: size, height: size, backgroundColor: member?.color ?? '#475569' }}
    >
      {initials}
    </span>
  );
}

function RoleBadge({ role }: { role: Member['role'] }) {
  return (
    <span
      className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${
        role === 'admin' ? 'bg-blue-500/15 text-blue-300' : 'bg-slate-700/60 text-slate-300'
      }`}
    >
      {role === 'admin' ? 'Admin' : 'Member'}
    </span>
  );
}

const STATUS_UI: Record<ConnStatus, { label: string; dot: string }> = {
  online: { label: 'Sincronizzato', dot: 'bg-emerald-400' },
  connecting: { label: 'Connessione…', dot: 'bg-amber-400' },
  offline: { label: 'Offline — riconnessione', dot: 'bg-rose-400' },
};

const hhmm = (ts: number) => new Date(ts).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });

const card = 'rounded-xl border border-slate-800 bg-slate-900/60 p-4';
const focusRing = 'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

/* ---------- Componente principale ---------- */

export interface SyncroSharedProps {
  currentUserId?: string;
  spaceId?: string;
  /** Se assente usa il server simulato in memoria. */
  wsUrl?: string;
  getToken?: () => string | undefined;
  /** Permette al genitore di passare membri/lista ad altri moduli (es. SyncroAI). */
  onSnapshot?: (snapshot: SpaceSnapshot) => void;
  /** Il server valida il codice: qui si inoltra soltanto la richiesta. */
  onJoinRequest?: (code: string) => void;
}

export default function SyncroShared({
  currentUserId = 'u1',
  spaceId = 'demo-space',
  wsUrl,
  getToken,
  onSnapshot,
  onJoinRequest,
}: SyncroSharedProps) {
  // Il trasporto è creato una sola volta per istanza del componente.
  const [transport] = useState(() =>
    wsUrl
      ? createWebSocketTransport(wsUrl, spaceId, getToken)
      : createMockTransport(createDemoSnapshot(), currentUserId, detectPushPlatform()),
  );
  const space = useSharedSpace(transport, currentUserId);
  const { view } = space;

  useEffect(() => {
    if (view) onSnapshot?.(view);
  }, [view, onSnapshot]);

  const [draft, setDraft] = useState('');
  const [invite, setInvite] = useState<Invite | null>(null);
  const [copied, setCopied] = useState<'code' | 'link' | null>(null);
  const [joinCode, setJoinCode] = useState('');
  const [joinMsg, setJoinMsg] = useState<string | null>(null);

  if (!view) {
    return <div className={`${card} mx-auto my-4 max-w-md text-sm text-slate-400`}>Connessione allo spazio condiviso…</div>;
  }

  const byId = new Map(view.members.map(m => [m.id, m]));
  const me = byId.get(currentUserId);
  const isAdmin = me?.role === 'admin';
  const st = STATUS_UI[space.status];

  const copy = async (what: 'code' | 'link', value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(what);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* clipboard non disponibile */
    }
  };

  const share = async (inv: Invite) => {
    const data = { title: `Unisciti a ${view.name} su SYNCRO`, text: `Codice invito: ${inv.code}`, url: inv.link };
    if (navigator.share) {
      try {
        await navigator.share(data);
        return;
      } catch {
        /* annullato dall’utente */
      }
    }
    void copy('link', inv.link);
  };

  const submitJoin = (e: React.FormEvent) => {
    e.preventDefault();
    const code = normalizeInviteCode(joinCode);
    if (!isValidInviteCode(code)) {
      setJoinMsg('Codice non valido. Formato: XXXXX-XXXXX.');
      return;
    }
    onJoinRequest?.(code);
    setJoinMsg('Richiesta inviata. Il server verificherà il codice.');
    setJoinCode('');
  };

  const submitItem = (e: React.FormEvent) => {
    e.preventDefault();
    space.addItem(draft);
    setDraft('');
  };

  return (
    <div className="mx-auto my-4 max-w-md space-y-3 text-slate-100">
      {/* Intestazione e stato di sincronizzazione */}
      <section className={card} aria-label="Spazio condiviso">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold">{view.name}</h3>
            <p className="text-[11px] text-slate-400">
              Versione {view.version}
              {space.pendingCount > 0 && ` · ${space.pendingCount} in attesa`}
              {space.conflicts > 0 && ` · ${space.conflicts} conflitti risolti`}
            </p>
          </div>
          <span className="flex items-center gap-1.5 rounded-full border border-slate-800 bg-slate-950/60 px-2.5 py-1 text-[11px] text-slate-300" role="status">
            <span className={`h-2 w-2 rounded-full ${st.dot}`} aria-hidden="true" />
            {st.label}
          </span>
        </div>
        <ul className="mt-3 flex flex-wrap gap-3">
          {view.members.map(m => (
            <li key={m.id} className="flex items-center gap-2">
              <Avatar member={m} />
              <div className="leading-tight">
                <div className="text-xs font-medium">{m.id === currentUserId ? `${m.name} (tu)` : m.name}</div>
                <RoleBadge role={m.role} />
              </div>
            </li>
          ))}
        </ul>
      </section>

      {/* Invito */}
      <section className={card} aria-label="Invita nello spazio">
        <h3 className="text-sm font-semibold">Invita persone</h3>
        {isAdmin ? (
          invite ? (
            <div className="mt-2 space-y-2">
              <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
                <span className="font-mono text-lg tracking-widest text-blue-300">{invite.code}</span>
                <button type="button" onClick={() => copy('code', invite.code)} className={`rounded px-2 py-1 text-xs text-slate-300 hover:bg-slate-800 ${focusRing}`}>
                  {copied === 'code' ? 'Copiato' : 'Copia'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400">Valido fino alle {hhmm(invite.expiresAt)} di {new Date(invite.expiresAt).toLocaleDateString('it-IT')}.</p>
              <div className="flex gap-2">
                <button type="button" onClick={() => share(invite)} className={`flex-1 rounded-lg bg-blue-600 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
                  Condividi link
                </button>
                <button type="button" onClick={() => setInvite(createInvite(window.location.origin))} className={`rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 ${focusRing}`}>
                  Nuovo codice
                </button>
              </div>
              {copied === 'link' && <p className="text-[11px] text-emerald-400">Link copiato negli appunti.</p>}
            </div>
          ) : (
            <button type="button" onClick={() => setInvite(createInvite(window.location.origin))} className={`mt-2 w-full rounded-lg bg-blue-600 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
              Genera codice invito
            </button>
          )
        ) : (
          <p className="mt-1 text-[11px] text-slate-400">Solo gli Admin possono generare inviti.</p>
        )}

        <form onSubmit={submitJoin} className="mt-3 flex gap-2 border-t border-slate-800 pt-3">
          <input
            value={joinCode}
            onChange={e => setJoinCode(e.target.value)}
            placeholder="Hai un codice? XXXXX-XXXXX"
            aria-label="Codice invito"
            autoCapitalize="characters"
            className={`min-w-0 flex-1 rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 font-mono text-xs placeholder:font-sans ${focusRing}`}
          />
          <button type="submit" className={`rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800 ${focusRing}`}>
            Unisciti
          </button>
        </form>
        {joinMsg && <p className="mt-1 text-[11px] text-slate-400">{joinMsg}</p>}
      </section>

      {/* Lista condivisa */}
      <section className={card} aria-label="Lista condivisa">
        <h3 className="text-sm font-semibold">Lista della spesa</h3>
        <ul className="mt-2 space-y-1.5">
          {view.items.map(item => {
            const author = byId.get(item.addedBy);
            const canRemove = isAdmin || item.addedBy === currentUserId;
            return (
              <li key={item.id} className="flex items-center gap-2">
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={item.done}
                  onClick={() => space.toggleItem(item.id)}
                  className={`flex flex-1 items-center gap-2.5 rounded-lg border px-2.5 py-2 text-left text-xs ${focusRing} ${
                    item.done ? 'border-slate-800/40 bg-slate-950/20 text-slate-500 line-through' : 'border-slate-800 bg-slate-950/70'
                  }`}
                >
                  <span className={`flex h-4 w-4 items-center justify-center rounded border text-[10px] ${item.done ? 'border-blue-500 bg-blue-600 text-white' : 'border-slate-700'}`}>
                    {item.done ? '✓' : ''}
                  </span>
                  <span className="flex-1">{item.name}</span>
                  <Avatar member={author} size={18} />
                </button>
                {canRemove && (
                  <button type="button" onClick={() => space.removeItem(item.id)} aria-label={`Rimuovi ${item.name}`} className={`rounded p-1.5 text-slate-500 hover:text-rose-400 ${focusRing}`}>
                    ✕
                  </button>
                )}
              </li>
            );
          })}
          {view.items.length === 0 && <li className="text-xs text-slate-500">Nessun articolo. Aggiungi il primo qui sotto.</li>}
        </ul>
        <form onSubmit={submitItem} className="mt-3 flex gap-2">
          <input
            value={draft}
            onChange={e => setDraft(e.target.value)}
            placeholder="Aggiungi un articolo"
            aria-label="Nuovo articolo"
            maxLength={80}
            className={`min-w-0 flex-1 rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs ${focusRing}`}
          />
          <button type="submit" className={`rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium hover:bg-blue-500 ${focusRing}`}>
            Aggiungi
          </button>
        </form>
      </section>

      {/* Feed attività */}
      <section className={card} aria-label="Attività recente">
        <h3 className="text-sm font-semibold">Attività recente</h3>
        <ul className="mt-2 space-y-2.5" aria-live="polite">
          {view.activity.length === 0 && <li className="text-xs text-slate-500">Nessuna attività ancora.</li>}
          {view.activity.slice(0, 8).map(a => {
            const m = byId.get(a.authorId);
            return (
              <li key={a.id} className="flex items-start gap-2.5">
                <Avatar member={m} size={28} />
                <div className="min-w-0 flex-1 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-medium">{m?.name ?? 'Utente'}</span>
                    {m && <RoleBadge role={m.role} />}
                    <span className="ml-auto text-[10px] text-slate-500">{hhmm(a.ts)}</span>
                  </div>
                  <p className="text-slate-300">{a.text}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      {/* Notifiche push simulate */}
      <section className={card} aria-label="Notifiche push simulate">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Notifiche push</h3>
          <button type="button" onClick={space.notifyGroup} className={`rounded-lg border border-slate-700 px-2.5 py-1 text-[11px] text-slate-200 hover:bg-slate-800 ${focusRing}`}>
            Avvisa il gruppo
          </button>
        </div>
        <p className="mt-1 text-[11px] text-slate-500">Simulazione: nessuna notifica reale viene inviata.</p>
        <ul className="mt-2 space-y-1.5" aria-live="polite">
          {space.pushes.map(p => (
            <li key={p.id} className="flex items-start justify-between gap-2 rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
              <div className="min-w-0 text-xs">
                <div className="font-medium">{p.title}</div>
                <div className="text-slate-400">{p.body}</div>
                <div className="mt-0.5 text-[10px] text-slate-500">{p.platform === 'local' ? 'Locale' : p.platform} · {hhmm(p.ts)}</div>
              </div>
              <button type="button" onClick={() => space.dismissPush(p.id)} aria-label="Chiudi notifica" className={`text-slate-500 hover:text-slate-300 ${focusRing}`}>
                ✕
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
