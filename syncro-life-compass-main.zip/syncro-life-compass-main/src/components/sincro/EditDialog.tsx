import { useState, type ReactNode } from 'react';
import { Pencil } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export type Field = { name: string; label: string; value: string; kind?: 'money' | 'number' | 'select'; options?: [string, string][]; placeholder?: string };

/** Converts "1.234,56" or "1234.5" to cents; null when invalid. */
export function parseMoney(raw: string) {
  const v = raw.trim().replace(/\s|€/g, '');
  if (v === '') return 0;
  const normalized = v.includes(',') ? v.replace(/\./g, '').replace(',', '.') : v;
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(normalized)) return null;
  return Math.round(Number(normalized) * 100);
}

export function EditDialog({ title, description, fields, onSave, label = 'Modifica', trigger }: { title: string; description?: string; fields: Field[]; onSave: (values: Record<string, string>) => Promise<void>; label?: string; trigger?: ReactNode }) {
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false);
  return <Dialog open={open} onOpenChange={setOpen}>
    <DialogTrigger asChild>{trigger ?? <Button variant="ghost" size="icon" aria-label={`${label}: ${title}`}><Pencil /></Button>}</DialogTrigger>
    <DialogContent>
      <DialogHeader><DialogTitle>{title}</DialogTitle>{description && <DialogDescription>{description}</DialogDescription>}</DialogHeader>
      <form className="space-y-4" onSubmit={async e => {
        e.preventDefault(); const f = new FormData(e.currentTarget); const values = Object.fromEntries(fields.map(x => [x.name, String(f.get(x.name) ?? '')]));
        setBusy(true);
        try { await onSave(values); toast.success('Salvato'); setOpen(false); } catch (err) { toast.error(err instanceof Error ? err.message : 'Salvataggio non riuscito'); } finally { setBusy(false); }
      }}>
        {fields.map(x => <label key={x.name} className="block space-y-2 text-sm">{x.label}
          {x.kind === 'select' ? <select name={x.name} defaultValue={x.value} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">{x.options?.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
            : <Input name={x.name} defaultValue={x.value} inputMode="decimal" placeholder={x.placeholder} />}
        </label>)}
        <DialogFooter><Button type="submit" disabled={busy}>{busy ? 'Salvataggio…' : 'Salva'}</Button></DialogFooter>
      </form>
    </DialogContent>
  </Dialog>;
}
