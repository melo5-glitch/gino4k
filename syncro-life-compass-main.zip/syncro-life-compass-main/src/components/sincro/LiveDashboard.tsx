import { useEffect, useMemo, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { toast } from 'sonner';
import { useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts';
import { ShoppingBag, Wallet, TrendingUp, Plus, Coins, ListChecks } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAccount, useFoundation } from '@/lib/sincro/account';
import { loadShopping } from '@/lib/sincro/data.functions';
import { budgetFigures, groceryFigures, pacFigures, project, euro } from '@/lib/sincro/dashboard';
import { greeting } from '@/lib/sincro/schemas';
import { useI18n } from '@/lib/i18n';
import { useServerFn } from '@tanstack/react-start';
import { saveFinance, editGoal, removeGoal } from '@/lib/sincro/data.functions';
import { EditDialog, parseMoney } from './EditDialog';
import { Button } from '@/components/ui/button';
import { Trash2, Briefcase, Target } from 'lucide-react';
import { useControls } from './Security';
import { ProfileAvatar } from './ProfileIdentity';

function Head({ icon: Icon, tone, title, sub }: { icon: typeof Wallet; tone: string; title: string; sub?: string }) {
  return <div className="mb-4 flex items-start gap-3"><span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${tone}`}><Icon className="h-4 w-4" /></span><div><h2 className="text-base font-semibold">{title}</h2>{sub && <p className="text-xs text-muted-foreground">{sub}</p>}</div></div>;
}

export function DashboardHero() {
  const { name, avatar, photo } = useControls(); const { user } = useAccount(); const { lang } = useI18n();
  const [hour, setHour] = useState<number | null>(null);
  useEffect(() => { const u = () => setHour(new Date().getHours()); u(); const t = setInterval(u, 60_000); return () => clearInterval(t); }, []);
  const hello = hour === null ? (lang === 'it' ? 'Bentornato' : 'Welcome back') : greeting(hour, lang);
  return <div className="mb-8 flex items-center gap-4">
    {user && <ProfileAvatar avatar={avatar} photo={photo} large />}
    <div className="min-w-0"><h1 className="break-words text-2xl font-bold sm:text-3xl">{hello}{name ? `, ${name}` : ''}</h1>
      <p className="text-sm text-muted-foreground">{lang === 'it' ? 'Ecco la tua situazione aggiornata.' : 'Here is your up-to-date overview.'}</p></div>
  </div>;
}

/** Refreshes dashboard data whenever the user's records change. */
function useLiveRefresh(userId: string) {
  const client = useQueryClient();
  useEffect(() => {
    const refresh = () => { void client.invalidateQueries({ queryKey: ['foundation', userId] }); void client.invalidateQueries({ queryKey: ['shopping', userId] }); };
    const channel = supabase.channel(`dashboard-${userId}`);
    for (const table of ['transactions', 'shopping_items', 'goal_allocations', 'profiles']) channel.on('postgres_changes', { event: '*', schema: 'public', table }, refresh);
    channel.subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [client, userId]);
}

export function LiveDashboard() {
  const { user } = useAccount(); const userId = user!.id;
  useLiveRefresh(userId);
  return <div className="grid gap-4 lg:grid-cols-3"><LiveGrocery userId={userId} /><LiveBudget /><LivePac /></div>;
}

function LiveGrocery({ userId }: { userId: string }) {
  const { lang, mask } = useI18n(); const it = lang === 'it'; const data = useFoundation();
  const items = useSuspenseQuery({ queryKey: ['shopping', userId], queryFn: () => loadShopping(), staleTime: 15000 }).data;
  const g = groceryFigures(data.entries);
  const open = items.filter(i => !i.checked);
  return <section className="card-sincro p-5 lg:col-span-2">
    <Head icon={ShoppingBag} tone="bg-deals/15 text-deals" title={it ? 'Spesa ottimizzata' : 'Optimized shopping'} sub={it ? 'Dal tuo registro di questo mese' : 'From this month’s records'} />
    <div className="grid gap-4 md:grid-cols-2">
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-surface p-4"><p className="text-xs text-muted-foreground">{it ? 'Spesa alimentare' : 'Groceries spent'}</p><p className="mt-1 font-display text-2xl font-bold tabular">{mask(euro(g.spent))}</p></div>
        <div className="rounded-xl border border-finance/30 bg-finance/10 p-4"><p className="text-xs text-muted-foreground">{it ? 'Sconti ottenuti' : 'Discounts earned'}</p><p className="mt-1 font-display text-2xl font-bold text-finance tabular">{mask(euro(g.saved))}</p></div>
        <p className="col-span-2 text-xs text-muted-foreground">{g.purchases} {it ? 'acquisti registrati questo mese' : 'purchases recorded this month'}</p>
      </div>
      <div className="rounded-xl border border-border p-4">
        <p className="mb-2 flex items-center gap-2 text-xs font-semibold"><ListChecks className="h-4 w-4 text-deals" />{it ? 'Da comprare' : 'To buy'} · {open.length}</p>
        {open.length === 0 ? <p className="text-xs text-muted-foreground">{it ? 'La tua lista è vuota.' : 'Your list is empty.'}</p> :
          <ul className="space-y-1.5 text-xs">{open.slice(0, 5).map(i => <li key={i.id} className="flex justify-between gap-2"><span className="truncate">{i.name}</span><span className="text-muted-foreground tabular">×{i.quantity}</span></li>)}</ul>}
        <Link to="/spese" className="mt-3 inline-flex text-xs font-semibold text-deals hover:underline">{it ? 'Gestisci la lista' : 'Manage list'}</Link>
      </div>
    </div>
  </section>;
}


const toEuro = (c: number) => (c / 100).toFixed(2).replace('.', ',');
function money(values: Record<string, string>, key: string) { const c = parseMoney(values[key] ?? ''); if (c === null) throw new Error('Importo non valido'); return c; }
function useFinanceSave() { const save = useServerFn(saveFinance); const client = useQueryClient(); return async (data: Parameters<typeof save>[0]['data']) => { await save({ data }); await client.invalidateQueries({ queryKey: ['foundation'] }); }; }

export function LiveBudget() {
  const { lang, mask, hidden } = useI18n(); const it = lang === 'it'; const data = useFoundation(); const save = useFinanceSave();
  const budget = data.profile?.monthly_budget_cents ?? 0; const b = budgetFigures(data.entries, budget);
  return <section className="card-sincro p-5">
    <div className="flex items-start justify-between"><Head icon={Wallet} tone="bg-finance/15 text-finance" title={it ? 'Budget mensile residuo' : 'Remaining monthly budget'} />
      <EditDialog title={it ? 'Budget mensile' : 'Monthly budget'} fields={[{ name: 'budget', label: it ? 'Budget mensile (€)' : 'Monthly budget (€)', value: toEuro(budget) }]} onSave={async v => save({ monthly_budget_cents: money(v, 'budget') })} /></div>
    {budget === 0 ? <p className="text-sm text-muted-foreground">{it ? 'Imposta un budget mensile con la matita per vedere quanto ti resta.' : 'Set a monthly budget with the pencil to see what is left.'}</p> : <>
      <p className="font-display text-4xl font-bold tabular">{mask(euro(b.remaining))} <span className="text-sm font-medium text-muted-foreground">{it ? 'di' : 'of'} {mask(euro(budget))}</span></p>
      <div className={`mt-4 h-2.5 overflow-hidden rounded-full bg-surface ${hidden ? 'invisible' : ''}`}><div className={`h-full rounded-full ${b.ratio >= 1 ? 'bg-destructive' : b.ratio >= .8 ? 'bg-deals' : 'bg-finance'}`} style={{ width: `${(1 - b.ratio) * 100}%` }} /></div>
      <div className="mt-4 flex items-center justify-between rounded-xl bg-surface p-3"><span className="text-xs text-muted-foreground">{it ? 'Disponibile oggi' : 'Available today'}</span><span className="font-display text-lg font-bold text-finance tabular">{mask(euro(b.daily))}</span></div>
    </>}
    <Link to="/spese" className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-finance/40 bg-finance/10 py-3 text-sm font-semibold text-finance transition hover:bg-finance/20"><Plus className="h-4 w-4" />{it ? 'Aggiungi spesa' : 'Add expense'}</Link>
  </section>;
}

export function LiveIncome() {
  const { lang, mask } = useI18n(); const it = lang === 'it'; const data = useFoundation(); const save = useFinanceSave();
  const salary = data.profile?.salary_cents ?? 0; const extra = data.profile?.extra_income_cents ?? 0; const budget = data.profile?.monthly_budget_cents ?? 0;
  const free = salary + extra - budget - (data.profile?.pac_monthly_cents ?? 0);
  return <section className="card-sincro p-5">
    <div className="flex items-start justify-between"><Head icon={Briefcase} tone="bg-finance/15 text-finance" title={it ? 'Entrate mensili' : 'Monthly income'} sub={it ? 'Inserite da te' : 'Entered by you'} />
      <EditDialog title={it ? 'Entrate mensili' : 'Monthly income'} fields={[{ name: 'salary', label: it ? 'Stipendio netto (€)' : 'Net salary (€)', value: toEuro(salary) }, { name: 'extra', label: it ? 'Altre entrate (€)' : 'Other income (€)', value: toEuro(extra) }]} onSave={async v => save({ salary_cents: money(v, 'salary'), extra_income_cents: money(v, 'extra') })} /></div>
    <div className="space-y-2">
      {[[it ? 'Stipendio' : 'Salary', salary], [it ? 'Altre entrate' : 'Other income', extra]].map(([l, c]) => <div key={l as string} className="flex items-center justify-between rounded-xl bg-surface p-3"><span className="text-xs text-muted-foreground">{l}</span><span className="font-display text-lg font-bold tabular">{mask(euro(c as number))}</span></div>)}
      <div className="flex items-center justify-between rounded-xl border border-finance/30 bg-finance/10 p-3"><span className="text-xs font-semibold">{it ? 'Totale entrate' : 'Total income'}</span><span className="font-display text-xl font-bold text-finance tabular">{mask(euro(salary + extra))}</span></div>
      {salary + extra > 0 && <p className={`text-xs ${free < 0 ? 'text-destructive' : 'text-muted-foreground'}`}>{it ? 'Dopo budget e PAC restano ' : 'After budget and savings plan: '}{mask(euro(free))}</p>}
    </div>
  </section>;
}

const rates = { low: 0.002, mid: 0.004, high: 0.006 } as const;
const riskLabel = (it: boolean) => it ? { low: 'Basso', mid: 'Medio', high: 'Alto' } : { low: 'Low', mid: 'Medium', high: 'High' };
export function LivePac() {
  const { lang, mask, hidden } = useI18n(); const it = lang === 'it'; const data = useFoundation(); const save = useFinanceSave();
  const [years, setYears] = useState(15);
  const p = useMemo(() => pacFigures(data.allocations, data.entries), [data.allocations, data.entries]);
  const risk = (data.profile?.pac_risk ?? 'mid') as keyof typeof rates;
  const declared = data.profile?.pac_invested_cents ?? 0; const monthly = data.profile?.pac_monthly_cents || p.monthlyAverage;
  const invested = declared + p.invested;
  const projected = project(invested, monthly, rates[risk], years);
  const series = p.series.map(x => ({ ...x, v: x.v + declared / 100 }));
  return <section className="card-sincro p-5 lg:col-span-3">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <Head icon={TrendingUp} tone="bg-invest/15 text-invest" title={it ? 'PAC e obiettivi di risparmio' : 'Savings plan and goals'} sub={it ? 'Importi dichiarati da te più le somme accantonate' : 'Your declared amounts plus amounts set aside'} />
      <div className="flex items-center gap-2">
        <div className="flex rounded-full border border-border bg-surface p-0.5 text-xs font-semibold" role="group" aria-label={it ? 'Profilo di rischio' : 'Risk profile'}>
          {(['low', 'mid', 'high'] as const).map(r => <button key={r} aria-pressed={risk === r} onClick={() => void save({ pac_risk: r }).catch(() => toast.error('Non salvato'))} className={`rounded-full px-3 py-1 transition ${risk === r ? 'bg-invest text-foreground' : 'text-muted-foreground'}`}>{riskLabel(it)[r]}</button>)}
        </div>
        <EditDialog title="PAC" fields={[{ name: 'monthly', label: it ? 'Versamento mensile (€)' : 'Monthly contribution (€)', value: toEuro(data.profile?.pac_monthly_cents ?? 0) }, { name: 'invested', label: it ? 'Già investito (€)' : 'Already invested (€)', value: toEuro(declared) }]} onSave={async v => save({ pac_monthly_cents: money(v, 'monthly'), pac_invested_cents: money(v, 'invested') })} />
      </div>
    </div>
    <div className="grid gap-5 md:grid-cols-3">
      <div className="h-44 md:col-span-2">{hidden ? <div className="grid h-full place-items-center text-muted-foreground">****</div> : invested === 0 ? <div className="grid h-full place-items-center text-center text-sm text-muted-foreground">{it ? 'Inserisci il tuo PAC con la matita o destina somme a un obiettivo.' : 'Enter your plan with the pencil or allocate to a goal.'}</div> :
        <ResponsiveContainer width="100%" height="100%"><AreaChart data={series}><defs><linearGradient id="pacLive" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--invest)" stopOpacity={0.5} /><stop offset="100%" stopColor="var(--invest)" stopOpacity={0} /></linearGradient></defs><XAxis dataKey="m" axisLine={false} tickLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 10 }} /><Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }} formatter={x => [euro(Number(x) * 100), '']} /><Area type="monotone" dataKey="v" stroke="var(--invest)" strokeWidth={2.5} fill="url(#pacLive)" /></AreaChart></ResponsiveContainer>}</div>
      <div className="grid gap-3">
        <div className="rounded-xl bg-surface p-3"><p className="text-[11px] text-muted-foreground">{it ? 'Capitale totale' : 'Total capital'}</p><p className="font-display text-xl font-bold tabular">{mask(euro(invested))}</p></div>
        <div className="rounded-xl bg-surface p-3"><p className="text-[11px] text-muted-foreground">{it ? 'Versamento mensile' : 'Monthly contribution'}</p><p className="font-display text-xl font-bold tabular">{mask(euro(monthly))}</p></div>
        <div className="rounded-xl border border-finance/30 bg-finance/10 p-3"><p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Coins className="h-3 w-3 text-finance" />{it ? 'Arrotondamenti del mese' : 'Round-ups this month'}</p><p className="font-display text-xl font-bold text-finance tabular">{mask(euro(p.roundups))}</p></div>
      </div>
    </div>
    <div className="mt-4 rounded-2xl border border-invest/30 bg-invest/5 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-xs font-semibold">{it ? 'Proiezione' : 'Projection'}</p><p className="text-xs text-muted-foreground">{years} {it ? 'anni' : 'years'}</p></div>
      <input type="range" min={1} max={40} value={years} onChange={e => setYears(Number(e.target.value))} className="mt-3 w-full accent-[var(--invest)]" aria-label={it ? 'Anni di proiezione' : 'Projection years'} />
      <div className="mt-2 flex items-center justify-between gap-3"><span className="text-xs text-muted-foreground">{it ? `Ipotesi: ${(rates[risk] * 1200).toFixed(1)}% annuo. Non è una previsione né consulenza.` : `Assumes ${(rates[risk] * 1200).toFixed(1)}% a year. Not a forecast or advice.`}</span><span className="font-display text-2xl font-bold text-invest tabular">{mask(euro(projected))}</span></div>
    </div>
    <GoalsList />
  </section>;
}

function GoalsList() {
  const { lang, mask } = useI18n(); const it = lang === 'it'; const data = useFoundation(); const client = useQueryClient();
  const edit = useServerFn(editGoal); const remove = useServerFn(removeGoal);
  if (!data.goals.length) return <p className="mt-4 text-xs text-muted-foreground">{it ? 'Nessun obiettivo. ' : 'No goals yet. '}<Link to="/portafoglio" className="text-finance hover:underline">{it ? 'Creane uno' : 'Create one'}</Link></p>;
  return <div className="mt-5 space-y-3"><p className="flex items-center gap-2 text-xs font-semibold"><Target className="h-4 w-4 text-finance" />{it ? 'Obiettivi' : 'Goals'}</p>
    {data.goals.map(g => { const saved = data.allocations.filter(a => a.goal_id === g.id).reduce((s, a) => s + a.amount_cents, 0); return <div key={g.id} className="flex items-center gap-3">
      <div className="min-w-0 flex-1"><div className="flex justify-between text-xs"><span className="truncate">{g.name}</span><span className="tabular">{mask(`${euro(saved)} / ${euro(g.target_cents)}`)}</span></div><progress className="budget-progress mt-1 h-1.5 w-full text-finance" max={g.target_cents} value={Math.min(saved, g.target_cents)} aria-label={g.name} /></div>
      <EditDialog title={it ? 'Modifica obiettivo' : 'Edit goal'} fields={[{ name: 'name', label: it ? 'Nome' : 'Name', value: g.name }, { name: 'target', label: it ? 'Traguardo (€)' : 'Target (€)', value: toEuro(g.target_cents) }]} onSave={async v => { const t = money(v, 'target'); if (!t) throw new Error('Traguardo non valido'); await edit({ data: { id: g.id, name: v['name'] ?? '', target_cents: t } }); await client.invalidateQueries({ queryKey: ['foundation'] }); }} />
      <Button variant="ghost" size="icon" aria-label={`${it ? 'Elimina' : 'Delete'} ${g.name}`} onClick={async () => { if (!confirm(it ? 'Eliminare questo obiettivo?' : 'Delete this goal?')) return; try { await remove({ data: g.id }); await client.invalidateQueries({ queryKey: ['foundation'] }); } catch (e) { toast.error(e instanceof Error ? e.message : 'Errore'); } }}><Trash2 /></Button>
    </div>; })}
  </div>;
}
