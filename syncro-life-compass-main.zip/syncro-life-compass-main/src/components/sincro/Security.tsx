import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useQuery, useQueryClient, useIsFetching } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { LockKeyhole, Fingerprint, ShieldCheck, LogOut } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAccount } from '@/lib/sincro/account';
import { loadControls, saveLockTimeout } from '@/lib/sincro/data.functions';
import { cloudState, inactivityExpired } from '@/lib/sincro/controls';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { greeting } from '@/lib/sincro/schemas';
import logo from '@/assets/sincro-logo.png';

const lockKey = 'sincro-security-lock';
type LockedIdentity = { id: string; email: string; minutes: number };
const ControlsContext = createContext<{name:string;minutes:number;state:string;avatar:string;photo:string|null;lock:()=>void;refresh:()=>Promise<void>}>({ name: '', minutes: 0, state: 'pending', avatar: 'sprout', photo: null, lock: () => {}, refresh: async () => {} });
export const useControls = () => useContext(ControlsContext);

export function SecurityProvider({ children }: { children: ReactNode }) {
  const { user, ready, online } = useAccount();
  const { lang } = useI18n();
  const client = useQueryClient();
  const read = useServerFn(loadControls);
  const [restored, setRestored] = useState(false);
  const [locked, setLocked] = useState<LockedIdentity | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const signingOut = useRef<Promise<unknown> | null>(null);
  const query = useQuery({ queryKey: ['controls', user?.id], queryFn: () => read(), enabled: Boolean(user) && !locked && restored, retry: 1, refetchInterval: 30_000, refetchOnWindowFocus: true });
  const photoPath = query.data?.photo_path ?? null;
  const photo = useQuery({ queryKey: ['profile-photo', user?.id, photoPath], enabled: Boolean(user && photoPath && !locked), staleTime: 50 * 60_000, queryFn: async () => { const { data, error } = await supabase.storage.from('profile-photos').createSignedUrl(photoPath!, 3600); if (error) throw error; return data.signedUrl; } });
  const fetching = useIsFetching();
  const minutes = query.data?.lock_minutes ?? 0;
  const lastActivity = useRef(0);
  const it = lang === 'it';

  useEffect(() => {
    try {
      const value: unknown = JSON.parse(sessionStorage.getItem(lockKey) ?? 'null');
      if (value && typeof value === 'object' && 'id' in value && 'email' in value && 'minutes' in value && typeof value.id === 'string' && typeof value.email === 'string' && typeof value.minutes === 'number') setLocked({ id: value.id, email: value.email, minutes: value.minutes });
    } catch { /* Invalid state never restores an authenticated session. */ }
    lastActivity.current = Date.now();
    setRestored(true);
  }, []);

  const lock = () => {
    if (!user?.email || locked) return;
    const identity = { id: user.id, email: user.email, minutes };
    setLocked(identity);
    setError('');
    try { sessionStorage.setItem(lockKey, JSON.stringify(identity)); } catch { /* Local sign-out still protects reloads. */ }
    signingOut.current = (async () => {
      await client.cancelQueries();
      client.clear();
      await supabase.auth.signOut({ scope: 'local' });
    })();
  };

  useEffect(() => {
    if (!user || !restored || locked || minutes === 0) return;
    const activityKey = `sincro-last-activity-${user.id}`;
    try { const saved = Number(sessionStorage.getItem(activityKey)); lastActivity.current = saved > 0 ? saved : Date.now(); } catch { lastActivity.current = Date.now(); }
    const check = () => { if (inactivityExpired(lastActivity.current, Date.now(), minutes)) lock(); };
    const activity = () => { if (inactivityExpired(lastActivity.current, Date.now(), minutes)) lock(); else { lastActivity.current = Date.now(); try { sessionStorage.setItem(activityKey, String(lastActivity.current)); } catch { /* In-memory timeout remains active. */ } } };
    const visibility = () => { if (document.visibilityState === 'visible') check(); };
    const events = ['pointerdown', 'keydown', 'touchstart', 'scroll'] as const;
    events.forEach(event => window.addEventListener(event, activity, { passive: true }));
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('focus', check);
    const timer = setInterval(check, 1000);
    check();
    return () => { clearInterval(timer); events.forEach(event => window.removeEventListener(event, activity)); document.removeEventListener('visibilitychange', visibility); window.removeEventListener('focus', check); };
  }, [user?.id, minutes, restored, Boolean(locked)]);

  if (!restored) return <div className="min-h-screen bg-background" aria-label={it ? 'Caricamento sicurezza' : 'Loading security'} />;
  if (locked) return <main className="flex min-h-dvh items-center justify-center bg-background px-6">
    <div className="w-full max-w-sm space-y-6 py-10">
      <img src={logo} alt="Sincro" className="mx-auto h-20 w-20 object-contain" />
      <div className="text-center"><LockKeyhole className="mx-auto mb-4 h-6 w-6 text-finance" /><h1 className="text-2xl font-semibold">{it ? 'Sincro è bloccato' : 'Sincro is locked'}</h1><p className="mt-3 text-sm text-muted-foreground">{it ? 'Accedi nuovamente per proteggere i tuoi dati.' : 'Sign in again to protect your data.'}</p></div>
      <form className="space-y-4" onSubmit={async event => {
        event.preventDefault(); setBusy(true); setError('');
        const password = String(new FormData(event.currentTarget).get('password') ?? '');
        event.currentTarget.reset();
        try {
          await signingOut.current;
          const result = await supabase.auth.signInWithPassword({ email: locked.email, password });
          if (result.error || result.data.user?.id !== locked.id) {
            if (result.data.session) await supabase.auth.signOut({ scope: 'local' });
            throw new Error('Verification failed');
          }
          sessionStorage.removeItem(lockKey);
          sessionStorage.setItem(`sincro-last-activity-${locked.id}`, String(Date.now()));
          lastActivity.current = Date.now(); setLocked(null);
        } catch { setError(it ? 'Password non valida o connessione assente. Riprova.' : 'Invalid password or no connection. Try again.'); }
        finally { setBusy(false); }
      }}>
        <label className="block space-y-2 text-sm">{it ? 'Password dell’account' : 'Account password'}<Input autoFocus type="password" name="password" autoComplete="current-password" required maxLength={128} /></label>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <Button type="submit" className="w-full" disabled={busy}><ShieldCheck />{busy ? (it ? 'Verifica…' : 'Verifying…') : (it ? 'Sblocca' : 'Unlock')}</Button>
      </form>
      <Button variant="ghost" className="w-full" disabled={busy} onClick={async () => { setBusy(true); await signingOut.current; await client.cancelQueries(); client.clear(); await supabase.auth.signOut({scope:'local'}); sessionStorage.removeItem(lockKey); window.location.assign('/auth'); }}><LogOut />{it ? 'Altro accesso / recupera password' : 'Other sign-in / recover password'}</Button>
    </div>
  </main>;
  const hasError = client.getQueryCache().getAll().some(q => q.state.status === 'error' && q.queryKey[0] === 'foundation');
  const state = cloudState(online, Boolean(user), hasError ? 'error' : query.status, fetching > 0);
  return <ControlsContext.Provider value={{ name: query.data?.display_name ?? '', minutes, avatar: query.data?.avatar_key ?? 'sprout', photo: photo.data ?? null, state: ready ? state : 'pending', lock, refresh: async () => { await client.invalidateQueries({ queryKey: ['controls'] }); } }}>{children}</ControlsContext.Provider>;
}

export function HomeGreeting() {
  const { name } = useControls(); const { lang, t } = useI18n(); const [hour, setHour] = useState<number | null>(null);
  useEffect(() => { const update = () => setHour(new Date().getHours()); update(); const timer = setInterval(update, 30_000); window.addEventListener('focus', update); return () => { clearInterval(timer); window.removeEventListener('focus', update); }; }, []);
  return <h1 className="mb-6 break-words text-2xl font-bold sm:text-3xl">{hour === null ? t('greeting') : `${greeting(hour, lang)}${name ? `, ${name}` : ''}`}</h1>;
}

export function SecuritySettings() {
  const { minutes, refresh, lock } = useControls(); const { lang } = useI18n(); const save = useServerFn(saveLockTimeout);
  const [value, setValue] = useState(minutes); const [busy, setBusy] = useState(false); const [status, setStatus] = useState(''); const it = lang === 'it';
  useEffect(() => setValue(minutes), [minutes]);
  return <section className="space-y-5 border-t border-border pt-8">
    <h2 className="flex items-center gap-3 text-xl font-semibold"><ShieldCheck className="text-finance" />{it ? 'Sicurezza e blocco' : 'Security and lock'}</h2>
    <form className="space-y-4" onSubmit={async e => { e.preventDefault(); setBusy(true); setStatus(''); try { await save({data:value}); await refresh(); setStatus(it ? 'Preferenze salvate.' : 'Preferences saved.'); } catch { setStatus(it ? 'Salvataggio non riuscito.' : 'Could not save.'); } finally { setBusy(false); } }}>
      <label className="block space-y-2 text-sm">{it ? 'Blocco dopo inattività (anche in background)' : 'Lock after inactivity (including background)'}
        <select aria-label={it ? 'Timeout di inattività' : 'Inactivity timeout'} value={value} onChange={e => setValue(Number(e.target.value))} className="h-10 w-full rounded-md border border-input bg-background px-3">
          {[0,1,2,5,15].map(n => <option key={n} value={n}>{n === 0 ? (it ? 'Disattivato' : 'Disabled') : `${n} min`}</option>)}
        </select>
      </label>
      <p className="text-sm text-muted-foreground">{it ? 'Il blocco chiude la sessione su questo dispositivo. Per rientrare serve la password dell’account e una connessione.' : 'Locking signs out this device. Unlocking requires your account password and a connection.'}</p>
      <div className="flex flex-wrap gap-3"><Button disabled={busy} type="submit">{it ? 'Salva sicurezza' : 'Save security'}</Button><Button type="button" variant="outline" onClick={lock}><LockKeyhole />{it ? 'Blocca ora' : 'Lock now'}</Button></div>
      {status && <p role="status" className="text-sm text-muted-foreground">{status}</p>}
    </form>
    <div className="flex items-start gap-3 text-sm text-muted-foreground"><Fingerprint className="h-5 w-5 shrink-0" /><p>{it ? 'Face ID / impronta non disponibili con l’accesso Cloud attuale. Nessuna verifica biometrica viene simulata. Se usi Google, puoi rientrare da “Altro accesso”.' : 'Face ID / fingerprint are not available with the current Cloud sign-in. Biometric verification is never simulated. Google users can choose “Other sign-in”.'}</p></div>
  </section>;
}