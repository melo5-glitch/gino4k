import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Bell, User, Home, ShoppingCart, PiggyBank, HeartPulse, Sparkles, Eye, EyeOff, Menu, ShieldCheck, Receipt, Wallet, LockKeyhole } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import logo from "@/assets/sincro-logo.png";
import { Button } from '@/components/ui/button';
import { Sheet, SheetTrigger, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetClose } from '@/components/ui/sheet';
import { useControls } from '@/components/sincro/Security';
import { useAccount } from '@/lib/sincro/account';
import { ProfileAvatar } from '@/components/sincro/ProfileIdentity';
import { SincroChat } from '@/components/sincro/SincroChat';

export function Header() {
  const { t, lang, setLang, hidden, toggleHidden } = useI18n();
  const { state, lock, avatar, photo, name } = useControls();
  const { user } = useAccount();
  const it = lang === 'it';
  const status = state === 'offline' ? 'Offline' : state === 'synced' ? (it ? 'Cloud sincronizzato' : 'Cloud synchronized') : state === 'signed-out' ? (it ? 'Online · non connesso al Cloud' : 'Online · signed out') : state === 'error' ? (it ? 'Cloud non disponibile' : 'Cloud unavailable') : (it ? 'Sincronizzazione…' : 'Synchronizing…');
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <div className="flex min-w-0 items-center gap-1 sm:gap-2">
          <Sheet><SheetTrigger asChild><Button variant="ghost" size="icon" aria-label={it ? 'Apri menu' : 'Open menu'}><Menu /></Button></SheetTrigger>
            <SheetContent side="left" className="overflow-y-auto motion-reduce:animate-none">
              <SheetHeader><SheetTitle>Sincro</SheetTitle><SheetDescription>{it ? 'Il tuo spazio personale' : 'Your personal space'}</SheetDescription></SheetHeader>
              {user && <SheetClose asChild><Link to="/profilo" className="mt-6 flex items-center gap-3 rounded-lg p-2 hover:bg-surface"><ProfileAvatar avatar={avatar} photo={photo} large /><span className="min-w-0"><span className="block truncate font-semibold">{name || (it ? 'Il tuo profilo' : 'Your profile')}</span><span className="text-xs text-muted-foreground">{it ? 'Foto e avatar' : 'Photo and avatar'}</span></span></Link></SheetClose>}
              <nav aria-label={it ? 'Sezioni di servizio' : 'Service sections'} className="mt-8 space-y-2">
                {([['/',Home,t('home')],['/negozi',ShoppingCart,t('shops')],['/finanza',PiggyBank,t('finance')],['/salute',HeartPulse,t('health')],['/spese',Receipt,it?'Registro spese':'Transactions'],['/portafoglio',Wallet,it?'Conti e obiettivi':'Accounts and goals'],['/scontrini',Receipt,it?'Scontrini':'Receipts'],['/inbox',Bell,t('notifications')],['/profilo',User,t('profile')],['/sicurezza',ShieldCheck,it?'Sicurezza':'Security'],['/privacy',ShieldCheck,it?'Privacy e trasparenza':'Privacy and transparency']] as const).map(([to,Symbol,label]) => <SheetClose asChild key={to}><Button variant="ghost" asChild className="w-full justify-start"><Link to={to}><Symbol />{label}</Link></Button></SheetClose>)}
              </nav>
              {user ? <SheetClose asChild><Button variant="outline" className="mt-8 w-full" onClick={lock}><LockKeyhole />{it ? 'Blocca ora' : 'Lock now'}</Button></SheetClose> : <SheetClose asChild><Button asChild className="mt-8 w-full"><Link to="/auth">{it ? 'Accedi' : 'Sign in'}</Link></Button></SheetClose>}
            </SheetContent>
          </Sheet>
          <Button onClick={toggleHidden} variant="ghost" size="icon" aria-pressed={hidden} aria-label={hidden ? t('showBalances') : t('hideBalances')} title={hidden ? t('showBalances') : t('hideBalances')} className={hidden ? 'text-finance' : ''}>{hidden ? <EyeOff /> : <Eye />}</Button>
        <Link to="/" className="flex min-w-0 items-center gap-2.5">
          <img src={logo} alt="Sincro" className="h-9 w-9 rounded-xl object-contain" />
          <span className="hidden font-display text-lg font-bold uppercase sm:inline">Syncro</span>
        </Link>
        </div>
        <div className="flex items-center gap-2">
          <span role="status" aria-label={status} title={status} className="flex items-center gap-2 text-xs text-muted-foreground"><span className={`h-2 w-2 shrink-0 rounded-full ${state === 'synced' ? 'bg-finance' : 'bg-health'}`} /><span className="hidden md:inline">{status}</span></span>
          <div className="flex rounded-full border border-border bg-surface p-0.5 text-xs font-semibold">
            {(["it", "en"] as const).map((l) => (
              <Button variant="ghost"
                key={l}
                onClick={() => setLang(l)}
                className={`rounded-full px-2.5 py-1 uppercase transition ${lang === l ? "bg-foreground text-background" : "text-muted-foreground"}`}
              >
                {l}
              </Button>
            ))}
          </div>
          <Button asChild variant="outline" size="icon" aria-label={t('notifications')}><Link to="/inbox">
            <Bell className="h-4 w-4" />
          </Link></Button>
          <Button asChild variant="outline" size="icon" className="overflow-hidden rounded-full p-0" aria-label={user ? t('profile') : (it ? 'Accedi' : 'Sign in')}><Link to={user ? '/profilo' : '/auth'}>
            {user ? <ProfileAvatar avatar={avatar} photo={photo} /> : <User className="h-4 w-4" />}
          </Link></Button>
        </div>
      </div>
    </header>
  );
}

export function BottomBar() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const openChat = () => setOpen(true);
    window.addEventListener('sincro:open-chat', openChat);
    return () => window.removeEventListener('sincro:open-chat', openChat);
  }, []);
  const item = (to: "/" | "/negozi" | "/finanza" | "/salute", Icon: typeof Home, label: string) => (
    <Link to={to} className="flex flex-1 flex-col items-center gap-1 py-2 text-[10px] font-medium text-muted-foreground" activeProps={{ className: "text-foreground" }} activeOptions={{ exact: true }}>
      <Icon className="h-5 w-5" />
      <span className="truncate">{label}</span>
    </Link>
  );
  return (
    <>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/85 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto flex max-w-lg items-end px-2">
          {item("/", Home, t("home"))}
          {item("/negozi", ShoppingCart, t("shops"))}
          <div className="flex flex-1 flex-col items-center">
            <button onClick={() => setOpen(true)} aria-label={t("ask")} className="glow-btn -mt-6 grid h-14 w-14 place-items-center rounded-full ring-4 ring-background transition hover:scale-105 animate-pulse [animation-duration:3s]">
              <Sparkles className="h-6 w-6 text-background" />
            </button>
            <span className="py-1 text-[10px] font-semibold">{t("ask")}</span>
          </div>
          {item("/finanza", PiggyBank, t("finance"))}
          {item("/salute", HeartPulse, t("health"))}
        </div>
      </nav>
      {open && <SincroChat onClose={() => setOpen(false)} />}
    </>
  );
}

export function Page({ children }: { children: ReactNode }) {
  return <main className="mx-auto max-w-6xl px-4 pb-32 pt-6">{children}</main>;
}
