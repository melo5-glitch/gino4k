import { useRef, useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Sprout, Waves, Sun, Orbit, Upload, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAccount, useFoundation } from '@/lib/sincro/account';
import { useControls } from './Security';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { avatarKeys, validPhoto } from '@/lib/sincro/profile-rules';
import { saveIdentity, saveAutonomy, loadAutonomy } from '@/lib/sincro/profile.functions';
import { toast } from 'sonner';
const symbols = { sprout: Sprout, wave: Waves, sun: Sun, orbit: Orbit };
const tones = { sprout: 'text-finance bg-finance/10', wave: 'text-invest bg-invest/10', sun: 'text-deals bg-deals/10', orbit: 'text-health bg-health/10' };
export function ProfileAvatar({ avatar = 'sprout', photo, large = false }: { avatar?: string; photo?: string | null; large?: boolean }) {
  const key = avatarKeys.find(k => k === avatar) ?? 'sprout'; const Icon = symbols[key];
  return <span className={`inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full ${large ? 'h-20 w-20' : 'h-8 w-8'} ${tones[key]}`}>
    {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : <Icon className={large ? 'h-9 w-9' : 'h-4 w-4'} />}
  </span>;
}
export function ProfileIdentity() {
  const data = useFoundation(); const { user } = useAccount(); const controls = useControls(); const client = useQueryClient();
  const save = useServerFn(saveIdentity); const autonomy = useServerFn(saveAutonomy); const read = useServerFn(loadAutonomy);
  const { lang } = useI18n(); const it = lang === 'it'; const fileInput = useRef<HTMLInputElement>(null); const [busy, setBusy] = useState(false);
  const status = useQuery({ queryKey: ['autonomy', user?.id], queryFn: () => read(), enabled: Boolean(user), refetchInterval: 60000 });
  const refresh = async () => { await Promise.all([client.invalidateQueries({ queryKey: ['foundation'] }), controls.refresh()]); };
  const choose = async (avatar: typeof avatarKeys[number], photo: string | null) => {
    setBusy(true);
    try { await save({ data: { avatar_key: avatar, photo_path: photo } }); await refresh(); toast.success(it ? 'Profilo aggiornato' : 'Profile updated'); } catch (e) { toast.error(e instanceof Error ? e.message : 'Errore'); } finally { setBusy(false); }
  };
  return <><section className="space-y-5 border-b border-border pb-8">
    <h2 className="text-xl font-semibold">{it ? 'Immagine del profilo' : 'Profile image'}</h2>
    <div className="flex items-center gap-5"><ProfileAvatar avatar={controls.avatar} photo={controls.photo} large /><div className="flex flex-wrap gap-3">
      <Button variant="outline" disabled={busy} onClick={() => fileInput.current?.click()}><Upload />{it ? 'Carica foto' : 'Upload photo'}</Button>
      {data.profile?.photo_path && <Button variant="ghost" size="icon" aria-label={it ? 'Rimuovi foto' : 'Remove photo'} disabled={busy} onClick={() => void choose('sprout', null)}><Trash2 /></Button>}
    </div></div>
    <input ref={fileInput} type="file" className="hidden" accept="image/jpeg,image/png,image/webp" aria-label="Foto personale" onChange={async e => {
      const file = e.target.files?.[0]; e.target.value = ''; if (!file || !user) return;
      if (!validPhoto(file)) { toast.error(it ? 'Scegli JPG, PNG o WebP, massimo 5 MB.' : 'Choose JPG, PNG or WebP, up to 5 MB.'); return; }
      setBusy(true); const ext = file.type === 'image/jpeg' ? 'jpg' : file.type === 'image/png' ? 'png' : 'webp'; const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      try { const uploaded = await supabase.storage.from('profile-photos').upload(path, file, { contentType: file.type }); if (uploaded.error) throw new Error('Caricamento non riuscito.'); await save({ data: { avatar_key: 'sprout', photo_path: path } }); await refresh(); toast.success(it ? 'Foto salvata' : 'Photo saved'); }
      catch (error) { await supabase.storage.from('profile-photos').remove([path]); toast.error(error instanceof Error ? error.message : 'Errore'); } finally { setBusy(false); }
    }} />
    <div className="flex flex-wrap gap-3" role="group" aria-label="Avatar">{avatarKeys.map(key => <Button key={key} variant={data.profile?.avatar_key === key && !data.profile.photo_path ? 'outline' : 'ghost'} className="h-12 w-12 p-0" aria-label={`Avatar ${key}`} aria-pressed={data.profile?.avatar_key === key && !data.profile.photo_path} disabled={busy} onClick={() => void choose(key, null)}><ProfileAvatar avatar={key} /></Button>)}</div>
  </section><section className="space-y-4 border-b border-border pb-8">
    <div className="flex items-center justify-between gap-4"><h2 className="text-xl font-semibold">{it ? 'Suggerimenti autonomi' : 'Autonomous insights'}</h2><Switch aria-label={it ? 'Suggerimenti autonomi' : 'Autonomous insights'} checked={data.profile?.autonomous_ai ?? true} disabled={busy} onCheckedChange={async checked => { setBusy(true); try { await autonomy({ data: checked }); await refresh(); } catch { toast.error('Preferenza non salvata.'); } finally { setBusy(false); } }} /></div>
    <p className="text-sm text-muted-foreground">{it ? 'Revisione giornaliera di spese, risparmi e scorte. Suggerimenti nell’Inbox, nessun movimento automatico. Le analisi consumano crediti IA.' : 'Daily review of spending, savings and stock. Insights in your Inbox, no automatic transactions. Analyses use AI credits.'}</p>
    {(status.data?.control?.reason || status.data?.job?.error_message) && <p role="alert" className="text-sm text-destructive">{status.data.control?.reason ?? status.data.job?.error_message}</p>}
    {status.data?.job?.completed_at && <p className="text-xs text-muted-foreground">{it ? 'Ultima analisi: ' : 'Last review: '}{new Date(status.data.job.completed_at).toLocaleString(lang)}</p>}
  </section></>;
}