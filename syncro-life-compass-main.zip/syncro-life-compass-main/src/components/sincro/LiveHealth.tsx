import { useServerFn } from '@tanstack/react-start';
import { useQueryClient } from '@tanstack/react-query';
import { Ruler, Weight, Cake, Target, UtensilsCrossed } from 'lucide-react';
import { useFoundation } from '@/lib/sincro/account';
import { saveBody } from '@/lib/sincro/data.functions';
import { bmi, dailyCalories } from '@/lib/sincro/schemas';
import { useI18n } from '@/lib/i18n';
import { EditDialog } from './EditDialog';

const num = (raw: string | undefined, scale = 1) => { const v = (raw ?? '').trim().replace(',', '.'); if (!v) return null; const n = Number(v); if (!Number.isFinite(n)) throw new Error('Valore non valido'); return Math.round(n * scale); };

export function LiveBio() {
  const { lang, mask } = useI18n(); const it = lang === 'it'; const p = useFoundation().profile; const save = useServerFn(saveBody); const client = useQueryClient();
  if (!p) return null;
  const kcal = dailyCalories(p); const index = bmi(p.height_cm, p.weight_dg); const age = p.birth_year ? new Date().getFullYear() - p.birth_year : null;
  const goals: [string, string][] = it ? [['lose', 'Dimagrire'], ['keep', 'Mantenere'], ['gain', 'Massa']] : [['lose', 'Lose'], ['keep', 'Maintain'], ['gain', 'Gain']];
  const macros = kcal ? [[it ? 'Proteine' : 'Protein', Math.round(kcal * .25 / 4), 'bg-health'], [it ? 'Carboidrati' : 'Carbs', Math.round(kcal * .5 / 4), 'bg-deals'], [it ? 'Grassi' : 'Fat', Math.round(kcal * .25 / 9), 'bg-invest']] as const : [];
  return <section className="card-sincro p-5">
    <div className="mb-4 flex items-start justify-between"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-health/15 text-health"><Target className="h-4 w-4" /></span><h2 className="text-base font-semibold">{it ? 'Profilo fisico e obiettivo' : 'Body profile and goal'}</h2></div>
      <EditDialog title={it ? 'Profilo fisico' : 'Body profile'} description={it ? 'Lascia vuoto ciò che non vuoi indicare.' : 'Leave blank what you prefer not to share.'} fields={[{ name: 'height', label: it ? 'Altezza (cm)' : 'Height (cm)', value: p.height_cm?.toString() ?? '' }, { name: 'weight', label: it ? 'Peso (kg)' : 'Weight (kg)', value: p.weight_dg ? (p.weight_dg / 10).toString().replace('.', ',') : '' }, { name: 'year', label: it ? 'Anno di nascita' : 'Birth year', value: p.birth_year?.toString() ?? '' }, { name: 'goal', label: it ? 'Obiettivo' : 'Goal', value: p.diet_goal, kind: 'select', options: goals }]}
        onSave={async v => { await save({ data: { height_cm: num(v['height']), weight_dg: num(v['weight'], 10), birth_year: num(v['year']), diet_goal: (v['goal'] ?? 'keep') as 'lose' | 'keep' | 'gain' } }); await client.invalidateQueries({ queryKey: ['foundation'] }); }} /></div>
    <div className="grid grid-cols-3 gap-2">
      {([[Ruler, it ? 'Altezza' : 'Height', p.height_cm ? `${p.height_cm} cm` : '—'], [Weight, it ? 'Peso' : 'Weight', p.weight_dg ? `${(p.weight_dg / 10).toLocaleString(lang)} kg` : '—'], [Cake, it ? 'Età' : 'Age', age?.toString() ?? '—']] as const).map(([Icon, l, v]) => <div key={l} className="rounded-xl bg-surface p-3 text-center"><Icon className="mx-auto h-4 w-4 text-health" /><p className="mt-1.5 font-display text-lg font-bold tabular">{mask(v)}</p><p className="text-[10px] text-muted-foreground">{l}</p></div>)}
    </div>
    <p className="mt-3 text-xs text-muted-foreground">{it ? 'Obiettivo: ' : 'Goal: '}<span className="font-semibold text-foreground">{goals.find(g => g[0] === p.diet_goal)?.[1]}</span>{index && <> · BMI {mask(index.toLocaleString(lang))}</>}</p>
    <div className="mt-4 rounded-2xl border border-health/30 bg-health/5 p-4">
      <div className="flex items-center gap-2"><UtensilsCrossed className="h-4 w-4 text-health" /><p className="text-sm font-semibold">{it ? 'Fabbisogno stimato' : 'Estimated needs'}</p></div>
      {kcal ? <><p className="mt-2 font-display text-2xl font-bold text-health tabular">{mask(`${kcal.toLocaleString(lang)} kcal`)}</p>
        <div className="mt-3 space-y-2">{macros.map(([l, g, c]) => <div key={l}><div className="flex justify-between text-[11px]"><span className="text-muted-foreground">{l}</span><span className="font-semibold tabular">{mask(`${g} g`)}</span></div><div className="mt-1 h-1.5 overflow-hidden rounded-full bg-surface"><div className={`h-full rounded-full ${c}`} style={{ width: `${Math.min(g / 350 * 100, 100)}%` }} /></div></div>)}</div>
        <p className="mt-3 text-[11px] text-muted-foreground">{it ? 'Stima generica con attività leggera, non un consiglio medico.' : 'General estimate for light activity, not medical advice.'}</p></>
        : <p className="mt-2 text-xs text-muted-foreground">{it ? 'Inserisci altezza, peso e anno di nascita per calcolarlo.' : 'Enter height, weight and birth year to calculate it.'}</p>}
    </div>
  </section>;
}
