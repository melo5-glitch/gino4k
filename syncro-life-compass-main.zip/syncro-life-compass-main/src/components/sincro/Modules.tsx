import { useState } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import {
  ShoppingBag, MapPin, Flame, Footprints, Heart, Lightbulb, Wallet, Plus, ScanLine,
  TrendingUp, Coins, Watch, Moon, Activity, Ruler, Weight, Cake, Target, UtensilsCrossed,
  Landmark, PenLine, Briefcase, Sparkles,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";

function Title({ icon: Icon, color, title, sub }: { icon: typeof Flame; color: string; title: string; sub?: string }) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${color}`}><Icon className="h-4 w-4" /></span>
      <div>
        <h2 className="text-base font-semibold">{title}</h2>
        {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
      </div>
    </div>
  );
}

export function GroceryModule() {
  const { t, mask, hidden } = useI18n();
  const items = [
    { n: "Latte intero 1L", a: 1.49, b: 1.19 },
    { n: "Petto di pollo 1kg", a: 8.9, b: 4.99 },
    { n: "Pasta 500g ×4", a: 4.4, b: 3.6 },
    { n: "Verdure miste", a: 5.2, b: 3.9 },
  ];
  return (
    <section className="card-sincro p-5 lg:col-span-2">
      <Title icon={ShoppingBag} color="bg-deals/15 text-deals" title={t("eveningTitle")} sub={t("eveningSub")} />
      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-finance/30 bg-finance/10 p-5">
          <p className="text-xs text-muted-foreground">{t("savedMonth")}</p>
          <p className="mt-1 font-display text-5xl font-bold text-finance tabular">{mask("84,50 €")}</p>
          <div className={`mt-4 h-1.5 overflow-hidden rounded-full bg-surface ${hidden ? "invisible" : ""}`}><div className="h-full w-[68%] rounded-full bg-finance" /></div>
          <p className="mt-2 text-xs text-muted-foreground">{mask("68% → 125 €")}</p>
        </div>
        <div className="rounded-2xl border border-deals/30 bg-deals/5 p-4">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="font-semibold">{t("optimized")}</span>
            <span className="rounded-full bg-deals/15 px-2 py-0.5 font-semibold text-deals">A vs B</span>
          </div>
          <div className="space-y-1.5 text-xs">
            {items.map((i) => (
              <div key={i.n} className="flex items-center justify-between">
                <span className="text-muted-foreground">{i.n}</span>
                <span className="tabular"><span className="text-muted-foreground line-through">{mask(i.a.toFixed(2))}</span> <span className="ml-1 font-semibold text-foreground">{mask(i.b.toFixed(2))}</span></span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-sm">
            <span>{t("estSaving")}</span>
            <span className="font-bold text-deals tabular">{mask("-12,40 €")}</span>
          </div>
        </div>
      </div>
      <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-deals py-3 text-sm font-semibold text-background transition hover:brightness-110">
        <MapPin className="h-4 w-4" /> {t("findDeals")}
      </button>
    </section>
  );
}

function Ring({ value, max }: { value: number; max: number }) {
  const r = 34, c = 2 * Math.PI * r, p = Math.min(value / max, 1);
  return (
    <svg viewBox="0 0 80 80" className="h-20 w-20 -rotate-90">
      <circle cx="40" cy="40" r={r} fill="none" stroke="var(--surface)" strokeWidth="8" />
      <circle cx="40" cy="40" r={r} fill="none" stroke="var(--health)" strokeWidth="8" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - p)} />
    </svg>
  );
}

export function HealthModule() {
  const { t, mask, hidden } = useI18n();
  return (
    <section className="card-sincro p-5">
      <div className="flex items-start justify-between">
        <Title icon={Flame} color="bg-health/15 text-health" title={t("healthTitle")} />
        <span className="flex items-center gap-1 rounded-full bg-health/10 px-2 py-1 text-[10px] font-semibold text-health"><Watch className="h-3 w-3" />{t("synced")}</span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl bg-surface p-3">
          <Flame className="h-4 w-4 text-health" />
          <p className="mt-2 font-display text-xl font-bold tabular">{mask("2.140")}</p>
          <p className="text-[10px] text-muted-foreground">{t("kcal")} · kcal</p>
        </div>
        <div className="relative grid place-items-center rounded-xl bg-surface p-2">
          {!hidden && <Ring value={8432} max={10000} />}
          <div className="absolute inset-0 grid place-items-center text-center">
            <div><Footprints className="mx-auto h-3 w-3 text-health" /><p className="text-xs font-bold tabular">{mask("8.432")}</p></div>
          </div>
          <p className="text-[10px] text-muted-foreground">{t("steps")}</p>
        </div>
        <div className="rounded-xl bg-surface p-3">
          <Heart className="h-4 w-4 animate-pulse text-health" />
          <p className="mt-2 font-display text-xl font-bold tabular">{mask("72")}</p>
          <p className="text-[10px] text-muted-foreground">{t("bpm")} · BPM</p>
        </div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <div className="rounded-xl bg-surface p-3">
          <div className="flex items-center gap-1.5"><Moon className="h-4 w-4 text-invest" /><span className="text-[10px] text-muted-foreground">{t("sleep")}</span></div>
          <p className="mt-1.5 font-display text-lg font-bold tabular">{mask("7h 12m")}</p>
          <div className={`mt-2 flex h-1.5 overflow-hidden rounded-full ${hidden ? "invisible" : ""}`}>
            <div className="w-[38%] bg-invest" />
            <div className="w-[62%] bg-invest/30" />
          </div>
          <p className="mt-1 text-[10px] text-muted-foreground">{mask(`2h 45m ${t("deep")} · 4h 27m ${t("light")}`)}</p>
        </div>
        <div className="rounded-xl bg-surface p-3">
          <div className="flex items-center gap-1.5"><Activity className="h-4 w-4 text-deals" /><span className="text-[10px] text-muted-foreground">{t("stress")}</span></div>
          <p className="mt-1.5 font-display text-lg font-bold tabular">{mask("32/100")}</p>
          <div className={`mt-2 h-1.5 overflow-hidden rounded-full bg-background ${hidden ? "invisible" : ""}`}>
            <div className="h-full w-[32%] rounded-full bg-deals" />
          </div>
          <p className="mt-1 text-[10px] text-muted-foreground">{mask("Low · HRV 68ms")}</p>
        </div>
      </div>
      <div className="mt-4 flex gap-3 rounded-xl border border-health/30 bg-health/10 p-3 text-xs leading-relaxed">
        <Lightbulb className="h-4 w-4 shrink-0 text-health" />
        <p>{hidden ? mask(t("advice")) : t("advice")}</p>
      </div>
    </section>
  );
}

type Goal = "lose" | "keep" | "gain";
const macroByGoal: Record<Goal, { kcal: number; p: number; c: number; f: number }> = {
  lose: { kcal: 1850, p: 140, c: 160, f: 60 },
  keep: { kcal: 2200, p: 130, c: 240, f: 75 },
  gain: { kcal: 2750, p: 170, c: 320, f: 85 },
};

export function BioModule() {
  const { t, mask, hidden } = useI18n();
  const [goal, setGoal] = useState<Goal>("keep");
  const m = macroByGoal[goal];
  const goals: [Goal, string][] = [["lose", t("goalLose")], ["keep", t("goalKeep")], ["gain", t("goalGain")]];
  const stats = [
    { icon: Ruler, label: t("height"), value: "178 cm" },
    { icon: Weight, label: t("weight"), value: "74 kg" },
    { icon: Cake, label: t("age"), value: "32" },
  ];
  const macros = [
    { label: t("protein"), g: m.p, color: "bg-health" },
    { label: t("carbs"), g: m.c, color: "bg-deals" },
    { label: t("fat"), g: m.f, color: "bg-invest" },
  ];
  return (
    <section className="card-sincro p-5">
      <Title icon={Target} color="bg-health/15 text-health" title={t("bioTitle")} />
      <div className="grid grid-cols-3 gap-2">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl bg-surface p-3 text-center">
            <s.icon className="mx-auto h-4 w-4 text-health" />
            <p className="mt-1.5 font-display text-lg font-bold tabular">{mask(s.value)}</p>
            <p className="text-[10px] text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>
      <p className="mb-1 mt-4 text-[10px] uppercase tracking-wider text-muted-foreground">{t("goal")}</p>
      <div className="flex rounded-full border border-border bg-surface p-0.5 text-xs font-semibold">
        {goals.map(([g, label]) => (
          <button key={g} onClick={() => setGoal(g)} className={`flex-1 rounded-full px-2 py-1.5 transition ${goal === g ? "bg-health text-background" : "text-muted-foreground"}`}>{label}</button>
        ))}
      </div>
      <div className="mt-5 rounded-2xl border border-health/30 bg-health/5 p-4">
        <div className="flex items-center gap-2">
          <UtensilsCrossed className="h-4 w-4 text-health" />
          <div>
            <p className="text-sm font-semibold">{t("nutritionTitle")}</p>
            <p className="text-[10px] text-muted-foreground">{t("nutritionSub")}</p>
          </div>
        </div>
        <div className="mt-3 flex items-baseline justify-between">
          <span className="text-xs text-muted-foreground">{t("kcalTarget")}</span>
          <span className="font-display text-2xl font-bold text-health tabular">{mask(`${m.kcal.toLocaleString("it-IT")} kcal`)}</span>
        </div>
        <div className="mt-3 space-y-2">
          {macros.map((x) => (
            <div key={x.label}>
              <div className="flex justify-between text-[11px]"><span className="text-muted-foreground">{x.label}</span><span className="font-semibold tabular">{mask(`${x.g} g`)}</span></div>
              <div className={`mt-1 h-1.5 overflow-hidden rounded-full bg-surface ${hidden ? "invisible" : ""}`}>
                <div className={`h-full rounded-full ${x.color}`} style={{ width: `${Math.min((x.g / 350) * 100, 100)}%` }} />
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 flex items-start gap-1.5 rounded-lg bg-surface p-2 text-[11px] leading-relaxed text-muted-foreground">
          <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-deals" />{hidden ? mask(t("recipeTip")) : t("recipeTip")}
        </p>
      </div>
    </section>
  );
}

export function IncomeModule() {
  const { t, mask, hidden } = useI18n();
  const [mode, setMode] = useState<"bank" | "manual">("manual");
  return (
    <section className="card-sincro p-5">
      <Title icon={Briefcase} color="bg-finance/15 text-finance" title={t("incomeTitle")} sub={t("incomeSub")} />
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => setMode("bank")} className={`rounded-xl border p-3 text-left transition ${mode === "bank" ? "border-finance/50 bg-finance/10" : "border-border bg-surface"}`}>
          <Landmark className={`h-4 w-4 ${mode === "bank" ? "text-finance" : "text-muted-foreground"}`} />
          <p className="mt-1.5 text-xs font-semibold">{t("bankMode")}</p>
          <p className="text-[10px] text-muted-foreground">{t("bankModeSub")}</p>
        </button>
        <button onClick={() => setMode("manual")} className={`rounded-xl border p-3 text-left transition ${mode === "manual" ? "border-finance/50 bg-finance/10" : "border-border bg-surface"}`}>
          <PenLine className={`h-4 w-4 ${mode === "manual" ? "text-finance" : "text-muted-foreground"}`} />
          <p className="mt-1.5 text-xs font-semibold">{t("manualMode")}</p>
          <p className="text-[10px] text-muted-foreground">{t("manualModeSub")}</p>
        </button>
      </div>
      <div className="mt-4 space-y-2">
        <div className="flex items-center justify-between rounded-xl bg-surface p-3">
          <span className="text-xs text-muted-foreground">{t("salary")}</span>
          <span className="font-display text-lg font-bold tabular">{mask("2.450,00 €")}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl bg-surface p-3">
          <span className="text-xs text-muted-foreground">{t("extra")}</span>
          <span className="font-display text-lg font-bold tabular">{mask("320,00 €")}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl border border-finance/30 bg-finance/10 p-3">
          <span className="text-xs font-semibold">{t("totalIncome")}</span>
          <span className="font-display text-xl font-bold text-finance tabular">{mask("2.770,00 €")}</span>
        </div>
      </div>
    </section>
  );
}

export function BudgetModule() {
  const { t, mask, hidden } = useI18n();
  const total = 1200, spent = 815;
  return (
    <section className="card-sincro p-5">
      <Title icon={Wallet} color="bg-finance/15 text-finance" title={t("budgetTitle")} />
      <p className="font-display text-4xl font-bold tabular">{mask("385,00 €")} <span className="text-sm font-medium text-muted-foreground">{t("of")} {mask(`${total} €`)}</span></p>
      <div className={`mt-4 h-2.5 overflow-hidden rounded-full bg-surface ${hidden ? "invisible" : ""}`} >
        <div className="h-full rounded-full bg-finance" style={{ width: `${((total - spent) / total) * 100}%` }} />
      </div>
      <div className="mt-4 flex items-center justify-between rounded-xl bg-surface p-3">
        <span className="text-xs text-muted-foreground">{t("availableToday")}</span>
        <span className="font-display text-lg font-bold text-finance tabular">{mask("35,00 €")}</span>
      </div>
      <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-finance/40 bg-finance/10 py-3 text-sm font-semibold text-finance transition hover:bg-finance/20">
        <Plus className="h-4 w-4" />{t("addExpense")}<ScanLine className="h-4 w-4" />
      </button>
    </section>
  );
}

const profiles = {
  low: {
    growth: 0.004,
    alloc: [["Obbligazioni", 65], ["Azioni ETF", 25], ["Liquidità", 10]],
    etf: [
      { n: "iShares Core Global Aggregate Bond", p: 40, y: 2.1 },
      { n: "Obbligazioni Governative EU", p: 25, y: 2.8 },
      { n: "Vanguard VWCE All-World", p: 25, y: 7.4 },
      { n: "Oro Fisico (Invesco ETC)", p: 10, y: 5.2 },
    ],
  },
  mid: {
    growth: 0.008,
    alloc: [["Azioni ETF", 55], ["Obbligazioni", 35], ["Oro", 10]],
    etf: [
      { n: "Vanguard VWCE All-World", p: 35, y: 7.4 },
      { n: "iShares Core MSCI World", p: 20, y: 8.1 },
      { n: "Obbligazioni Aggregate", p: 35, y: 2.6 },
      { n: "Oro Fisico (Invesco ETC)", p: 10, y: 5.2 },
    ],
  },
  high: {
    growth: 0.014,
    alloc: [["Azioni ETF", 75], ["Emergenti", 15], ["Crypto", 10]],
    etf: [
      { n: "Vanguard VWCE All-World", p: 45, y: 7.4 },
      { n: "iShares MSCI Emerging Markets", p: 15, y: 9.3 },
      { n: "Invesco Nasdaq-100", p: 30, y: 12.6 },
      { n: "Bitcoin ETC", p: 10, y: 18.4 },
    ],
  },
} as const;
type Risk = keyof typeof profiles;

export function PacModule() {
  const { t, mask, hidden } = useI18n();
  const [risk, setRisk] = useState<Risk>("mid");
  const [years, setYears] = useState(15);
  const months = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott"];
  let v = 2900;
  const data = months.map((m, i) => {
    v = v * (1 + profiles[risk].growth + Math.sin(i * 1.7) * profiles[risk].growth) + 150;
    return { m, v: Math.round(v) };
  });
  const r = profiles[risk].growth;
  const n = years * 12;
  const projected = Math.round(4250 * Math.pow(1 + r, n) + 150 * ((Math.pow(1 + r, n) - 1) / r));
  const shades = ["var(--invest)", "color-mix(in oklab, var(--invest) 55%, transparent)", "color-mix(in oklab, var(--invest) 25%, transparent)"];
  return (
    <section className="card-sincro p-5 lg:col-span-2">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <Title icon={TrendingUp} color="bg-invest/15 text-invest" title={t("pacTitle")} />
        <div>
          <p className="mb-1 text-[10px] uppercase tracking-wider text-muted-foreground">{t("risk")}</p>
          <div className="flex rounded-full border border-border bg-surface p-0.5 text-xs font-semibold">
            {(["low", "mid", "high"] as const).map((rk) => (
              <button key={rk} onClick={() => setRisk(rk)} className={`rounded-full px-3 py-1 transition ${risk === rk ? "bg-invest text-foreground" : "text-muted-foreground"}`}>{t(rk)}</button>
            ))}
          </div>
        </div>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        <div className="relative h-48 md:col-span-2">
          {hidden ? <div className="grid h-full place-items-center text-muted-foreground" aria-label={t("hideBalances")}>****</div> : <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="pac" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--invest)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="var(--invest)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="m" axisLine={false} tickLine={false} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} />
              <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 }} formatter={(x) => [mask(`${x} €`), ""]} />
              <Area type="monotone" dataKey="v" stroke="var(--invest)" strokeWidth={2.5} fill="url(#pac)" />
            </AreaChart>
          </ResponsiveContainer>}
        </div>
        <div>
          <p className="mb-2 text-xs text-muted-foreground">{t("allocation")}</p>
          <div className={`flex h-3 overflow-hidden rounded-full ${hidden ? "invisible" : ""}`}>
            {profiles[risk].alloc.map(([nm, p], i) => <div key={nm} style={{ width: `${p}%`, background: shades[i] }} className="transition-all duration-500" />)}
          </div>
          <ul className="mt-3 space-y-1.5 text-xs">
            {profiles[risk].alloc.map(([nm, p], i) => (
              <li key={nm} className="flex items-center justify-between"><span className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: shades[i] }} />{nm}</span><span className="font-semibold tabular">{mask(`${p}%`)}</span></li>
            ))}
          </ul>
        </div>
      </div>
      <div className="mt-5 rounded-2xl border border-border bg-surface/50 p-4">
        <p className="mb-3 text-xs font-semibold">{t("etfTitle")}</p>
        <ul className="space-y-2">
          {profiles[risk].etf.map((e) => (
            <li key={e.n} className="flex items-center gap-3 text-xs">
              <span className="w-10 shrink-0 font-semibold text-invest tabular">{mask(`${e.p}%`)}</span>
              <div className="min-w-0 flex-1">
                <p className="truncate">{e.n}</p>
                <div className={`mt-1 h-1 overflow-hidden rounded-full bg-surface ${hidden ? "invisible" : ""}`}>
                  <div className="h-full rounded-full bg-invest/60 transition-all duration-500" style={{ width: `${e.p}%` }} />
                </div>
              </div>
              <span className="shrink-0 font-semibold text-finance tabular">{mask(`+${e.y.toFixed(1)}%`)} <span className="text-[9px] font-normal text-muted-foreground">{t("yieldLabel")}</span></span>
            </li>
          ))}
        </ul>
      </div>
      <div className="mt-4 rounded-2xl border border-invest/30 bg-invest/5 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs font-semibold">{t("simTitle")}</p>
          <p className="text-xs text-muted-foreground">{t("simYears")}: <span className="font-semibold text-foreground tabular">{years} {t("years")}</span></p>
        </div>
        <input
          type="range" min={1} max={40} value={years} onChange={(e) => setYears(Number(e.target.value))}
          className="mt-3 w-full accent-[var(--invest)]"
          aria-label={t("simTitle")}
        />
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{t("projected")}</span>
          <span className="font-display text-2xl font-bold text-invest tabular">{mask(`${projected.toLocaleString("it-IT")} €`)}</span>
        </div>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl bg-surface p-3"><p className="text-[11px] text-muted-foreground">{t("invested")}</p><p className="font-display text-xl font-bold tabular">{mask("4.250 €")}</p></div>
        <div className="rounded-xl bg-surface p-3"><p className="text-[11px] text-muted-foreground">{t("monthly")}</p><p className="font-display text-xl font-bold tabular">{mask("150 €/mese")}</p></div>
        <div className="rounded-xl border border-finance/30 bg-finance/10 p-3">
          <p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Coins className="h-3 w-3 text-finance" />{t("spare")}</p>
          <p className="font-display text-xl font-bold text-finance tabular">{mask("+42,80 €")}</p>
          <p className="text-[10px] text-muted-foreground">{t("spareSub")}</p>
        </div>
      </div>
    </section>
  );
}
