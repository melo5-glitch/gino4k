import { useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport, isToolUIPart, type UIMessage } from 'ai';
import { Infinity as InfinityIcon, X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAccount } from '@/lib/sincro/account';
import { loadChat } from '@/lib/sincro/data.functions';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from '@/components/ai-elements/conversation';
import { Message, MessageContent, MessageResponse } from '@/components/ai-elements/message';
import { PromptInput, PromptInputBody, PromptInputFooter, PromptInputSubmit, PromptInputTextarea } from '@/components/ai-elements/prompt-input';
import { Tool, ToolContent, ToolHeader, ToolInput, ToolOutput } from '@/components/ai-elements/tool';
import { Shimmer } from '@/components/ai-elements/shimmer';

const toolLabels: Record<string, string> = { read_overview: 'Lettura dei tuoi dati', read_shopping_list: 'Lettura lista spesa', add_shopping_item: 'Aggiunta alla lista', update_settings: 'Modifica impostazioni', create_goal: 'Nuovo obiettivo' };

export function SincroChat({ onClose }: { onClose: () => void }) {
  const { user, ready } = useAccount(); const { lang } = useI18n(); const it = lang === 'it';
  const history = useQuery({ queryKey: ['chat', user?.id], queryFn: () => loadChat(), enabled: Boolean(user), staleTime: Infinity });
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/70 backdrop-blur-sm sm:items-center" onClick={onClose}>
    <div role="dialog" aria-label={it ? 'Chiedi a Sincro' : 'Ask Sincro'} className="card-sincro flex h-[80vh] w-full max-w-xl flex-col p-4 animate-in slide-in-from-bottom-8" onClick={e => e.stopPropagation()}>
      <div className="mb-2 flex items-center justify-between">
        <h3 className="flex items-center gap-2 font-semibold"><span className="grid h-7 w-7 place-items-center rounded-full bg-finance/15 text-finance"><InfinityIcon className="h-4 w-4" /></span>{it ? 'Chiedi a Sincro' : 'Ask Sincro'}</h3>
        <Button variant="ghost" size="icon" onClick={onClose} aria-label={it ? 'Chiudi' : 'Close'}><X /></Button>
      </div>
      {!ready || (user && history.isPending) ? <div className="grid flex-1 place-items-center"><Shimmer>{it ? 'Carico la conversazione…' : 'Loading conversation…'}</Shimmer></div>
        : !user ? <div className="grid flex-1 place-items-center text-center"><div className="space-y-4"><p className="text-muted-foreground">{it ? 'Accedi per parlare con Sincro dei tuoi dati.' : 'Sign in to talk with Sincro about your data.'}</p><Button asChild><Link to="/auth" onClick={onClose}>{it ? 'Accedi' : 'Sign in'}</Link></Button></div></div>
        : history.isError ? <p role="alert" className="flex-1 text-sm text-destructive">{it ? 'Conversazione non disponibile.' : 'Conversation unavailable.'}</p>
        : <ChatWindow initial={history.data as unknown as UIMessage[]} userId={user.id} />}
    </div>
  </div>;
}

function ChatWindow({ initial, userId }: { initial: UIMessage[]; userId: string }) {
  const { lang, hidden } = useI18n(); const it = lang === 'it'; const client = useQueryClient(); const [text, setText] = useState('');
  const { messages, sendMessage, status, stop, error } = useChat({
    id: `sincro-${userId}`, messages: initial,
    transport: new DefaultChatTransport({
      api: '/api/chat',
      headers: async (): Promise<Record<string, string>> => { const { data } = await supabase.auth.getSession(); return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {}; },
      prepareSendMessagesRequest: ({ messages: all, headers }) => ({ ...(headers ? { headers } : {}), body: { message: all[all.length - 1] } }),
    }),
    onError: e => { let msg = e.message; try { msg = JSON.parse(e.message).error ?? msg; } catch { /* plain text */ } toast.error(msg); },
    onFinish: ({ message }) => {
      // Assistant edits can change any dashboard figure, so refresh them after tool use.
      if (message.parts.some(isToolUIPart)) { void client.invalidateQueries({ queryKey: ['foundation'] }); void client.invalidateQueries({ queryKey: ['shopping'] }); void client.invalidateQueries({ queryKey: ['controls'] }); }
      void client.invalidateQueries({ queryKey: ['chat', userId] });
    },
  });
  const busy = status === 'submitted' || status === 'streaming';
  useEffect(() => { document.querySelector<HTMLTextAreaElement>('[data-sincro-chat] textarea')?.focus(); }, [status]);
  return <div className="flex min-h-0 flex-1 flex-col" data-sincro-chat>
    <Conversation className="min-h-0 flex-1">
      <ConversationContent>
        {messages.length === 0 && <ConversationEmptyState title={it ? 'Come posso aiutarti?' : 'How can I help?'} description={it ? 'Prova: "Quanto mi resta del budget?" oppure "Aggiungi latte alla lista".' : 'Try: "How much budget is left?" or "Add milk to my list".'} />}
        {messages.map(m => <Message key={m.id} from={m.role}>
          <MessageContent className={m.role === 'user' ? 'bg-primary text-primary-foreground' : ''}>
            {m.parts.map((part, i) => {
              if (part.type === 'text') return m.role === 'assistant' ? <MessageResponse key={i}>{hidden ? part.text.replace(/\d[\d.,]*/g, '****') : part.text}</MessageResponse> : <p key={i} className="whitespace-pre-wrap">{part.text}</p>;
              if (isToolUIPart(part)) { const name = part.type === 'dynamic-tool' ? part.toolName : part.type.replace(/^tool-/, ''); return <Tool key={i} defaultOpen={false}><ToolHeader type="dynamic-tool" toolName={name} state={part.state} title={toolLabels[name] ?? name} /><ToolContent>{!hidden && <ToolInput input={part.input} />}{!hidden && <ToolOutput output={part.output} errorText={part.errorText} />}</ToolContent></Tool>; }
              return null;
            })}
          </MessageContent>
        </Message>)}
        {status === 'submitted' && <Shimmer>{it ? 'Sincro sta pensando…' : 'Sincro is thinking…'}</Shimmer>}
        {error && !busy && <p role="alert" className="text-xs text-destructive">{it ? 'Ultima risposta non riuscita. Puoi riprovare.' : 'Last reply failed. You can try again.'}</p>}
      </ConversationContent>
      <ConversationScrollButton />
    </Conversation>
    <PromptInput className="mt-3" onSubmit={({ text: value }) => { const t = (value ?? '').trim(); if (!t || busy) return; void sendMessage({ text: t }); setText(''); }}>
      <PromptInputBody><PromptInputTextarea value={text} onChange={e => setText(e.currentTarget.value)} maxLength={4000} autoFocus placeholder={it ? 'Scrivi a Sincro…' : 'Message Sincro…'} /></PromptInputBody>
      <PromptInputFooter className="justify-end"><PromptInputSubmit status={status} onStop={stop} disabled={!busy && !text.trim()} /></PromptInputFooter>
    </PromptInput>
  </div>;
}
