import { useState } from "react";
import { Package, ShoppingCart, Check, ExternalLink, Truck, MapPin, Clock, Bike, CalendarClock, Loader2 } from "lucide-react";
import { useI18n } from "@/lib/i18n";

const S = {
  it: {
    amzTitle: "Amazon Smart Basket & Household Refill", amzSub: "Prodotti casa a consumo frequente",
    left: "rimasto", pack: "Scorta consigliata", build: "Compila Carrello Amazon Automatico",
    ready: "Carrello smart pronto", items: "articoli", total: "Totale", saving: "Risparmio vs confezione singola",
    transfer: "Trasferisci su Amazon",
    delTitle: "Consegna a Domicilio & Spesa a Casa", delSub: "Salta traffico e file: ricevi la spesa a casa",
    locate: "Rileva la mia posizione", locating: "Rilevamento…", denied: "Posizione non disponibile: mostro le opzioni per Milano centro.",
    near: "Posizione rilevata", express: "Express", scheduled: "Programmata", ship: "Spedizione", free: "Gratis",
    timeSaved: "Tempo risparmiato stimato", choose: "Scegli",
  },
  en: {
    amzTitle: "Amazon Smart Basket & Household Refill", amzSub: "Frequently used household products",
    left: "left", pack: "Suggested bulk pack", build: "Build Automatic Amazon Cart",
    ready: "Smart cart ready", items: "items", total: "Total", saving: "Savings vs single pack",
    transfer: "Transfer to Amazon",
    delTitle: "Home Delivery & Groceries at Home", delSub: "Skip traffic and queues: groceries delivered",
    locate: "Detect my location", locating: "Detecting…", denied: "Location unavailable: showing options for central Milan.",
    near: "Location detected", express: "Express", scheduled: "Scheduled", ship: "Delivery", free: "Free",
    timeSaved: "Estimated time saved", choose: "Choose",
  },
};

const household = [
  { n: "Detersivo lavatrice", stock: 12, pack: "Dash Pods ×60", price: 17.9, single: 24.5, q: "dash pods 60" },
  { n: "Carta igienica", stock: 18, pack: "Regina 4 veli ×40", price: 21.99, single: 28.8, q: "carta igienica regina 40 rotoli" },
  { n: "Pastiglie lavastoviglie", stock: 25, pack: "Finish Quantum ×100", price: 19.49, single: 26.0, q: "finish quantum 100" },
  { n: "Sapone mani", stock: 64, pack: "Dove ricarica 2×1L", price: 9.9, single: 12.4, q: "dove sapone ricarica" },
  { n: "Sacchi spazzatura", stock: 80, pack: "Domopak ×120", price: 8.5, single: 10.2, q: "sacchi spazzatura domopak" },
];

const eur = (n: number) => `${n.toFixed(2).replace(".", ",")} €`;

export function AmazonModule() {
  const { lang, mask, hidden } = useI18n();
  const s = S[lang];
  const [built, setBuilt] = useState(false);
  const low = household.filter((h) => h.stock < 30);
  const total = low.reduce((a, h) => a + h.price, 0);
  const saving = low.reduce((a, h) => a + h.single - h.price, 0);
  const url = `https://www.amazon.it/s?k=${encodeURIComponent(low.map((h) => h.q).join(" | "))}`;
  return (
    <section className="card-sincro p-5 lg:col-span-2">
      <div className="mb-4 flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-deals/15 text-deals"><Package className="h-4 w-4" /></span>
        <div><h2 className="text-base font-semibold">{s.amzTitle}</h2><p className="text-xs text-muted-foreground">{s.amzSub}</p></div>
      </div>
      <ul className="space-y-2">
        {household.map((h) => {
          const isLow = h.stock < 30;
          return (
            <li key={h.n} className="rounded-xl bg-surface p-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold">{h.n}</span>
                <span className={`tabular ${isLow ? "text-health" : "text-muted-foreground"}`}>{mask(`${h.stock}% ${s.left}`)}</span>
              </div>
              <div className={`mt-2 h-1.5 overflow-hidden rounded-full bg-background ${hidden ? "invisible" : ""}`}>
                <div className={`h-full rounded-full ${isLow ? "bg-health" : "bg-finance"}`} style={{ width: `${h.stock}%` }} />
              </div>
              {isLow && <p className="mt-1.5 text-[10px] text-muted-foreground">{s.pack}: <span className="text-foreground">{h.pack}</span> · {mask(eur(h.price))}</p>}
            </li>
          );
        })}
      </ul>
      {!built ? (
        <button onClick={() => setBuilt(true)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-deals py-3 text-sm font-semibold text-background transition hover:brightness-110">
          <ShoppingCart className="h-4 w-4" /> {s.build}
        </button>
      ) : (
        <div className="mt-4 rounded-2xl border border-deals/30 bg-deals/5 p-4">
          <p className="flex items-center gap-2 text-sm font-semibold"><Check className="h-4 w-4 text-finance" />{s.ready} · {low.length} {s.items}</p>
          <div className="mt-2 flex justify-between text-xs"><span className="text-muted-foreground">{s.total}</span><span className="font-bold tabular">{mask(eur(total))}</span></div>
          <div className="mt-1 flex justify-between text-xs"><span className="text-muted-foreground">{s.saving}</span><span className="font-bold text-finance tabular">{mask(`-${eur(saving)}`)}</span></div>
          <a href={url} target="_blank" rel="noreferrer" className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-deals py-2.5 text-sm font-semibold text-background hover:brightness-110">
            {s.transfer} <ExternalLink className="h-4 w-4" />
          </a>
        </div>
      )}
    </section>
  );
}

export function DeliveryModule() {
  const { lang, mask, hidden } = useI18n();
  const s = S[lang];
  const [state, setState] = useState<"idle" | "loading" | "ok" | "denied">("idle");
  const [coords, setCoords] = useState<string>("");
  const locate = () => {
    setState("loading");
    if (!navigator.geolocation) return setState("denied");
    navigator.geolocation.getCurrentPosition(
      (p) => { setCoords(`${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}`); setState("ok"); },
      () => setState("denied"),
      { timeout: 8000 },
    );
  };
  const options = [
    { n: "Glovo Market", icon: Bike, kind: s.express, eta: "30–40 min", fee: 2.9, saved: "55 min" },
    { n: "Esselunga a Casa", icon: CalendarClock, kind: s.scheduled, eta: "Oggi 19:00–20:00", fee: 0, saved: "70 min" },
    { n: "Carrefour Sprint", icon: Bike, kind: s.express, eta: "45–60 min", fee: 3.9, saved: "50 min" },
    { n: "Amazon Fresh", icon: Truck, kind: s.scheduled, eta: "Domani 9:00–11:00", fee: 3.49, saved: "65 min" },
  ];
  return (
    <section className="card-sincro p-5 lg:col-span-2">
      <div className="mb-4 flex items-start gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-finance/15 text-finance"><Truck className="h-4 w-4" /></span>
        <div><h2 className="text-base font-semibold">{s.delTitle}</h2><p className="text-xs text-muted-foreground">{s.delSub}</p></div>
      </div>
      {state === "idle" || state === "loading" ? (
        <button onClick={locate} disabled={state === "loading"} className="flex w-full items-center justify-center gap-2 rounded-xl border border-finance/40 bg-finance/10 py-3 text-sm font-semibold text-finance hover:bg-finance/20">
          {state === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
          {state === "loading" ? s.locating : s.locate}
        </button>
      ) : (
        <>
          <p className="mb-3 flex items-center gap-2 rounded-xl bg-surface p-2.5 text-xs text-muted-foreground">
            <MapPin className="h-3.5 w-3.5 text-finance" />{state === "ok" ? `${s.near}: ${mask(coords)}` : s.denied}
          </p>
          <ul className="grid gap-2 sm:grid-cols-2">
            {options.map((o) => (
              <li key={o.n} className="rounded-xl border border-border bg-surface p-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm font-semibold"><o.icon className="h-4 w-4 text-finance" />{o.n}</span>
                  <span className="rounded-full bg-finance/10 px-2 py-0.5 text-[10px] font-semibold text-finance">{o.kind}</span>
                </div>
                <div className="mt-2 flex justify-between text-xs">
                  <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-3 w-3" />{o.eta}</span>
                  <span className="tabular">{s.ship}: <b>{o.fee === 0 ? s.free : mask(eur(o.fee))}</b></span>
                </div>
                <p className="mt-1 text-[10px] text-muted-foreground">{s.timeSaved}: <span className="text-deals">{o.saved}</span></p>
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}
