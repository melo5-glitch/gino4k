/**
 * Vault privato cifrato lato client.
 *
 * - Il namespace di archiviazione è un hash SHA-256 dello user_id (mai l’id in chiaro).
 * - I dati sono cifrati con AES-GCM 256; la chiave deriva dalla passphrase (PBKDF2).
 * - La passphrase e la chiave NON vengono mai salvate.
 *
 * Importante: la cifratura lato client è una difesa in profondità. L’isolamento reale
 * tra utenti e spazi condivisi va applicato anche sul server (autorizzazione per user_id,
 * row-level security) archiviando solo il testo cifrato (`VaultEnvelope`).
 */

export interface VaultEnvelope {
  v: 1;
  salt: string; // base64
  iv: string; // base64
  ct: string; // base64
}

export interface VaultStorage {
  load(namespace: string): Promise<VaultEnvelope | null>;
  save(namespace: string, envelope: VaultEnvelope): Promise<void>;
}

const enc = new TextEncoder();
const dec = new TextDecoder();
const PBKDF2_ITERATIONS = 310_000;

export const toB64 = (bytes: Uint8Array): string => {
  let s = '';
  bytes.forEach(b => (s += String.fromCharCode(b)));
  return btoa(s);
};

export const fromB64 = (b64: string): Uint8Array => Uint8Array.from(atob(b64), c => c.charCodeAt(0));

export async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Namespace opaco per l’utente: `syncro:vault:v1:<sha256(user_id)>`. */
export async function vaultNamespace(userId: string): Promise<string> {
  return `syncro:vault:v1:${await sha256Hex(`syncro-vault|${userId}`)}`;
}

export async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const material = await crypto.subtle.importKey('raw', enc.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

export async function encryptJSON(key: CryptoKey, data: unknown): Promise<{ iv: string; ct: string }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(data)));
  return { iv: toB64(iv), ct: toB64(new Uint8Array(ct)) };
}

/** Lancia un errore se la chiave è errata o i dati sono stati alterati (tag GCM). */
export async function decryptJSON<T>(key: CryptoKey, payload: { iv: string; ct: string }): Promise<T> {
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(payload.iv) }, key, fromB64(payload.ct));
  return JSON.parse(dec.decode(plain)) as T;
}

/** Archiviazione predefinita (solo testo cifrato). Sostituibile con un’API server. */
export const localVaultStorage: VaultStorage = {
  async load(ns) {
    const raw = localStorage.getItem(ns);
    return raw ? (JSON.parse(raw) as VaultEnvelope) : null;
  },
  async save(ns, env) {
    localStorage.setItem(ns, JSON.stringify(env));
  },
};
