import React, { useMemo, useState } from 'react';

export interface CartItem {
  id: string;
  name: string;
  priceCents: number; // importi in centesimi: niente errori di virgola mobile
  selected: boolean;
  category: string;
}

const eur = new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' });
const formatEur = (cents: number) => eur.format(cents / 100);

const INITIAL_ITEMS: CartItem[] = [
  { id: '1', name: 'Pasta Integrale 1kg', priceCents: 180, selected: true, category: 'Dispensa' },
  { id: '2', name: 'Olio Extravergine 1L', priceCents: 850, selected: true, category: 'Dispensa' },
  { id: '3', name: 'Detersivo Lavatrice', priceCents: 620, selected: true, category: 'Casa' },
  { id: '4', name: 'Carta Igienica 12 pz', priceCents: 490, selected: true, category: 'Casa' },
];

interface SyncroCartProps {
  items?: CartItem[];
  onTotalChange?: (totalCents: number) => void;
  /** Id degli articoli attualmente selezionati (la callback deve essere stabile, es. useCallback). */
  onSelectionChange?: (selectedIds: string[]) => void;
}

export default function SyncroCart({ items: initialItems = INITIAL_ITEMS, onTotalChange, onSelectionChange }: SyncroCartProps) {
  const [isOpen, setIsOpen] = useState(false);
  // Spunta inversa: tutti gli articoli partono selezionati
  const [items, setItems] = useState<CartItem[]>(initialItems);

  const toggleItem = (id: string) =>
    setItems(prev => prev.map(i => (i.id === id ? { ...i, selected: !i.selected } : i)));

  const { totalCents, activeCount } = useMemo(() => {
    const active = items.filter(i => i.selected);
    return {
      totalCents: active.reduce((acc, i) => acc + i.priceCents, 0),
      activeCount: active.length,
    };
  }, [items]);

  // Notifica opzionale al genitore (es. dashboard)
  React.useEffect(() => {
    onTotalChange?.(totalCents);
  }, [totalCents, onTotalChange]);

  React.useEffect(() => {
    onSelectionChange?.(items.filter(i => i.selected).map(i => i.id));
  }, [items, onSelectionChange]);

  return (
    <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-100 max-w-md mx-auto my-4 backdrop-blur-md">
      {/* Header a tendina */}
      <button
        type="button"
        onClick={() => setIsOpen(o => !o)}
        aria-expanded={isOpen}
        aria-controls="syncro-cart-panel"
        className="w-full flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 transition-colors hover:bg-slate-800/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
      >
        <div className="flex items-center gap-2">
          <span className="text-blue-400 text-base" aria-hidden="true">🛒</span>
          <div className="text-left">
            <h4 className="text-xs font-semibold text-slate-200">Carrello e dispensa</h4>
            <span className="text-[10px] text-slate-400">
              {activeCount} di {items.length} articoli attivi
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-blue-400 tabular-nums">{formatEur(totalCents)}</span>
          <span
            aria-hidden="true"
            className={`text-xs text-slate-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
          >
            ▼
          </span>
        </div>
      </button>

      {/* Pannello espandibile */}
      {isOpen && (
        <div id="syncro-cart-panel" className="mt-3 space-y-2 pt-2 border-t border-slate-800">
          <p className="text-[11px] text-slate-400 px-1">
            Tocca un prodotto per escluderlo. Il totale si aggiorna subito.
          </p>

          <ul className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {items.map(item => (
              <li key={item.id}>
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={item.selected}
                  onClick={() => toggleItem(item.id)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-lg border text-left transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                    item.selected
                      ? 'bg-slate-950/80 border-blue-500/40 text-slate-200'
                      : 'bg-slate-950/20 border-slate-800/40 text-slate-500 line-through'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center text-[10px] border ${
                        item.selected ? 'bg-blue-600 border-blue-500 text-white' : 'border-slate-700 bg-slate-900'
                      }`}
                    >
                      {item.selected ? '✓' : ''}
                    </div>
                    <div>
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-[10px] opacity-70">{item.category}</div>
                    </div>
                  </div>
                  <div className="text-xs font-semibold tabular-nums">{formatEur(item.priceCents)}</div>
                </button>
              </li>
            ))}
          </ul>

          <div className="pt-2 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-800/60">
            <span>Valuta: euro (€)</span>
            <span className="text-emerald-400 font-medium">Sincronizzato in tempo reale</span>
          </div>
        </div>
      )}
    </div>
  );
}
