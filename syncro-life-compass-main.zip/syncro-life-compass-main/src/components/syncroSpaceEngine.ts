import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { newId } from './syncroTypes';
import type { Member, SharedItem, SpaceSnapshot } from './syncroTypes';

/* ======================================================================
 * Operazioni (modello di dominio) — pure e deterministiche
 * ==================================================================== */

interface OpBase {
  opId: string;
  authorId: string;
  ts: number;
}
export type Op =
  | (OpBase & { kind: 'add'; item: SharedItem })
  | (OpBase & { kind: 'toggle'; itemId: string })
  | (OpBase & { kind: 'remove'; itemId: string });

/**
 * Applica un’operazione a uno snapshot. Non tocca `version`: la assegna il server.
 * Le operazioni su elementi inesistenti sono no-op, quindi l’applicazione è sicura
 * anche dopo un rebase su uno stato più recente.
 */
export function applyOp(s: SpaceSnapshot, op: Op): SpaceSnapshot {
  let items = s.items;
  let text: string;

  switch (op.kind) {
    case 'add': {
      if (items.some(i => i.id === op.item.id)) return s;
      items = [...items, op.item];
      text = `ha aggiunto “${op.item.name}”`;
      break;
    }
    case 'toggle': {
      const target = items.find(i => i.id === op.itemId);
      if (!target) return s;
      items = items.map(i => (i.id === op.itemId ? { ...i, done: !i.done } : i));
      text = `ha ${target.done ? 'riattivato' : 'completato'} “${target.name}”`;
      break;
    }
    case 'remove': {
      const target = items.find(i => i.id === op.itemId);
      if (!target) return s;
      items = items.filter(i => i.id !== op.itemId);
      text = `ha rimosso “${target.name}”`;
      break;
    }
  }

  const activity = [{ id: op.opId, authorId: op.authorId, text, ts: op.ts }, ...s.activity].slice(0, 30);
  return { ...s, items, activity };
}

/* ======================================================================
 * Protocollo client ⇄ server
 * ==================================================================== */

export type ConnStatus = 'connecting' | 'online' | 'offline';
export type PushPlatform = 'FCM' | 'APNs';

export type ClientMsg =
  | { type: 'auth'; token: string }
  | { type: 'op'; op: Op; baseVersion: number }
  | { type: 'resync' }
  | { type: 'notify' };

export type ServerMsg =
  | { type: 'hello'; snapshot: SpaceSnapshot }
  | { type: 'snapshot'; snapshot: SpaceSnapshot }
  | { type: 'ack'; opId: string; version: number }
  | { type: 'conflict'; opId: string; snapshot: SpaceSnapshot }
  // Il server NON deve inviare `remote` all’autore dell’operazione (riceve `ack`).
  | { type: 'remote'; op: Op; version: number }
  | { type: 'push_sim'; title: string; body: string; platform: PushPlatform };

export interface SpaceTransport {
  connect(onMessage: (m: ServerMsg) => void, onStatus: (s: ConnStatus) => void): void;
  send(m: ClientMsg): void;
  close(): void;
}

export function detectPushPlatform(): PushPlatform {
  return /iPhone|iPad|iPod/.test(navigator.userAgent) ? 'APNs' : 'FCM';
}

/* ======================================================================
 * Trasporto WebSocket reale (riconnessione con backoff esponenziale)
 * ==================================================================== */

export function createWebSocketTransport(url: string, spaceId: string, getToken?: () => string | undefined): SpaceTransport {
  let ws: WebSocket | null = null;
  let closed = false;
  let attempt = 0;
  let timer: number | undefined;
  let onMsg: (m: ServerMsg) => void = () => {};
  let onStatus: (s: ConnStatus) => void = () => {};

  const open = () => {
    onStatus('connecting');
    ws = new WebSocket(`${url}?space=${encodeURIComponent(spaceId)}`);
    ws.onopen = () => {
      attempt = 0;
      const token = getToken?.();
      if (token) ws?.send(JSON.stringify({ type: 'auth', token } satisfies ClientMsg));
      onStatus('online');
    };
    ws.onmessage = e => {
      try {
        onMsg(JSON.parse(String(e.data)) as ServerMsg);
      } catch {
        /* messaggio malformato: ignorato */
      }
    };
    ws.onerror = () => ws?.close();
    ws.onclose = () => {
      onStatus('offline');
      if (!closed) timer = window.setTimeout(open, Math.min(1000 * 2 ** attempt++, 15_000));
    };
  };

  return {
    connect(m, s) {
      onMsg = m;
      onStatus = s;
      closed = false;
      open();
    },
    send(m) {
      if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(m));
    },
    close() {
      closed = true;
      window.clearTimeout(timer);
      ws?.close();
    },
  };
}

/* ======================================================================
 * Trasporto simulato (demo/sviluppo): server in memoria con OCC reale
 * e un membro "fantasma" che modifica la lista, per provocare conflitti.
 * ==================================================================== */

export function createDemoSnapshot(): SpaceSnapshot {
  return {
    spaceId: 'demo-space',
    name: 'Casa Catania',
    version: 1,
    members: [
      { id: 'u1', name: 'Marco Rossi', role: 'admin', color: '#2563eb', intolerances: [], likes: ['pasta', 'pesce'], dislikes: [] },
      { id: 'u2', name: 'Giulia Bianchi', role: 'member', color: '#db2777', intolerances: ['lattosio'], likes: ['verdure'], dislikes: ['coriandolo'] },
      { id: 'u3', name: 'Luca Verdi', role: 'member', color: '#059669', intolerances: ['glutine'], likes: ['carne'], dislikes: ['olive'] },
    ],
    items: [
      { id: 'i1', name: 'Pasta integrale', done: false, addedBy: 'u1' },
      { id: 'i2', name: 'Latte intero', done: false, addedBy: 'u2' },
      { id: 'i3', name: 'Detersivo lavatrice', done: true, addedBy: 'u1' },
    ],
    activity: [],
  };
}

export function createMockTransport(initial: SpaceSnapshot, currentUserId: string, platform: PushPlatform = 'FCM'): SpaceTransport {
  let server: SpaceSnapshot = structuredClone(initial);
  let onMsg: (m: ServerMsg) => void = () => {};
  const timeouts: number[] = [];
  let interval: number | undefined;
  const later = (fn: () => void, ms = 120) => timeouts.push(window.setTimeout(fn, ms));

  const peerPool = ['Pomodori', 'Riso', 'Yogurt greco', 'Spinaci'];
  const peerAct = () => {
    const peers = server.members.filter(m => m.id !== currentUserId);
    const peer = peers[Math.floor(Math.random() * peers.length)];
    if (!peer) return;
    const base = { opId: newId(), authorId: peer.id, ts: Date.now() };
    const op: Op =
      server.items.length > 0 && Math.random() < 0.6
        ? { ...base, kind: 'toggle', itemId: server.items[Math.floor(Math.random() * server.items.length)].id }
        : { ...base, kind: 'add', item: { id: newId(), name: peerPool[Math.floor(Math.random() * peerPool.length)], done: false, addedBy: peer.id } };
    const next = applyOp(server, op);
    if (next === server) return;
    server = { ...next, version: server.version + 1 };
    onMsg({ type: 'remote', op, version: server.version });
    onMsg({ type: 'push_sim', title: peer.name, body: `${peer.name} ${server.activity[0]?.text ?? 'ha aggiornato la lista'}`, platform });
  };

  return {
    connect(m, s) {
      onMsg = m;
      s('connecting');
      later(() => {
        s('online');
        m({ type: 'hello', snapshot: server });
      }, 300);
      interval = window.setInterval(peerAct, 9000);
    },
    send(msg) {
      switch (msg.type) {
        case 'op':
          later(() => {
            // Autorizzazione e controllo di versione sono SEMPRE server-side.
            if (msg.baseVersion !== server.version) {
              onMsg({ type: 'conflict', opId: msg.op.opId, snapshot: server });
              return;
            }
            server = { ...applyOp(server, msg.op), version: server.version + 1 };
            onMsg({ type: 'ack', opId: msg.op.opId, version: server.version });
          });
          break;
        case 'resync':
          later(() => onMsg({ type: 'snapshot', snapshot: server }));
          break;
        case 'notify':
          later(() =>
            onMsg({
              type: 'push_sim',
              title: server.name,
              body: `Avviso consegnato a ${server.members.length - 1} membri (simulato)`,
              platform,
            }),
          );
          break;
        default:
          break;
      }
    },
    close() {
      timeouts.splice(0).forEach(window.clearTimeout);
      window.clearInterval(interval);
    },
  };
}

/* ======================================================================
 * Inviti: codice alfanumerico sicuro + link condivisibile
 * (la validazione, la scadenza e l’uso singolo vanno applicati dal server)
 * ==================================================================== */

// Senza caratteri ambigui (I, L, O, 0, 1)
const INVITE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const INVITE_RE = new RegExp(`^[${INVITE_ALPHABET}]{5}-[${INVITE_ALPHABET}]{5}$`);

export function generateInviteCode(length = 10): string {
  const limit = 256 - (256 % INVITE_ALPHABET.length); // rejection sampling: nessun bias da modulo
  let out = '';
  while (out.length < length) {
    const buf = new Uint8Array(length * 2);
    crypto.getRandomValues(buf);
    for (const b of buf) {
      if (b < limit && out.length < length) out += INVITE_ALPHABET[b % INVITE_ALPHABET.length];
    }
  }
  const half = length / 2;
  return `${out.slice(0, half)}-${out.slice(half)}`;
}

export function normalizeInviteCode(input: string): string {
  const raw = input.toUpperCase().replace(/[^A-Z0-9]/g, '');
  return raw.length === 10 ? `${raw.slice(0, 5)}-${raw.slice(5)}` : input.toUpperCase().trim();
}

export const isValidInviteCode = (code: string): boolean => INVITE_RE.test(code);

export interface Invite {
  code: string;
  link: string;
  expiresAt: number;
}

export function createInvite(origin: string, ttlHours = 48): Invite {
  const code = generateInviteCode();
  return { code, link: `${origin}/join/${code}`, expiresAt: Date.now() + ttlHours * 3_600_000 };
}

/* ======================================================================
 * Hook: stato ottimistico + OCC
 *
 * - `confirmed` è lo stato autorevole del server.
 * - `pending` è la coda locale di operazioni non ancora confermate.
 * - La vista = pending applicato sopra confirmed (aggiornamento ottimistico).
 * - Un’operazione alla volta è "in volo", con `baseVersion`. Se il server
 *   risponde `conflict`, si adotta il suo snapshot e la stessa operazione
 *   viene riapplicata (rebase) e rinviata con la nuova versione.
 * ==================================================================== */

export interface PushNotice {
  id: string;
  title: string;
  body: string;
  platform: PushPlatform | 'local';
  ts: number;
}

interface State {
  confirmed: SpaceSnapshot | null;
  pending: Op[];
  conflicts: number;
  epoch: number; // incrementa quando conviene rinviare l’operazione in testa
  pushes: PushNotice[];
}

type Action =
  | { type: 'snapshot'; snapshot: SpaceSnapshot }
  | { type: 'enqueue'; op: Op }
  | { type: 'ack'; opId: string; version: number }
  | { type: 'conflict'; snapshot: SpaceSnapshot }
  | { type: 'remote'; op: Op; version: number }
  | { type: 'drop'; opId: string }
  | { type: 'push'; notice: PushNotice }
  | { type: 'dismissPush'; id: string };

function reducer(state: State, a: Action): State {
  switch (a.type) {
    case 'snapshot':
      return { ...state, confirmed: a.snapshot, epoch: state.epoch + 1 };
    case 'enqueue':
      return { ...state, pending: [...state.pending, a.op] };
    case 'ack': {
      if (!state.confirmed) return state;
      const op = state.pending.find(o => o.opId === a.opId);
      const base = op ? applyOp(state.confirmed, op) : state.confirmed;
      return { ...state, confirmed: { ...base, version: a.version }, pending: state.pending.filter(o => o.opId !== a.opId) };
    }
    case 'conflict':
      return { ...state, confirmed: a.snapshot, conflicts: state.conflicts + 1, epoch: state.epoch + 1 };
    case 'remote':
      return state.confirmed ? { ...state, confirmed: { ...applyOp(state.confirmed, a.op), version: a.version } } : state;
    case 'drop':
      return { ...state, pending: state.pending.filter(o => o.opId !== a.opId) };
    case 'push':
      return { ...state, pushes: [a.notice, ...state.pushes].slice(0, 5) };
    case 'dismissPush':
      return { ...state, pushes: state.pushes.filter(p => p.id !== a.id) };
  }
}

const MAX_RETRIES = 5;

export function useSharedSpace(transport: SpaceTransport, currentUserId: string) {
  const [state, dispatch] = useReducer(reducer, { confirmed: null, pending: [], conflicts: 0, epoch: 0, pushes: [] });
  const [status, setStatus] = useState<ConnStatus>('connecting');
  const inflight = useRef<string | null>(null);
  const versionRef = useRef(0);
  const attempts = useRef<Record<string, number>>({});

  useEffect(() => {
    const handle = (msg: ServerMsg) => {
      switch (msg.type) {
        case 'hello':
        case 'snapshot':
          inflight.current = null;
          versionRef.current = msg.snapshot.version;
          dispatch({ type: 'snapshot', snapshot: msg.snapshot });
          break;
        case 'ack':
          inflight.current = null;
          versionRef.current = msg.version;
          dispatch({ type: 'ack', opId: msg.opId, version: msg.version });
          break;
        case 'conflict': {
          inflight.current = null;
          versionRef.current = msg.snapshot.version;
          const n = (attempts.current[msg.opId] = (attempts.current[msg.opId] ?? 0) + 1);
          dispatch({ type: 'conflict', snapshot: msg.snapshot });
          if (n > MAX_RETRIES) {
            dispatch({ type: 'drop', opId: msg.opId });
            dispatch({
              type: 'push',
              notice: { id: newId(), title: 'Modifica non sincronizzata', body: 'Troppi conflitti: riprova l’operazione.', platform: 'local', ts: Date.now() },
            });
          }
          break;
        }
        case 'remote':
          if (msg.version !== versionRef.current + 1) {
            transport.send({ type: 'resync' }); // buco nella sequenza: chiede lo snapshot completo
          } else {
            versionRef.current = msg.version;
            dispatch({ type: 'remote', op: msg.op, version: msg.version });
          }
          break;
        case 'push_sim':
          dispatch({ type: 'push', notice: { id: newId(), title: msg.title, body: msg.body, platform: msg.platform, ts: Date.now() } });
          break;
      }
    };
    transport.connect(handle, s => {
      if (s !== 'online') inflight.current = null; // se cade la rete, l’operazione va rinviata
      setStatus(s);
    });
    return () => transport.close();
  }, [transport]);

  // Invio dell’operazione in testa alla coda (una alla volta)
  useEffect(() => {
    const head = state.pending[0];
    if (!head || !state.confirmed || status !== 'online') return;
    if (inflight.current === head.opId) return;
    inflight.current = head.opId;
    transport.send({ type: 'op', op: head, baseVersion: state.confirmed.version });
  }, [state.pending, state.confirmed, state.epoch, status, transport]);

  const view = useMemo(
    () => (state.confirmed ? state.pending.reduce(applyOp, state.confirmed) : null),
    [state.confirmed, state.pending],
  );

  const enqueue = useCallback((op: Op) => dispatch({ type: 'enqueue', op }), []);
  const base = useCallback(() => ({ opId: newId(), authorId: currentUserId, ts: Date.now() }), [currentUserId]);

  return {
    view,
    status,
    pushes: state.pushes,
    conflicts: state.conflicts,
    pendingCount: state.pending.length,
    addItem: useCallback(
      (name: string) => {
        const clean = name.trim().slice(0, 80);
        if (clean) enqueue({ ...base(), kind: 'add', item: { id: newId(), name: clean, done: false, addedBy: currentUserId } });
      },
      [base, enqueue, currentUserId],
    ),
    toggleItem: useCallback((itemId: string) => enqueue({ ...base(), kind: 'toggle', itemId }), [base, enqueue]),
    removeItem: useCallback((itemId: string) => enqueue({ ...base(), kind: 'remove', itemId }), [base, enqueue]),
    notifyGroup: useCallback(() => transport.send({ type: 'notify' }), [transport]),
    dismissPush: useCallback((id: string) => dispatch({ type: 'dismissPush', id }), []),
  };
}

export type { Member };
