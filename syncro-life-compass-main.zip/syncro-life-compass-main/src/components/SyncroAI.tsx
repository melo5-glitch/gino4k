import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { newId } from './syncroTypes';
import type { Member } from './syncroTypes';

/* ======================================================================
 * 1. Analisi proattiva: testo/ricette/liste × profili dei membri
 *    (basata su parole chiave: NON sostituisce la lettura delle etichette)
 * ==================================================================== */

export interface Finding {
  memberId: string;
  memberName: string;
  kind: 'intolerance' | 'dislike';
  label: string; // nome dell’intolleranza oppure il cibo sgradito
  term: string; // parola trovata nel testo
}

const INTOLERANCE_KEYWORDS: Record<string, string[]> = {
  glutine: ['glutine', 'frumento', 'grano', 'farina', 'pasta', 'pane', 'semola', 'orzo', 'farro', 'couscous', 'biscott', 'pizza', 'cracker'],
  lattosio: ['lattosio', 'latte', 'burro', 'panna', 'formaggio', 'yogurt', 'mozzarella', 'ricotta', 'parmigiano', 'besciamella', 'gelato'],
  uova: ['uovo', 'uova', 'maionese'],
  'frutta a guscio': ['noci', 'nocciol', 'mandorl', 'pistacch', 'anacard', 'pinoli'],
  arachidi: ['arachid'],
  crostacei: ['gamber', 'scampi', 'aragosta', 'granchio'],
  pesce: ['pesce', 'tonno', 'salmone', 'merluzzo', 'acciug', 'alici'],
  soia: ['soia', 'tofu', 'edamame'],
};

const SAFE_VARIANTS: Record<string, RegExp> = {
  glutine: /senza glutine|gluten ?free/,
  lattosio: /senza lattosio|delattosat|lactose ?free/,
};

const SUBSTITUTES: Record<string, string> = {
  glutine: 'versioni senza glutine certificate, riso o mais',
  lattosio: 'prodotti delattosati o bevande vegetali',
  uova: 'sostituti vegetali dell’uovo',
  'frutta a guscio': 'semi (girasole, zucca)',
};

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export function analyzeText(text: string, members: Member[]): Finding[] {
  const lines = norm(text).split(/[\n,;]+/).map(l => l.trim()).filter(Boolean);
  const out: Finding[] = [];
  const seen = new Set<string>();
  const push = (f: Finding) => {
    const key = `${f.memberId}|${f.kind}|${f.label}|${f.term}`;
    if (!seen.has(key)) {
      seen.add(key);
      out.push(f);
    }
  };

  for (const m of members) {
    for (const intolerance of m.intolerances) {
      const n = norm(intolerance);
      const key = Object.keys(INTOLERANCE_KEYWORDS).find(k => n.includes(norm(k)));
      const keywords = key ? INTOLERANCE_KEYWORDS[key] : [n];
      const safe = key ? SAFE_VARIANTS[key] : undefined;
      for (const line of lines) {
        if (safe?.test(line)) continue; // es. “latte senza lattosio”
        for (const kw of keywords) {
          if (new RegExp(`\\b${escapeRe(kw)}`).test(line)) push({ memberId: m.id, memberName: m.name, kind: 'intolerance', label: key ?? intolerance, term: kw });
        }
      }
    }
    for (const dislike of m.dislikes) {
      const d = norm(dislike);
      if (d && lines.some(l => new RegExp(`\\b${escapeRe(d)}`).test(l))) {
        push({ memberId: m.id, memberName: m.name, kind: 'dislike', label: dislike, term: dislike });
      }
    }
  }
  return out;
}

export function formatFindings(findings: Finding[]): string {
  const lines: string[] = [];
  const byMember = new Map<string, Finding[]>();
  findings.forEach(f => byMember.set(f.memberId, [...(byMember.get(f.memberId) ?? []), f]));
  byMember.forEach(list => {
    const name = list[0].memberName;
    const intol = list.filter(f => f.kind === 'intolerance');
    const dis = list.filter(f => f.kind === 'dislike');
    if (intol.length) {
      const label = [...new Set(intol.map(f => f.label))].join(', ');
      lines.push(`⚠️ ${name} (intolleranza: ${label}) — trovato: ${[...new Set(intol.map(f => f.term))].join(', ')}.`);
    }
    if (dis.length) lines.push(`ℹ️ ${name} non ama: ${[...new Set(dis.map(f => f.label))].join(', ')}.`);
  });
  if (findings.some(f => f.kind === 'intolerance')) lines.push('Controlla sempre l’etichetta: l’analisi si basa su parole chiave.');
  return lines.join('\n');
}

/* ======================================================================
 * 2. Provider IA (sostituibile con un LLM reale lato server)
 * ==================================================================== */

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'alert';
  text: string;
  ts: number;
  via?: 'text' | 'dictation' | 'voice';
}

export interface AiRequest {
  text: string;
  history: ChatMessage[];
  members: Member[];
  findings: Finding[];
}

export interface AiProvider {
  reply(req: AiRequest): Promise<string>;
}

export const localAiProvider: AiProvider = {
  async reply({ members, findings }) {
    const base = `Ho confrontato il testo con i profili di ${members.length} membri.`;
    const labels = [...new Set(findings.filter(f => f.kind === 'intolerance').map(f => f.label))];
    const tips = labels.map(l => SUBSTITUTES[l]).filter(Boolean);
    return tips.length ? `${base} Alternative possibili: ${tips.join('; ')}.` : `${base} Non emergono conflitti.`;
  },
};

/* ======================================================================
 * 3. Riconoscimento vocale (Web Speech API) e sintesi
 * ==================================================================== */

interface RecognitionResultEvent {
  resultIndex: number;
  results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }>;
}
interface Recognizer {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: RecognitionResultEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}
type RecognizerCtor = new () => Recognizer;

const getRecognizerCtor = (): RecognizerCtor | undefined => {
  const w = window as unknown as { SpeechRecognition?: RecognizerCtor; webkitSpeechRecognition?: RecognizerCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition;
};

function useSpeechRecognition(opts: { continuous: boolean; onInterim?: (t: string) => void; onFinal: (t: string) => void }) {
  const Ctor = useMemo(getRecognizerCtor, []);
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recRef = useRef<Recognizer | null>(null);
  const wantRef = useRef(false);
  const cb = useRef(opts);
  cb.current = opts;

  const start = useCallback(() => {
    if (!Ctor || wantRef.current) return;
    const rec = new Ctor();
    rec.lang = 'it-IT';
    rec.continuous = cb.current.continuous;
    rec.interimResults = true;
    rec.onresult = e => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const t = r[0].transcript;
        if (r.isFinal) cb.current.onFinal(t.trim());
        else interim += t;
      }
      if (interim) cb.current.onInterim?.(interim);
    };
    rec.onerror = e => {
      if (e.error === 'not-allowed') {
        wantRef.current = false;
        setError('Permesso microfono negato.');
      } else if (e.error !== 'no-speech' && e.error !== 'aborted') {
        setError(`Errore microfono: ${e.error}`);
      }
    };
    rec.onend = () => {
      if (wantRef.current && cb.current.continuous) {
        try {
          rec.start(); // alcuni browser chiudono la sessione dopo una pausa
        } catch {
          wantRef.current = false;
          setListening(false);
        }
      } else {
        wantRef.current = false;
        setListening(false);
      }
    };
    recRef.current = rec;
    wantRef.current = true;
    setError(null);
    try {
      rec.start();
      setListening(true);
    } catch {
      wantRef.current = false;
    }
  }, [Ctor]);

  const stop = useCallback(() => {
    wantRef.current = false;
    recRef.current?.stop();
    setListening(false);
  }, []);

  useEffect(
    () => () => {
      wantRef.current = false;
      recRef.current?.abort();
    },
    [],
  );

  return { supported: Boolean(Ctor), listening, error, start, stop };
}

function speak(text: string): Promise<void> {
  return new Promise(resolve => {
    if (!('speechSynthesis' in window)) return resolve();
    const clean = text.replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF\uFE0F]/gu, '');
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = 'it-IT';
    u.onend = () => resolve();
    u.onerror = () => resolve();
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  });
}

/* ======================================================================
 * 4. Configuratore modulare — SOLO anteprima visiva, nessun pagamento
 * ==================================================================== */

/** Interruttore di sicurezza: le transazioni sono escluse a livello di tipo e di codice. */
export const PAYMENTS_ENABLED = false as const;
export type CheckoutResult = { ok: false; reason: string };

/** Unico punto di ingresso verso un eventuale checkout: restituisce sempre un blocco. */
export function requestCheckout(): CheckoutResult {
  return { ok: false, reason: 'Anteprima: acquisti e pagamenti non sono abilitati in questa versione.' };
}

const PLAN_MODULES = [
  { id: 'ai', title: 'IA conversazionale', blurb: 'Chat testuale, dettatura e voce con avvisi su gusti e intolleranze.', includes: ['Chat vocale live', 'Dettatura', 'Avvisi proattivi'] },
  { id: 'watch', title: 'Smartwatch e biometria', blurb: 'Pressione ed ECG da HealthKit o Health Connect.', includes: ['Lettura parametri', 'Sezione farmaci', 'Spesa ricalibrata'] },
  { id: 'pac', title: 'PAC e risparmio', blurb: 'Piani di accumulo e risparmi in un’area privata e cifrata.', includes: ['Proiezioni', 'Area isolata'] },
  { id: 'vouchers', title: 'Buoni pasto', blurb: 'Calcolo degli articoli ammissibili e scalo dal totale.', includes: ['Ammissibilità prodotti', 'Confronto A/B'] },
] as const;

function PlanPreview() {
  const [selected, setSelected] = useState<Set<string>>(new Set(['ai']));
  const [notice, setNotice] = useState<string | null>(null);

  const toggle = (id: string) =>
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-4" aria-label="Configuratore piani">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Configura il tuo piano</h3>
        <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-medium text-amber-300">Solo anteprima</span>
      </div>
      <ul className="mt-3 space-y-2">
        {PLAN_MODULES.map(m => {
          const on = selected.has(m.id);
          return (
            <li key={m.id}>
              <button
                type="button"
                role="switch"
                aria-checked={on}
                onClick={() => toggle(m.id)}
                className={`w-full rounded-lg border p-3 text-left transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  on ? 'border-blue-500/50 bg-slate-950/80' : 'border-slate-800 bg-slate-950/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium">{m.title}</span>
                  <span className={`h-4 w-7 rounded-full p-0.5 transition-colors ${on ? 'bg-blue-600' : 'bg-slate-700'}`} aria-hidden="true">
                    <span className={`block h-3 w-3 rounded-full bg-white transition-transform ${on ? 'translate-x-3' : ''}`} />
                  </span>
                </div>
                <p className="mt-1 text-[11px] text-slate-400">{m.blurb}</p>
                {on && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {m.includes.map(i => (
                      <span key={i} className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-300">
                        {i}
                      </span>
                    ))}
                  </div>
                )}
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mt-3 text-[11px] text-slate-400">
        {selected.size === 0 ? 'Nessun modulo selezionato.' : `${selected.size} moduli nell’anteprima del piano.`}
      </p>
      <button
        type="button"
        aria-disabled="true"
        onClick={() => setNotice(requestCheckout().reason)}
        className="mt-2 w-full cursor-not-allowed rounded-lg border border-slate-700 bg-slate-800/50 py-2 text-xs text-slate-400"
      >
        Attivazione non disponibile in anteprima
      </button>
      {notice && <p className="mt-1 text-[11px] text-amber-300" role="status">{notice}</p>}
    </section>
  );
}

/* ======================================================================
 * 5. Componente principale
 * ==================================================================== */

type Mode = 'text' | 'dictation' | 'voice';
type VoiceState = 'idle' | 'listening' | 'thinking' | 'speaking';

export interface SyncroAIProps {
  members: Member[];
  /** Elementi della lista condivisa: se cambiano, l’IA avvisa in modo proattivo. */
  listItems?: string[];
  provider?: AiProvider;
}

const MODE_LABEL: Record<Mode, string> = { text: 'Testo', dictation: 'Dettatura', voice: 'Voce' };
const VOICE_LABEL: Record<VoiceState, string> = {
  idle: 'Tocca per parlare',
  listening: 'Ti ascolto…',
  thinking: 'Sto pensando…',
  speaking: 'Sto rispondendo…',
};

export default function SyncroAI({ members, listItems, provider = localAiProvider }: SyncroAIProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: 'welcome', role: 'assistant', text: 'Ciao! Scrivi o detta una ricetta o una lista: la confronto con gusti e intolleranze del gruppo.', ts: Date.now() },
  ]);
  const [mode, setMode] = useState<Mode>('text');
  const [input, setInput] = useState('');
  const [interim, setInterim] = useState('');
  const [busy, setBusy] = useState(false);
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const voiceOnRef = useRef(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => endRef.current?.scrollIntoView({ block: 'end' }), [messages]);

  const send = useCallback(
    async (raw: string, via: ChatMessage['via']): Promise<string | undefined> => {
      const text = raw.trim();
      if (!text) return undefined;
      const userMsg: ChatMessage = { id: newId(), role: 'user', text, ts: Date.now(), via };
      setMessages(m => [...m, userMsg]);
      setBusy(true);

      const findings = analyzeText(text, members);
      let reply: string;
      try {
        reply = await provider.reply({ text, history: [...messagesRef.current, userMsg], members, findings });
      } catch {
        reply = 'Non riesco a rispondere ora. Riprova tra poco.';
      }
      const out: ChatMessage[] = [{ id: newId(), role: 'assistant', text: reply, ts: Date.now() }];
      const alertText = findings.length ? formatFindings(findings) : '';
      if (alertText) out.push({ id: newId(), role: 'alert', text: alertText, ts: Date.now() });
      setMessages(m => [...m, ...out]);
      setBusy(false);
      return [reply, alertText].filter(Boolean).join(' ');
    },
    [members, provider],
  );

  /* Dettatura: il testo riconosciuto finisce nel campo, l’utente rivede e invia */
  const dictation = useSpeechRecognition({
    continuous: true,
    onInterim: setInterim,
    onFinal: t => {
      setInput(prev => (prev ? `${prev} ${t}` : t));
      setInterim('');
    },
  });

  /* Chat vocale: ascolta → risponde → ascolta di nuovo */
  const voiceStartRef = useRef<() => void>(() => {});
  const voice = useSpeechRecognition({
    continuous: false,
    onFinal: async t => {
      if (!voiceOnRef.current || !t) return;
      setVoiceState('thinking');
      const spoken = await send(t, 'voice');
      if (!voiceOnRef.current) return;
      if (spoken) {
        setVoiceState('speaking');
        await speak(spoken);
      }
      if (voiceOnRef.current) {
        setVoiceState('listening');
        voiceStartRef.current();
      }
    },
  });
  voiceStartRef.current = voice.start;

  const stopVoice = useCallback(() => {
    voiceOnRef.current = false;
    voice.stop();
    window.speechSynthesis?.cancel();
    setVoiceState('idle');
  }, [voice]);

  const toggleVoice = () => {
    if (voiceOnRef.current) {
      stopVoice();
    } else {
      voiceOnRef.current = true;
      setVoiceState('listening');
      voice.start();
    }
  };

  const changeMode = (m: Mode) => {
    if (m === mode) return;
    stopVoice();
    dictation.stop();
    setInterim('');
    setMode(m);
  };

  useEffect(() => () => window.speechSynthesis?.cancel(), []);

  /* Comportamento proattivo sulla lista condivisa */
  const lastSig = useRef('');
  useEffect(() => {
    if (!listItems?.length) return;
    const findings = analyzeText(listItems.join('\n'), members);
    const sig = findings.map(f => `${f.memberId}:${f.label}:${f.term}`).sort().join('|');
    if (sig === lastSig.current) return;
    lastSig.current = sig;
    if (!sig) return;
    setMessages(m => [...m, { id: newId(), role: 'alert', text: `Dalla lista condivisa:\n${formatFindings(findings)}`, ts: Date.now() }]);
  }, [listItems, members]);

  const submit = async () => {
    const text = input;
    setInput('');
    setInterim('');
    if (dictation.listening) dictation.stop();
    await send(text, mode === 'dictation' ? 'dictation' : 'text');
  };

  const speechSupported = mode === 'dictation' ? dictation.supported : mode === 'voice' ? voice.supported : true;
  const speechError = mode === 'dictation' ? dictation.error : mode === 'voice' ? voice.error : null;

  return (
    <div className="mx-auto my-4 max-w-md space-y-3 text-slate-100">
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-4" aria-label="Assistente IA">
        <div role="tablist" aria-label="Modalità di interazione" className="mb-3 grid grid-cols-3 gap-1 rounded-lg bg-slate-950/70 p-1">
          {(Object.keys(MODE_LABEL) as Mode[]).map(m => (
            <button
              key={m}
              type="button"
              role="tab"
              aria-selected={mode === m}
              onClick={() => changeMode(m)}
              className={`rounded-md py-1.5 text-xs font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                mode === m ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {MODE_LABEL[m]}
            </button>
          ))}
        </div>

        <div className="max-h-72 space-y-2 overflow-y-auto pr-1" aria-live="polite">
          {messages.map(m => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] whitespace-pre-line rounded-2xl px-3 py-2 text-xs ${
                  m.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : m.role === 'alert'
                      ? 'border border-amber-500/40 bg-amber-500/10 text-amber-100'
                      : 'bg-slate-800 text-slate-100'
                }`}
              >
                {m.text}
                {m.via && m.via !== 'text' && <span className="ml-1 text-[10px] opacity-60">({m.via === 'voice' ? 'voce' : 'dettato'})</span>}
              </div>
            </div>
          ))}
          {busy && <div className="text-[11px] text-slate-500">Sto analizzando…</div>}
          <div ref={endRef} />
        </div>

        {!speechSupported && <p className="mt-2 text-[11px] text-amber-300">Il riconoscimento vocale non è supportato da questo browser. Usa la modalità Testo.</p>}
        {speechError && <p className="mt-2 text-[11px] text-rose-300" role="alert">{speechError}</p>}

        {mode === 'voice' ? (
          <div className="mt-4 flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={toggleVoice}
              disabled={!voice.supported}
              aria-pressed={voiceState !== 'idle'}
              className={`flex h-16 w-16 items-center justify-center rounded-full border text-2xl transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-40 ${
                voiceState === 'idle' ? 'border-slate-700 bg-slate-900 text-blue-400' : 'border-blue-500 bg-blue-600 text-white'
              } ${voiceState === 'listening' ? 'animate-pulse' : ''}`}
              aria-label={voiceState === 'idle' ? 'Avvia conversazione vocale' : 'Termina conversazione vocale'}
            >
              {voiceState === 'idle' ? '🎙️' : '■'}
            </button>
            <span className="text-[11px] text-slate-400">{VOICE_LABEL[voiceState]}</span>
          </div>
        ) : (
          <form
            onSubmit={e => {
              e.preventDefault();
              void submit();
            }}
            className="mt-3 flex items-end gap-2"
          >
            <textarea
              value={interim ? `${input}${input ? ' ' : ''}${interim}` : input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  void submit();
                }
              }}
              rows={2}
              placeholder={mode === 'dictation' ? 'Premi il microfono e detta…' : 'Scrivi una ricetta o una lista…'}
              aria-label="Messaggio"
              className="min-w-0 flex-1 resize-none rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            />
            {mode === 'dictation' && (
              <button
                type="button"
                onClick={dictation.listening ? dictation.stop : dictation.start}
                disabled={!dictation.supported}
                aria-pressed={dictation.listening}
                aria-label={dictation.listening ? 'Ferma dettatura' : 'Avvia dettatura'}
                className={`h-9 w-9 shrink-0 rounded-full border text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-40 ${
                  dictation.listening ? 'animate-pulse border-rose-500 bg-rose-600 text-white' : 'border-slate-700 bg-slate-900 text-blue-400'
                }`}
              >
                🎙️
              </button>
            )}
            <button type="submit" disabled={busy || !input.trim()} className="h-9 shrink-0 rounded-lg bg-blue-600 px-3 text-xs font-medium hover:bg-blue-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 disabled:opacity-40">
              Invia
            </button>
          </form>
        )}
      </section>

      <PlanPreview />
    </div>
  );
}
