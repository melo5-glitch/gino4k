import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import SyncroCart from './SyncroCart';
import { decryptJSON, deriveKey, encryptJSON, fromB64, localVaultStorage, toB64, vaultNamespace } from './syncroVault';
import type { VaultStorage } from './syncroVault';
import { formatEur, newId } from './syncroTypes';

/*
 * ISOLAMENTO: questo modulo non importa nulla dallo spazio condiviso e NON espone
 * callback con dati finanziari. Tutto ciò che contiene (risparmi, PAC, buoni pasto)
 * vive solo nel vault cifrato legato allo user_id.
 */

/* ======================================================================
 * Modello dati del vault
 * ==================================================================== */

interface Saving {
  id: string;
  label: string;
  amountCents: number;
}
interface PacPlan {
  id: string;
  name: string;
  monthlyCents: number;
  annualReturnPct: number; // ipotesi dell’utente, non una previsione
  years: number;
}
interface VoucherConfig {
  balanceCount: number;
  unitValueCents: number;
  maxPerTransaction: number; // configurabile: verifica le condizioni dell’emittente e dell’esercente
}
interface VaultData {
  savings: Saving[];
  pac: PacPlan[];
  vouchers: VoucherConfig;
}

const EMPTY_VAULT: VaultData = {
  savings: [],
  pac: [],
  vouchers: { balanceCount: 10, unitValueCents: 800, maxPerTransaction: 8 },
};

/* ======================================================================
 * Hook del vault: sblocco con passphrase, salvataggio cifrato, blocco automatico
 * ==================================================================== */

type VaultStatus = 'loading' | 'new' | 'existing' | 'unlocked';
const IDLE_LOCK_MS = 5 * 60_000;

function useVault(userId: string, storage: VaultStorage) {
  const [status, setStatus] = useState<VaultStatus>('loading');
  const [data, setData] = useState<VaultData>(EMPTY_VAULT);
  const [error, setError] = useState<string | null>(null);
  const keyRef = useRef<CryptoKey | null>(null);
  const saltRef = useRef<Uint8Array | null>(null);
  const nsRef = useRef('');
  const dataRef = useRef<VaultData>(EMPTY_VAULT);
  const idleRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    let off = false;
    setStatus('loading');
    keyRef.current = null;
    dataRef.current = EMPTY_VAULT;
    setData(EMPTY_VAULT);
    (async () => {
      nsRef.current = await vaultNamespace(userId);
      const env = await storage.load(nsRef.current);
      if (!off) setStatus(env ? 'existing' : 'new');
    })().catch(() => !off && setStatus('new'));
    return () => {
      off = true;
      keyRef.current = null;
    };
  }, [userId, storage]);

  const persist = useCallback(
    async (d: VaultData) => {
      const key = keyRef.current;
      const salt = saltRef.current;
      if (!key || !salt) return;
      const { iv, ct } = await encryptJSON(key, d);
      await storage.save(nsRef.current, { v: 1, salt: toB64(salt), iv, ct });
    },
    [storage],
  );

  const unlock = async (passphrase: string) => {
    setError(null);
    if (passphrase.length < 8) {
      setError('Usa almeno 8 caratteri.');
      return;
    }
    try {
      const env = await storage.load(nsRef.current);
      if (env) {
        const salt = fromB64(env.salt);
        const key = await deriveKey(passphrase, salt);
        const d = await decryptJSON<VaultData>(key, env);
        keyRef.current = key;
        saltRef.current = salt;
        dataRef.current = d;
        setData(d);
      } else {
        const salt = crypto.getRandomValues(new Uint8Array(16));
        keyRef.current = await deriveKey(passphrase, salt);
        saltRef.current = salt;
        dataRef.current = EMPTY_VAULT;
        setData(EMPTY_VAULT);
        await persist(EMPTY_VAULT);
      }
      setStatus('unlocked');
    } catch {
      keyRef.current = null;
      setError('Passphrase errata o dati non leggibili.');
    }
  };

  const update = useCallback(
    (fn: (d: VaultData) => VaultData) => {
      const next = fn(dataRef.current);
      dataRef.current = next;
      setData(next);
      void persist(next);
    },
    [persist],
  );

  const lock = useCallback(() => {
    keyRef.current = null;
    saltRef.current = null;
    dataRef.current = EMPTY_VAULT;
    setData(EMPTY_VAULT);
    setStatus('existing');
  }, []);

  const touch = useCallback(() => {
    window.clearTimeout(idleRef.current);
    if (keyRef.current) idleRef.current = window.setTimeout(lock, IDLE_LOCK_MS);
  }, [lock]);

  useEffect(() => {
    if (status === 'unlocked') touch();
    return () => window.clearTimeout(idleRef.current);
  }, [status, touch]);

  return { status, data, error, unlock, update, lock, touch };
}

/* ======================================================================
 * Calcoli
 * ==================================================================== */

const parseEuroToCents = (s: string): number | null => {
  const n = Number(s.replace(',', '.'));
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : null;
};

/** Valore futuro di versamenti mensili costanti (rendita posticipata, capitalizzazione mensile). */
export function projectPac(plan: PacPlan) {
  const n = plan.years * 12;
  const invested = plan.monthlyCents * n;
  const r = Math.pow(1 + plan.annualReturnPct / 100, 1 / 12) - 1;
  const future = r === 0 ? invested : Math.round(plan.monthlyCents * ((Math.pow(1 + r, n) - 1) / r));
  return { invested, future, gain: future - invested };
}

export interface GroceryLine {
  id: string;
  name: string;
  category: string;
  fresh: boolean; // i freschi restano in negozio nell’Opzione B
  voucherEligible: boolean; // ammissibile ai buoni pasto (di norma alimentari)
  flyerPriceCents: number; // prezzo da volantino, ritiro locale
  onlinePriceCents: number; // prezzo del carrello online
}

const DEFAULT_GROCERIES: GroceryLine[] = [
  { id: 'g1', name: 'Pasta integrale 1kg', category: 'Dispensa', fresh: false, voucherEligible: true, flyerPriceCents: 150, onlinePriceCents: 180 },
  { id: 'g2', name: 'Olio extravergine 1L', category: 'Dispensa', fresh: false, voucherEligible: true, flyerPriceCents: 790, onlinePriceCents: 850 },
  { id: 'g3', name: 'Detersivo lavatrice', category: 'Casa', fresh: false, voucherEligible: false, flyerPriceCents: 640, onlinePriceCents: 620 },
  { id: 'g4', name: 'Carta igienica 12 pz', category: 'Casa', fresh: false, voucherEligible: false, flyerPriceCents: 520, onlinePriceCents: 490 },
  { id: 'g5', name: 'Mele 1kg', category: 'Fresco', fresh: true, voucherEligible: true, flyerPriceCents: 190, onlinePriceCents: 290 },
  { id: 'g6', name: 'Petto di pollo 500g', category: 'Fresco', fresh: true, voucherEligible: true, flyerPriceCents: 520, onlinePriceCents: 650 },
];

interface StrategyResult {
  totalCents: number;
  vouchersUsed: number;
  voucherCents: number;
  payCents: number;
}

/** Buoni interi, senza resto: n = min(saldo, massimo per transazione, buoni coperti dal totale ammissibile). */
function applyVouchers(eligibleCents: number, totalCents: number, v: VoucherConfig): StrategyResult {
  const n = v.unitValueCents > 0 ? Math.max(0, Math.min(v.balanceCount, v.maxPerTransaction, Math.floor(eligibleCents / v.unitValueCents))) : 0;
  const voucherCents = n * v.unitValueCents;
  return { totalCents, vouchersUsed: n, voucherCents, payCents: totalCents - voucherCents };
}

const sum = (lines: GroceryLine[], pick: (l: GroceryLine) => number) => lines.reduce((a, l) => a + pick(l), 0);

function computeStrategies(lines: GroceryLine[], excluded: Set<string>, v: VoucherConfig) {
  const active = lines.filter(l => !excluded.has(l.id));
  // A: tutto da volantino, ritiro locale, buoni sugli articoli ammissibili
  const A = applyVouchers(
    sum(active.filter(l => l.voucherEligible), l => l.flyerPriceCents),
    sum(active, l => l.flyerPriceCents),
    v,
  );
  // B: freschi in negozio (da volantino), non freschi nel carrello online. I buoni valgono solo in negozio.
  const local = active.filter(l => l.fresh);
  const online = active.filter(l => !l.fresh);
  const localCents = sum(local, l => l.flyerPriceCents);
  const onlineCents = sum(online, l => l.onlinePriceCents);
  const B = {
    ...applyVouchers(
      sum(local.filter(l => l.voucherEligible), l => l.flyerPriceCents),
      localCents + onlineCents,
      v,
    ),
    localCents,
    onlineCents,
  };
  return { A, B };
}

/* ======================================================================
 * UI
 * ==================================================================== */

const card = 'rounded-xl border border-slate-800 bg-slate-900/60 p-4';
const field = 'min-w-0 rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';
const primaryBtn = 'rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium hover:bg-blue-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';
const ghostBtn = 'rounded px-1.5 text-slate-500 hover:text-rose-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500';

function VaultGate({ status, error, onUnlock }: { status: VaultStatus; error: string | null; onUnlock: (p: string) => Promise<void> }) {
  const [pass, setPass] = useState('');
  const [busy, setBusy] = useState(false);
  const isNew = status === 'new';
  return (
    <section className={card} aria-label="Sblocca area privata">
      <h3 className="text-sm font-semibold">{isNew ? 'Crea la tua area privata' : 'Area privata bloccata'}</h3>
      <p className="mt-1 text-[11px] text-slate-400">
        {isNew
          ? 'Scegli una passphrase: cifra i tuoi dati su questo dispositivo. Non può essere recuperata se la dimentichi.'
          : 'Inserisci la passphrase per sbloccare risparmi, PAC e buoni pasto.'}
      </p>
      <form
        onSubmit={async e => {
          e.preventDefault();
          setBusy(true);
          await onUnlock(pass);
          setPass('');
          setBusy(false);
        }}
        className="mt-3 flex gap-2"
      >
        <input
          type="password"
          value={pass}
          onChange={e => setPass(e.target.value)}
          autoComplete={isNew ? 'new-password' : 'current-password'}
          aria-label="Passphrase"
          placeholder="Passphrase (min. 8 caratteri)"
          className={`${field} flex-1`}
        />
        <button type="submit" disabled={busy || status === 'loading'} className={`${primaryBtn} disabled:opacity-40`}>
          {isNew ? 'Crea' : 'Sblocca'}
        </button>
      </form>
      {error && <p className="mt-2 text-[11px] text-rose-300" role="alert">{error}</p>}
    </section>
  );
}

function SavingsSection({ data, update }: { data: VaultData; update: (fn: (d: VaultData) => VaultData) => void }) {
  const [label, setLabel] = useState('');
  const [amount, setAmount] = useState('');
  const total = data.savings.reduce((a, s) => a + s.amountCents, 0);

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    const cents = parseEuroToCents(amount);
    if (!label.trim() || cents === null) return;
    update(d => ({ ...d, savings: [...d.savings, { id: newId(), label: label.trim().slice(0, 60), amountCents: cents }] }));
    setLabel('');
    setAmount('');
  };

  return (
    <section className={card} aria-label="Risparmi">
      <div className="flex items-baseline justify-between">
        <h3 className="text-sm font-semibold">Risparmi</h3>
        <span className="text-sm font-bold tabular-nums text-blue-400">{formatEur(total)}</span>
      </div>
      <ul className="mt-2 space-y-1.5">
        {data.savings.map(s => (
          <li key={s.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-xs">
            <span>{s.label}</span>
            <span className="flex items-center gap-2 tabular-nums">
              {formatEur(s.amountCents)}
              <button type="button" aria-label={`Rimuovi ${s.label}`} onClick={() => update(d => ({ ...d, savings: d.savings.filter(x => x.id !== s.id) }))} className={ghostBtn}>
                ✕
              </button>
            </span>
          </li>
        ))}
        {data.savings.length === 0 && <li className="text-[11px] text-slate-500">Nessun risparmio registrato.</li>}
      </ul>
      <form onSubmit={add} className="mt-3 flex gap-2">
        <input value={label} onChange={e => setLabel(e.target.value)} placeholder="Voce (es. Fondo emergenze)" aria-label="Nome voce" className={`${field} flex-1`} />
        <input value={amount} onChange={e => setAmount(e.target.value)} inputMode="decimal" placeholder="€" aria-label="Importo in euro" className={`${field} w-20`} />
        <button type="submit" className={primaryBtn}>Aggiungi</button>
      </form>
    </section>
  );
}

function PacSection({ data, update }: { data: VaultData; update: (fn: (d: VaultData) => VaultData) => void }) {
  const [name, setName] = useState('');
  const [monthly, setMonthly] = useState('');
  const [ret, setRet] = useState('4');
  const [years, setYears] = useState('10');

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    const m = parseEuroToCents(monthly);
    const r = Number(ret.replace(',', '.'));
    const y = Math.round(Number(years));
    if (!name.trim() || m === null || m === 0 || !Number.isFinite(r) || r < -50 || r > 50 || !Number.isFinite(y) || y < 1 || y > 60) return;
    update(d => ({ ...d, pac: [...d.pac, { id: newId(), name: name.trim().slice(0, 60), monthlyCents: m, annualReturnPct: r, years: y }] }));
    setName('');
    setMonthly('');
  };

  return (
    <section className={card} aria-label="Piani di accumulo">
      <h3 className="text-sm font-semibold">PAC</h3>
      <ul className="mt-2 space-y-2">
        {data.pac.map(p => {
          const pr = projectPac(p);
          return (
            <li key={p.id} className="rounded-lg border border-slate-800 bg-slate-950/70 p-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-medium">{p.name}</span>
                <button type="button" aria-label={`Rimuovi ${p.name}`} onClick={() => update(d => ({ ...d, pac: d.pac.filter(x => x.id !== p.id) }))} className={ghostBtn}>
                  ✕
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                {formatEur(p.monthlyCents)}/mese · {p.years} anni · rendimento ipotizzato {p.annualReturnPct}%
              </p>
              <dl className="mt-2 grid grid-cols-3 gap-2 text-[11px]">
                <div><dt className="text-slate-500">Versato</dt><dd className="tabular-nums">{formatEur(pr.invested)}</dd></div>
                <div><dt className="text-slate-500">Stima finale</dt><dd className="tabular-nums text-blue-300">{formatEur(pr.future)}</dd></div>
                <div><dt className="text-slate-500">Differenza</dt><dd className={`tabular-nums ${pr.gain >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{formatEur(pr.gain)}</dd></div>
              </dl>
            </li>
          );
        })}
        {data.pac.length === 0 && <li className="text-[11px] text-slate-500">Nessun piano. Aggiungine uno per vedere una proiezione.</li>}
      </ul>
      <form onSubmit={add} className="mt-3 grid grid-cols-2 gap-2">
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Nome piano" aria-label="Nome piano" className={`${field} col-span-2`} />
        <input value={monthly} onChange={e => setMonthly(e.target.value)} inputMode="decimal" placeholder="€ al mese" aria-label="Versamento mensile in euro" className={field} />
        <input value={ret} onChange={e => setRet(e.target.value)} inputMode="decimal" placeholder="% annuo ipotizzato" aria-label="Rendimento annuo ipotizzato" className={field} />
        <input value={years} onChange={e => setYears(e.target.value)} inputMode="numeric" placeholder="Anni" aria-label="Durata in anni" className={field} />
        <button type="submit" className={primaryBtn}>Aggiungi piano</button>
      </form>
      <p className="mt-2 text-[10px] text-slate-500">Proiezione illustrativa basata sul rendimento che hai ipotizzato: non è una previsione, una garanzia né una consulenza finanziaria.</p>
    </section>
  );
}

function VoucherSection({ data, update }: { data: VaultData; update: (fn: (d: VaultData) => VaultData) => void }) {
  const v = data.vouchers;
  const set = (patch: Partial<VoucherConfig>) => update(d => ({ ...d, vouchers: { ...d.vouchers, ...patch } }));
  const num = (s: string) => Math.max(0, Math.min(99, Math.floor(Number(s) || 0)));
  return (
    <section className={card} aria-label="Buoni pasto">
      <h3 className="text-sm font-semibold">Buoni pasto</h3>
      <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-slate-400">
        <label className="space-y-1">
          <span>Buoni disponibili</span>
          <input value={v.balanceCount} onChange={e => set({ balanceCount: num(e.target.value) })} inputMode="numeric" className={`${field} w-full`} />
        </label>
        <label className="space-y-1">
          <span>Valore (€)</span>
          <input
            defaultValue={(v.unitValueCents / 100).toFixed(2).replace('.', ',')}
            onBlur={e => {
              const c = parseEuroToCents(e.target.value);
              if (c !== null) set({ unitValueCents: c });
            }}
            inputMode="decimal"
            className={`${field} w-full`}
          />
        </label>
        <label className="space-y-1">
          <span>Max per spesa</span>
          <input value={v.maxPerTransaction} onChange={e => set({ maxPerTransaction: num(e.target.value) })} inputMode="numeric" className={`${field} w-full`} />
        </label>
      </div>
      <p className="mt-2 text-[10px] text-slate-500">Si usano buoni interi, senza resto, solo su articoli ammissibili. Verifica le regole dell’emittente e dell’esercente.</p>
    </section>
  );
}

function StrategyCompare({ lines, voucher }: { lines: GroceryLine[]; voucher: VoucherConfig }) {
  const [selectedOnline, setSelectedOnline] = useState<string[] | null>(null);

  const onlineLines = useMemo(() => lines.filter(l => !l.fresh), [lines]);
  const cartItems = useMemo(
    () => onlineLines.map(l => ({ id: l.id, name: l.name, priceCents: l.onlinePriceCents, selected: true, category: l.category })),
    [onlineLines],
  );
  const onSelection = useCallback((ids: string[]) => setSelectedOnline(ids), []);

  // Un articolo deselezionato nel carrello online viene escluso da ENTRAMBE le opzioni
  const excluded = useMemo(() => {
    if (!selectedOnline) return new Set<string>();
    return new Set(onlineLines.filter(l => !selectedOnline.includes(l.id)).map(l => l.id));
  }, [selectedOnline, onlineLines]);

  const { A, B } = useMemo(() => computeStrategies(lines, excluded, voucher), [lines, excluded, voucher]);
  const winner: 'A' | 'B' = B.payCents < A.payCents ? 'B' : 'A';
  const diff = Math.abs(A.payCents - B.payCents);

  const Badge = ({ id }: { id: 'A' | 'B' }) =>
    winner === id ? <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-300">Più conveniente</span> : null;

  return (
    <section className={card} aria-label="Confronto strategico A/B">
      <h3 className="text-sm font-semibold">Confronto A/B</h3>
      <p className="mt-1 text-[11px] text-slate-400" role="status">
        {diff === 0 ? 'Le due opzioni costano uguale.' : `L’Opzione ${winner} fa risparmiare ${formatEur(diff)}.`}
      </p>

      <div className="mt-3 space-y-3">
        <article className={`rounded-lg border p-3 ${winner === 'A' ? 'border-emerald-500/40' : 'border-slate-800'} bg-slate-950/70`}>
          <header className="flex items-center justify-between">
            <h4 className="text-xs font-semibold">Opzione A · Risparmio massimo</h4>
            <Badge id="A" />
          </header>
          <p className="mt-0.5 text-[11px] text-slate-400">Volantini, ritiro locale e buoni pasto.</p>
          <dl className="mt-2 space-y-0.5 text-[11px]">
            <div className="flex justify-between"><dt className="text-slate-400">Totale</dt><dd className="tabular-nums">{formatEur(A.totalCents)}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-400">Buoni usati ({A.vouchersUsed})</dt><dd className="tabular-nums text-emerald-400">−{formatEur(A.voucherCents)}</dd></div>
            <div className="flex justify-between border-t border-slate-800 pt-1 text-xs font-semibold"><dt>Da pagare</dt><dd className="tabular-nums">{formatEur(A.payCents)}</dd></div>
          </dl>
        </article>

        <article className={`rounded-lg border p-3 ${winner === 'B' ? 'border-emerald-500/40' : 'border-slate-800'} bg-slate-950/70`}>
          <header className="flex items-center justify-between">
            <h4 className="text-xs font-semibold">Opzione B · Freschi in negozio + online</h4>
            <Badge id="B" />
          </header>
          <p className="mt-0.5 text-[11px] text-slate-400">Freschi da volantino; non freschi nel carrello Amazon. I buoni valgono solo in negozio.</p>
          <dl className="mt-2 space-y-0.5 text-[11px]">
            <div className="flex justify-between"><dt className="text-slate-400">Freschi (negozio)</dt><dd className="tabular-nums">{formatEur(B.localCents)}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-400">Non freschi (online)</dt><dd className="tabular-nums">{formatEur(B.onlineCents)}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-400">Buoni usati ({B.vouchersUsed})</dt><dd className="tabular-nums text-emerald-400">−{formatEur(B.voucherCents)}</dd></div>
            <div className="flex justify-between border-t border-slate-800 pt-1 text-xs font-semibold"><dt>Da pagare</dt><dd className="tabular-nums">{formatEur(B.payCents)}</dd></div>
          </dl>
          <SyncroCart items={cartItems} onSelectionChange={onSelection} />
        </article>
      </div>
      <p className="mt-2 text-[10px] text-slate-500">Prezzi di esempio: collega i tuoi volantini e il carrello reale tramite la prop <code>groceries</code>.</p>
    </section>
  );
}

/* ======================================================================
 * Componente principale
 * ==================================================================== */

export interface SyncroFinanceProps {
  /** Identificativo dell’utente autenticato: usato solo per derivare il namespace del vault. */
  userId: string;
  storage?: VaultStorage;
  /** Lista della spesa PERSONALE dell’utente (non quella dello spazio condiviso). */
  groceries?: GroceryLine[];
}

export default function SyncroFinance({ userId, storage = localVaultStorage, groceries = DEFAULT_GROCERIES }: SyncroFinanceProps) {
  const vault = useVault(userId, storage);

  if (vault.status !== 'unlocked') {
    return (
      <div className="mx-auto my-4 max-w-md text-slate-100">
        <VaultGate status={vault.status} error={vault.error} onUnlock={vault.unlock} />
      </div>
    );
  }

  return (
    <div className="mx-auto my-4 max-w-md space-y-3 text-slate-100" onPointerDownCapture={vault.touch} onKeyDownCapture={vault.touch}>
      <div className="flex items-center justify-between px-1">
        <p className="flex items-center gap-1.5 text-[11px] text-emerald-300">
          <span aria-hidden="true">🔒</span> Area privata · cifrata · non visibile al gruppo
        </p>
        <button type="button" onClick={vault.lock} className="rounded-lg border border-slate-700 px-2.5 py-1 text-[11px] text-slate-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500">
          Blocca
        </button>
      </div>
      <SavingsSection data={vault.data} update={vault.update} />
      <PacSection data={vault.data} update={vault.update} />
      <VoucherSection data={vault.data} update={vault.update} />
      <StrategyCompare lines={groceries} voucher={vault.data.vouchers} />
    </div>
  );
}
