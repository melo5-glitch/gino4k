export const avatarKeys = ['sprout', 'wave', 'sun', 'orbit'] as const;
export function validPhoto(file: { size: number; type: string }) {
  return file.size > 0 && file.size <= 5 * 1024 * 1024 && ['image/jpeg', 'image/png', 'image/webp'].includes(file.type);
}
export function ownedPhoto(path: string, userId: string) {
  return path.startsWith(`${userId}/`) && !path.includes('..') && /^[\w/-]+\.(jpg|jpeg|png|webp)$/.test(path);
}
export const AI_BATCH_SIZE = 3;
export function aiFailure(status: number, type = '') {
  if (status === 402 || status === 403) return { pause: true, category: status === 402 || ['credit_limit_reached', 'ai_disabled'].includes(type) ? 'workspace' : 'terminal' };
  return { pause: false, category: status === 429 || status >= 500 ? 'transient' : 'terminal' };
}