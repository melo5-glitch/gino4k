import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { avatarKeys, ownedPhoto } from './profile-rules';
export const saveIdentity = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator((v: { avatar_key: typeof avatarKeys[number]; photo_path: string | null }) => z.object({ avatar_key: z.enum(avatarKeys), photo_path: z.string().max(200).nullable() }).parse(v))
  .handler(async ({ data, context }) => {
    if (data.photo_path) {
      if (!ownedPhoto(data.photo_path, context.userId)) throw new Error('Foto non valida.');
      const { data: files, error } = await context.supabase.storage.from('profile-photos').list(context.userId);
      if (error || !files?.some(f => `${context.userId}/${f.name}` === data.photo_path)) throw new Error('Foto non trovata.');
    }
    const { error } = await context.supabase.from('profiles').update(data).eq('id', context.userId);
    if (error) throw new Error('Immagine non salvata.');
  });
export const saveAutonomy = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator((v: boolean) => z.boolean().parse(v)).handler(async ({ data, context }) => {
  const { error } = await context.supabase.from('profiles').update({ autonomous_ai: data }).eq('id', context.userId);
  if (error) throw new Error('Preferenza non salvata.');
});
export const loadAutonomy = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [job, control] = await Promise.all([context.supabase.from('sincro_ai_jobs').select('status,error_message,completed_at').eq('user_id', context.userId).maybeSingle(), context.supabase.from('sincro_ai_control').select('paused,reason').eq('id', 1).maybeSingle()]);
  if (job.error || control.error) throw new Error('Stato IA non disponibile.');
  return { job: job.data, control: control.data };
});