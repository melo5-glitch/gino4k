import { tool } from 'ai';
import { z } from 'zod';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { budgetFigures, groceryFigures, pacFigures } from '../dashboard';
import { bmi, dailyCalories, financeSchema, bodySchema } from '../schemas';

type Db = SupabaseClient<Database>;
const euros = (c: number) => Math.round(c) / 100;

/** Tools run with the signed-in user's client, so database rules limit them to that user's data. */
export function chatTools(db: Db, userId: string) {
  return {
    read_overview: tool({
      description: 'Read the user’s profile, budget, income, savings plan, goals, body data and month totals. Amounts are in euros.',
      inputSchema: z.object({}),
      execute: async () => {
        const [p, t, g, a] = await Promise.all([db.from('profiles').select('*').eq('id', userId).single(), db.from('transactions').select('*').order('created_at', { ascending: false }).limit(500), db.from('saving_goals').select('id,name,target_cents'), db.from('goal_allocations').select('goal_id,amount_cents,transaction_id')]);
        if (p.error || t.error || g.error || a.error) return { error: 'Dati non disponibili.' };
        const pr = p.data; const entries = t.data ?? []; const b = budgetFigures(entries, pr.monthly_budget_cents); const gr = groceryFigures(entries); const pac = pacFigures(a.data ?? [], entries);
        return {
          name: pr.display_name, income: { salary: euros(pr.salary_cents), extra: euros(pr.extra_income_cents) },
          budget: { monthly: euros(pr.monthly_budget_cents), spent_this_month: euros(b.spent), remaining: euros(b.remaining), available_today: euros(b.daily) },
          groceries_this_month: { spent: euros(gr.spent), discounts: euros(gr.saved), purchases: gr.purchases },
          savings_plan: { monthly_contribution: euros(pr.pac_monthly_cents), declared_invested: euros(pr.pac_invested_cents), risk: pr.pac_risk, set_aside_for_goals: euros(pac.invested) },
          goals: (g.data ?? []).map(x => ({ id: x.id, name: x.name, target: euros(x.target_cents), saved: euros((a.data ?? []).filter(y => y.goal_id === x.id).reduce((s, y) => s + y.amount_cents, 0)) })),
          body: { height_cm: pr.height_cm, weight_kg: pr.weight_dg ? pr.weight_dg / 10 : null, birth_year: pr.birth_year, diet_goal: pr.diet_goal, bmi: bmi(pr.height_cm, pr.weight_dg), daily_kcal_estimate: dailyCalories(pr) },
          recent_transactions: entries.slice(0, 15).map(e => ({ date: e.created_at.slice(0, 10), kind: e.kind, description: e.description, category: e.category, amount: euros(e.amount_cents) })),
        };
      },
    }),
    read_shopping_list: tool({
      description: 'Read the user’s shopping list and stock items.',
      inputSchema: z.object({}),
      execute: async () => { const { data, error } = await db.from('shopping_items').select('name,quantity,checked,expires_on,stock,category').eq('deleted', false).limit(100); return error ? { error: 'Lista non disponibile.' } : { items: data }; },
    }),
    add_shopping_item: tool({
      description: 'Add an item to the user’s personal shopping list when they ask.',
      inputSchema: z.object({ name: z.string(), quantity: z.number() }),
      execute: async ({ name, quantity }) => {
        const clean = name.trim().slice(0, 100); const q = Math.min(Math.max(Math.round(quantity) || 1, 1), 99);
        if (!clean) return { error: 'Nome mancante.' };
        const { error } = await db.from('shopping_items').insert({ user_id: userId, name: clean, quantity: q });
        return error ? { error: 'Articolo non aggiunto.' } : { added: clean, quantity: q };
      },
    }),
    update_settings: tool({
      description: 'Update settings the user explicitly asks to change. Use null for fields that should stay unchanged. Amounts in euros; weight in kg.',
      inputSchema: z.object({ salary: z.number().nullable(), extra_income: z.number().nullable(), monthly_budget: z.number().nullable(), pac_monthly: z.number().nullable(), pac_invested: z.number().nullable(), pac_risk: z.enum(['low', 'mid', 'high']).nullable(), height_cm: z.number().nullable(), weight_kg: z.number().nullable(), birth_year: z.number().nullable(), diet_goal: z.enum(['lose', 'keep', 'gain']).nullable() }),
      execute: async (i) => {
        const c = (v: number | null) => v === null ? undefined : Math.round(v * 100);
        const finance = financeSchema.safeParse({ salary_cents: c(i.salary), extra_income_cents: c(i.extra_income), monthly_budget_cents: c(i.monthly_budget), pac_monthly_cents: c(i.pac_monthly), pac_invested_cents: c(i.pac_invested), pac_risk: i.pac_risk ?? undefined });
        const body = bodySchema.safeParse({ height_cm: i.height_cm === null ? undefined : Math.round(i.height_cm), weight_dg: i.weight_kg === null ? undefined : Math.round(i.weight_kg * 10), birth_year: i.birth_year === null ? undefined : Math.round(i.birth_year), diet_goal: i.diet_goal ?? undefined });
        if (!finance.success || !body.success) return { error: 'Valori fuori dai limiti consentiti.' };
        const update = Object.fromEntries(Object.entries({ ...finance.data, ...body.data }).filter(([, v]) => v !== undefined));
        if (!Object.keys(update).length) return { error: 'Nessun valore da modificare.' };
        const { error } = await db.from('profiles').update({ ...update, updated_at: new Date().toISOString() }).eq('id', userId);
        return error ? { error: 'Modifica non salvata.' } : { updated: Object.keys(update) };
      },
    }),
    create_goal: tool({
      description: 'Create a savings goal the user asks for. Target in euros.',
      inputSchema: z.object({ name: z.string(), target: z.number() }),
      execute: async ({ name, target }) => {
        const cents = Math.round(target * 100); const clean = name.trim().slice(0, 100);
        if (!clean || cents <= 0 || cents > 100000000) return { error: 'Obiettivo non valido.' };
        const { error } = await db.from('saving_goals').insert({ user_id: userId, name: clean, target_cents: cents });
        return error ? { error: 'Obiettivo non creato.' } : { created: clean, target };
      },
    }),
  };
}
