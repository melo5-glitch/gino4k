import { createContext, useContext, useEffect, useState, Suspense, type ReactNode } from 'react';
import { useRouter, Link } from '@tanstack/react-router';
import { queryOptions, useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { loadFoundation } from './data.functions';
export const foundationOptions = (userId: string) => queryOptions({queryKey:['foundation',userId],queryFn:()=>loadFoundation(),staleTime:15000});
const Context = createContext<{user:User|null;ready:boolean;online:boolean}>({user:null,ready:false,online:true});
export function AccountProvider({children}:{children:ReactNode}) { const [user,setUser]=useState<User|null>(null); const [ready,setReady]=useState(false); const [online,setOnline]=useState(true); const queryClient=useQueryClient();const router=useRouter();
useEffect(()=>{let alive=true;let identityVersion=0;const fetchUser=async()=>{const version=++identityVersion;const {data}=await supabase.auth.getUser();if(alive&&version===identityVersion){setUser(data.user);setReady(true);}};void fetchUser();const {data:{subscription}}=supabase.auth.onAuthStateChange(event=>{if(!['SIGNED_IN','SIGNED_OUT','USER_UPDATED'].includes(event))return;if(event==='SIGNED_OUT'){identityVersion++;setUser(null);setReady(true);void queryClient.cancelQueries();queryClient.clear();}else{void fetchUser();void queryClient.invalidateQueries();}void router.invalidate();}); const update=()=>setOnline(navigator.onLine);update();window.addEventListener('online',update);window.addEventListener('offline',update);return()=>{alive=false;subscription.unsubscribe();window.removeEventListener('online',update);window.removeEventListener('offline',update);};},[queryClient,router]);return <Context.Provider value={{user,ready,online}}>{children}</Context.Provider>; }
export const useAccount=()=>useContext(Context);
export const useFoundation=()=>{const {user}=useAccount();return useSuspenseQuery(foundationOptions(user?.id ?? 'signed-out')).data;};
export function AccountSurface({children}:{children:ReactNode}){const {user,ready}=useAccount();if(!ready)return <FoundationSkeleton/>;if(!user)return <div className="space-y-4 py-10"><h2 className="font-display text-xl">Il tuo spazio Sincro</h2><p className="text-muted-foreground">Accedi per consultare e salvare i tuoi dati personali.</p><Button asChild><Link to="/auth">Accedi / Registrati</Link></Button></div>;return <Suspense fallback={<FoundationSkeleton/>}>{children}</Suspense>;}
export function FoundationSkeleton(){return <div className="grid gap-6 md:grid-cols-3" aria-label="Caricamento"><Skeleton className="h-32"/><Skeleton className="h-32"/><Skeleton className="h-32"/></div>;}
