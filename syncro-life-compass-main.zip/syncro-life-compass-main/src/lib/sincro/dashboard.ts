type Entry = { kind: string; category: string; amount_cents: number; discount_cents: number; roundup_cents: number; created_at: string; goal_id?: string | null };
const sameMonth = (d: Date, now: Date) => d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
const isSpend = (e: Entry) => e.kind === 'expense' && e.category !== 'Trasferimento';
export function budgetFigures(entries: Entry[], budgetCents: number, now = new Date()) {
  const spent = entries.filter(e => isSpend(e) && sameMonth(new Date(e.created_at), now)).reduce((s, e) => s + e.amount_cents, 0);
  const remaining = Math.max(budgetCents - spent, 0);
  const daysLeft = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate() - now.getDate() + 1;
  return { spent, remaining, daily: Math.floor(remaining / daysLeft), ratio: budgetCents > 0 ? Math.min(spent / budgetCents, 1) : 0 };
}
export function groceryFigures(entries: Entry[], now = new Date()) {
  const month = entries.filter(e => isSpend(e) && e.category === 'Alimentari' && sameMonth(new Date(e.created_at), now));
  return { spent: month.reduce((s, e) => s + e.amount_cents, 0), saved: month.reduce((s, e) => s + e.discount_cents, 0), purchases: month.length };
}
export function pacFigures(allocations: { amount_cents: number; transaction_id: string }[], entries: (Entry & { id: string })[], now = new Date()) {
  const dates = new Map(entries.map(e => [e.id, new Date(e.created_at)]));
  const invested = allocations.reduce((s, a) => s + a.amount_cents, 0);
  const series: { m: string; v: number }[] = []; let running = 0;
  const earlier = allocations.filter(a => { const d = dates.get(a.transaction_id); return d && d < new Date(now.getFullYear(), now.getMonth() - 5, 1); }).reduce((s, a) => s + a.amount_cents, 0);
  running = earlier;
  const monthly: number[] = [];
  for (let i = 5; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const added = allocations.filter(a => { const d = dates.get(a.transaction_id); return d && sameMonth(d, start); }).reduce((s, a) => s + a.amount_cents, 0);
    running += added; monthly.push(added);
    series.push({ m: start.toLocaleString('it-IT', { month: 'short' }), v: running / 100 });
  }
  const roundups = entries.filter(e => sameMonth(new Date(e.created_at), now)).reduce((s, e) => s + e.roundup_cents, 0);
  return { invested, series, monthlyAverage: Math.round(monthly.reduce((s, v) => s + v, 0) / 6), roundups };
}
export function project(investedCents: number, monthlyCents: number, monthlyRate: number, years: number) {
  const n = years * 12; const g = Math.pow(1 + monthlyRate, n);
  return Math.round(investedCents * g + monthlyCents * (monthlyRate ? (g - 1) / monthlyRate : n));
}
export const euro = (cents: number) => (cents / 100).toLocaleString('it-IT', { style: 'currency', currency: 'EUR' });
