export function maskSensitive(value: string, hidden: boolean) {
  return hidden ? '****' : value;
}
export function inactivityExpired(lastActivity: number, now: number, minutes: number) {
  return minutes > 0 && now - lastActivity >= minutes * 60_000;
}
export function cloudState(online: boolean, signedIn: boolean, status: string, fetching: boolean) {
  if (!online) return 'offline';
  if (!signedIn) return 'signed-out';
  if (status === 'error') return 'error';
  return status === 'success' && !fetching ? 'synced' : 'pending';
}