import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { maskSensitive } from '@/lib/sincro/controls';

export type Lang = "it" | "en";

const dict = {
  it: {
    greeting: "Ciao! Ecco il tuo riepilogo Sincro",
    home: "Home", shops: "Negozi & Spesa", finance: "PAC & Finanza", health: "Salute", ask: "Chiedi a Sincro",
    eveningTitle: "Assistente Spesa Serale", eveningSub: "Organizza gli acquisti senza girare mille posti",
    savedMonth: "Risparmiato questo mese grazie a Sincro",
    optimized: "Lista spesa ottimizzata", estSaving: "Risparmio stimato",
    findDeals: "Trova Offerte Vicino a Me / Ottimizza Volantini",
    healthTitle: "Salute & Dieta", synced: "Smartwatch sincronizzato",
    kcal: "Calorie Bruciate", steps: "Passi", bpm: "Battito Cardiaco",
    sleep: "Sonno", stress: "Stress", deep: "profondo", light: "leggero",
    advice: "Oggi hai bruciato +500 kcal! Consiglio per la cena: Pollo e verdure — In offerta da Supermercato X a 4,99 €/kg",
    bioTitle: "Profilo Biometrico & Obiettivi", height: "Altezza", weight: "Peso", age: "Età", goal: "Obiettivo",
    goalLose: "Perdita di peso", goalKeep: "Mantenimento", goalGain: "Massa",
    nutritionTitle: "Smart Nutrition & Meal Prep", nutritionSub: "Macro calcolati sul tuo obiettivo, ricette dai volantini vicini",
    protein: "Proteine", carbs: "Carboidrati", fat: "Grassi", kcalTarget: "Target giornaliero",
    recipeTip: "Ricetta suggerita: Salmone e quinoa — ingredienti in offerta da Supermercato B (-18%)",
    budgetTitle: "Budget Mensile Residuo", availableToday: "Disponibile oggi", addExpense: "Aggiungi Spesa / Scansiona Scontrino",
    incomeTitle: "Entrate & Stipendio del Mese", incomeSub: "Scegli come registrare le entrate",
    bankMode: "Open Banking", bankModeSub: "Connessione bancaria automatica",
    manualMode: "Inserimento manuale", manualModeSub: "Massima privacy, nessun collegamento",
    salary: "Stipendio", extra: "Entrate extra", totalIncome: "Totale entrate",
    pacTitle: "Piani di Accumulo (PAC) & Investimenti", risk: "Profilo di Rischio",
    low: "Basso", mid: "Medio", high: "Alto",
    invested: "Totale Investito", monthly: "Versamento Mensile PAC", spare: "Spiccioli da Spesa Accumulati",
    spareSub: "dirottati automaticamente dal risparmio spesa",
    allocation: "Allocazione", of: "di", notifications: "Notifiche", profile: "Profilo",
    etfTitle: "Composizione Dettagliata ETF", yieldLabel: "rend. annuo",
    simTitle: "Simulatore di crescita", simYears: "Orizzonte", projected: "Valore proiettato", years: "anni",
    hideBalances: "Nascondi saldi", showBalances: "Mostra saldi",
    askPlaceholder: "Scrivi o parla con Sincro…",
  },
  en: {
    greeting: "Hi! Here's your Sincro summary",
    home: "Home", shops: "Shops & Groceries", finance: "PAC & Finance", health: "Health", ask: "Ask Sincro",
    eveningTitle: "Evening Grocery Assistant", eveningSub: "Plan your shopping without running around",
    savedMonth: "Saved this month thanks to Sincro",
    optimized: "Optimized shopping list", estSaving: "Estimated saving",
    findDeals: "Find Deals Near Me / Optimize Flyers",
    healthTitle: "Health & Diet", synced: "Smartwatch synced",
    kcal: "Calories Burned", steps: "Steps", bpm: "Heart Rate",
    sleep: "Sleep", stress: "Stress", deep: "deep", light: "light",
    advice: "You burned +500 kcal today! Dinner tip: Chicken & vegetables — On sale at Supermarket X for €4.99/kg",
    bioTitle: "Biometric Profile & Goals", height: "Height", weight: "Weight", age: "Age", goal: "Goal",
    goalLose: "Weight loss", goalKeep: "Maintenance", goalGain: "Muscle gain",
    nutritionTitle: "Smart Nutrition & Meal Prep", nutritionSub: "Macros based on your goal, recipes from nearby store flyers",
    protein: "Protein", carbs: "Carbs", fat: "Fat", kcalTarget: "Daily target",
    recipeTip: "Suggested recipe: Salmon & quinoa — ingredients on sale at Supermarket B (-18%)",
    budgetTitle: "Remaining Monthly Budget", availableToday: "Available today", addExpense: "Add Expense / Scan Receipt",
    incomeTitle: "Income & Monthly Salary", incomeSub: "Choose how to track your income",
    bankMode: "Open Banking", bankModeSub: "Automatic bank connection",
    manualMode: "Manual entry", manualModeSub: "Maximum privacy, no connection",
    salary: "Salary", extra: "Extra income", totalIncome: "Total income",
    pacTitle: "Accumulation Plans (PAC) & Investments", risk: "Risk Profile",
    low: "Low", mid: "Medium", high: "High",
    invested: "Total Invested", monthly: "Monthly PAC Deposit", spare: "Grocery Spare Change Saved",
    spareSub: "automatically redirected from grocery savings",
    allocation: "Allocation", of: "of", notifications: "Notifications", profile: "Profile",
    etfTitle: "Detailed ETF Composition", yieldLabel: "annual yield",
    simTitle: "Growth simulator", simYears: "Horizon", projected: "Projected value", years: "years",
    hideBalances: "Hide balances", showBalances: "Show balances",
    askPlaceholder: "Type or talk to Sincro…",
  },
} as const;

export type Key = keyof (typeof dict)["it"];

const Ctx = createContext<{
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (k: Key) => string;
  hidden: boolean;
  toggleHidden: () => void;
  mask: (s: string) => string;
}>({
  lang: "it", setLang: () => {}, t: (k) => dict.it[k],
  hidden: false, toggleHidden: () => {}, mask: (s) => s,
});

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("it");
  const [hidden, setHidden] = useState(false);
  useEffect(() => { try { setHidden(sessionStorage.getItem('sincro-private') === 'true'); } catch { /* Storage may be unavailable. */ } }, []);
  return (
    <Ctx.Provider
      value={{
        lang,
        setLang,
        t: (k) => dict[lang][k],
        hidden,
        toggleHidden: () => setHidden((h) => { try { sessionStorage.setItem('sincro-private', String(!h)); } catch { /* Keep the instant toggle working. */ } return !h; }),
        mask: (s: string) => maskSensitive(s, hidden),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export const useI18n = () => useContext(Ctx);
