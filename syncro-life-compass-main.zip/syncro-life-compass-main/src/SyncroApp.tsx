import { useEffect, useState } from 'react';
import { Link, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAccount, useFoundation } from '@/lib/sincro/account';
import { budgetFigures, euro } from '@/lib/sincro/dashboard';
import { useI18n } from '@/lib/i18n';

const copy = {
  it: {
    monthly: 'Disponibilità mensile', today: 'Disponibile oggi', setBudget: 'Imposta il tuo budget in Finanza',
    updated: 'Aggiornato in tempo reale', theme: 'Tema', themes: ['Scuro', 'Medio', 'Chiaro'] as const,
    add: 'Aggiungi', ai: 'Spesa IA', stats: 'Statistiche', more: 'Altro',
    gpsOff: 'GPS non attivo', locating: 'Localizzazione…',
  },
  en: {
    monthly: 'Monthly availability', today: 'Available today', setBudget: 'Set your budget in Finance',
    updated: 'Updated in real time', theme: 'Theme', themes: ['Dark', 'Medium', 'Light'] as const,
    add: 'Add', ai: 'AI shopping', stats: 'Statistics', more: 'More',
    gpsOff: 'GPS off', locating: 'Locating…',
  },
} as const;

export default function SyncroApp() {
  // Tema locale del pannello (Scuro, Medio, Chiaro)
  const [theme, setTheme] = useState<'dark' | 'medium' | 'light'>('dark');
  const navigate = useNavigate();
  const { lang, mask } = useI18n();
  const t = copy[lang === 'it' ? 'it' : 'en'];
  const { user } = useAccount();
  const data = useFoundation();
  const client = useQueryClient();

  // Disponibilità calcolata dai dati reali: budget residuo del mese e quota giornaliera.
  const budget = data.profile?.monthly_budget_cents ?? 0;
  const b = budgetFigures(data.entries, budget);

  // Aggiorna la cifra appena cambiano spese, budget o profilo.
  useEffect(() => {
    if (!user) return;
    const refresh = () => { void client.invalidateQueries({ queryKey: ['foundation', user.id] }); };
    const channel = supabase.channel(`syncro-home-${user.id}`);
    for (const table of ['transactions', 'goal_allocations', 'profiles']) channel.on('postgres_changes', { event: '*', schema: 'public', table }, refresh);
    channel.subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [client, user]);

  // GPS reale su richiesta, nessuna città inventata.
  const [gps, setGps] = useState<'idle' | 'loading' | 'ok' | 'denied'>('idle');
  const [coords, setCoords] = useState('');
  const locate = () => {
    if (!navigator.geolocation) return setGps('denied');
    setGps('loading');
    navigator.geolocation.getCurrentPosition(
      p => { setCoords(`${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}`); setGps('ok'); },
      () => setGps('denied'),
      { timeout: 8000 },
    );
  };
  const gpsLabel = gps === 'ok' ? mask(coords) : gps === 'loading' ? t.locating : gps === 'denied' ? t.gpsOff : 'GPS';

  const themeClasses = {
    dark: 'bg-slate-950 text-slate-100 border-slate-800',
    medium: 'bg-slate-800 text-slate-100 border-slate-700',
    light: 'bg-slate-50 text-slate-900 border-slate-200'
  }[theme];

  return (
    <div className={`mx-auto flex min-h-[60vh] max-w-md flex-col justify-between gap-6 rounded-3xl border p-4 pb-8 transition-colors duration-200 ${themeClasses}`}>

      {/* 1. Header minimalista con logo centrale e badge GPS */}
      <header className="flex items-center justify-between py-3 border-b border-slate-800/40">
        <div className="w-8"></div>

        {/* Logo vettoriale infinito al centro */}
        <div className="flex items-center gap-1.5 font-bold tracking-wider">
          <span className="text-blue-500 text-lg">∞</span>
          <span className="text-sm">SYNCRO</span>
        </div>

        {/* Badge GPS reale, tocca per localizzare */}
        <button
          type="button"
          onClick={locate}
          title={gps === 'denied' ? t.gpsOff : 'GPS'}
          className="flex items-center gap-1 bg-slate-900/80 border border-slate-800 px-2.5 py-1 rounded-full text-[11px] text-slate-300"
        >
          <span className={`w-1.5 h-1.5 rounded-full ${gps === 'ok' ? 'bg-emerald-500' : 'bg-slate-500'} ${gps === 'loading' ? 'animate-pulse' : ''}`}></span>
          <span className="max-w-28 truncate">{gpsLabel}</span>
        </button>
      </header>

      {/* 2. Disponibilità reale dal database */}
      <main className="flex flex-col gap-6 py-2">
        <div className="flex flex-col items-center text-center p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60 backdrop-blur-md">
          <span className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">
            {t.monthly}
          </span>
          {budget === 0
            ? <Link to="/finanza" className="text-sm font-semibold text-blue-400 underline underline-offset-4">{t.setBudget}</Link>
            : <div className="text-4xl font-bold tracking-tight text-blue-400 tabular">{mask(euro(b.remaining))}</div>}
          <span className="text-[11px] text-emerald-400 mt-2">
            {t.updated}{budget > 0 ? ` • ${t.today} ${mask(euro(b.daily))}` : ''}
          </span>
        </div>

        {/* 3. Azioni rapide collegate alle sezioni reali */}
        <div className="grid grid-cols-4 gap-2 px-2">
          <button
            onClick={() => navigate({ to: '/spese' })}
            className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs transition-all"
          >
            <div className="w-10 h-10 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold text-base">+</div>
            <span>{t.add}</span>
          </button>

          <button
            onClick={() => window.dispatchEvent(new Event('sincro:open-chat'))}
            className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs transition-all"
          >
            <div className="w-10 h-10 rounded-full bg-purple-600/20 text-purple-400 flex items-center justify-center text-sm">🤖</div>
            <span>{t.ai}</span>
          </button>

          <button
            onClick={() => navigate({ to: '/finanza' })}
            className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs transition-all"
          >
            <div className="w-10 h-10 rounded-full bg-emerald-600/20 text-emerald-400 flex items-center justify-center text-sm">📊</div>
            <span>{t.stats}</span>
          </button>

          <button
            onClick={() => navigate({ to: '/profilo' })}
            className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs transition-all"
          >
            <div className="w-10 h-10 rounded-full bg-amber-600/20 text-amber-400 flex items-center justify-center text-sm">⚙️</div>
            <span>{t.more}</span>
          </button>
        </div>

        {/* 4. Selettore tema del pannello */}
        <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60 flex items-center justify-between text-xs">
          <span className="text-slate-400">{t.theme}:</span>
          <div className="flex gap-1.5">
            {(['dark', 'medium', 'light'] as const).map((key, i) => (
              <button
                key={key}
                onClick={() => setTheme(key)}
                className={`px-2.5 py-1 rounded-md ${theme === key ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'}`}
              >{t.themes[i]}</button>
            ))}
          </div>
        </div>
      </main>

      {/* Footer minimale */}
      <footer className="text-center py-2 text-[10px] text-slate-500">
        SYNCRO Engine
      </footer>
    </div>
  );
}
