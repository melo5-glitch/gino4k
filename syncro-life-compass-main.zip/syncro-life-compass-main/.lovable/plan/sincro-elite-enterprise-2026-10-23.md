# Sincro Elite & Enterprise

## Risultato
Evolvere l’app esistente senza perdere logo, moduli, selettore IT/EN, privacy, simulatore PAC o barra inferiore. Dark mode predefinita **#0f1115**, accenti verde acqua/smeraldo e tema chiaro opzionale.

Profilo completo e nome reale salvati nell’account. **Una sola conversazione con Sincro, conservata nell’account.** Limite personalizzato alle richieste IA, accettato dall’utente e verificato con test.

## Ordine di realizzazione

### 1. Account e fondamenta sicure
Attivare Lovable Cloud per dati, account e sincronizzazione. Registrazione, accesso con email/password, conferma email, recupero password e pagina per impostarne una nuova; profilo modificabile, CAP/zona, preferenze e consensi registrati con versione e data. Separare rigorosamente dati reali e dimostrativi. Configurare isolamento dei dati e appartenenza alla famiglia.
**Punti:** 2, 16, 27, 31, 35, 36, 37, 41.

### 2. Esperienza visiva e navigazione
Animazione vettoriale breve dell’infinito, senza ritardare il caricamento dei dati e con movimento ridotto rispettato. Saluto secondo l’ora del dispositivo e il nome nell’account. Menu laterale accessibile, occhio accanto al menu, indicatore che distingue connessione e sincronizzazione reale, campanella con Inbox. Home più ariosa, sezioni collassabili e pagine spesa/finanza ordinate. Tour iniziale di tre schermate.
**Punti:** 1, 2, 3, 4, 5, 6, 7, 23, 30, 34, 38.

### 3. Spesa e contabilità affidabile
Liste e scorte modificabili, preferiti e ricorrenti, conferma degli acquisti e registro transazioni filtrabile. Un acquisto produce una sola registrazione contabile e aggiorna risparmio, PAC e obiettivi nella stessa operazione; il semplice inserimento in lista non genera denaro. Distinguere sconti, arrotondamenti e sprechi evitati documentati, senza sommarli due volte. Budget e barre derivati dai movimenti reali. Obiettivi, modalità emergenza con revisione del carrello, report PDF/CSV non certificati e simulatore proiettivo con ipotesi visibili.
**Punti:** 7, 10, 17, 19, 20, 21, 23, 24, 26, 32, 42, 43.

### 4. Assistente intelligente
Sostituire le risposte preimpostate con IA reale: conversazione unica salvata, risposta progressiva, annullamento e gestione degli errori. Suggerimenti da dati dell’account, ricette basate su scadenze e ingredienti, scansione scontrini con revisione prima di registrare movimenti, categorizzazione e report mensile/annuale. Regole deterministiche rivalutate all’apertura e a ogni variazione rilevante; l’IA non effettua acquisti né trasferimenti di denaro senza conferma. Controllo personalizzato server-side delle richieste e protezione dei costi.
**Punti:** 8, 9, 11, 12, 17, 25, 33, 34, 42.

### 5. Famiglia e avvisi
Creazione nucleo, inviti, liste e scorte condivise con aggiornamenti in tempo reale. Permessi distinti: lettura, gestione spesa, gestione fondi. Inbox persistente e regole di cortesia, anche per intervalli che attraversano la mezzanotte. Predisporre invio push da eventi verificati, evitando duplicati e rispettando consensi e silenzio.
**Punti:** 9, 14, 15, 23, 44.

### 6. Offline e chiusura sicura
Consultazione offline di liste/scorte e coda delle modifiche con stato visibile. Risoluzione per timestamp per i dati non finanziari; per gli acquisti, operazioni identificabili e deduplicate, mai sovrascrittura del saldo. Cache privata separata per account e cancellata all’uscita. Blocco facoltativo, pausa in background e timeout configurabile; lo sblocco richiede verifica reale, non una semplice schermata. Preferenze e obiettivi ritornano accedendo da un nuovo dispositivo.
**Punti:** 13, 18, 22, 41, 45.

### 7. Fiducia e completezza
Privacy, disclaimer, FAQ, assistenza e “The Sincro Vision” come pagine dedicate. Documenti legali indicati come bozze finché validati; nessuna promessa di conformità certificata. Telemetria minimizzata senza dati sanitari/finanziari nei log. Controlli su contrasto, tastiera, lettori di schermo, testi IT/EN e schermi piccoli.
**Punti:** 28, 29, 34, 35, 37, 38, 39, 40.

## Dipendenze e limiti espliciti
- **Push:** la Inbox funziona con Cloud; notifiche in background richiedono configurazione del servizio di messaggistica e permesso sul dispositivo. Supporto web diverso per browser, con installazione richiesta su iOS.
- **Face ID/impronta:** sul web si possono usare passkey dove supportate, con verifica server; biometria nativa completa richiede un’app mobile dedicata, fuori dallo stack web attuale. Non simulare sicurezza nativa.
- **Banca, smartwatch, offerte locali, consegne e Amazon:** mantenere quanto esiste e segnalarlo come dimostrativo finché sono disponibili partner, cataloghi e collegamenti autorizzati. Il CAP non inventa disponibilità o prezzi reali.
- **Offline:** disponibile nell’app pubblicata, non nell’anteprima dell’editor. Dati sensibili non conservati in chiaro senza una scelta di sicurezza adeguata; non promettere protezione su un dispositivo già compromesso.
- **Backup:** accesso da nuovo dispositivo ripristina i dati salvati; backup automatici e recupero temporale vanno verificati rispetto al servizio disponibile, non dichiarati implicitamente.
- **Privacy e certificazioni:** RLS isola l’accesso, non cifra le singole righe; PDF esportati non sono documenti certificati. Nessuna garanzia di latenza al microsecondo, assenza assoluta di errori o standard bancari non verificati.
- **Assistenza:** il modulo deve avere un destinatario reale prima di poter inviare richieste; nessun contatto inventato.

## Dettagli tecnici
- TanStack Start esistente, moduli separati per dominio e funzioni server autenticate; nessuna riscrittura in un altro framework o microservizi artificiali.
- Cloud PostgreSQL: profili collegati agli account, membership separate dai profili, permessi e RLS, grant espliciti e test di isolamento.
- Importi in centesimi interi; procedura SQL transazionale, identificatore univoco dell’operazione, vincoli e controlli server. Conferma UI solo dopo esito verificato; aggiornamenti immediati riconciliati con il risultato.
- Lovable AI Gateway sul server, cronologia completa, input validati, limiti persistenti atomici. Lavori automatici limitati, deduplicati e sospendibili, webhook autenticati e nessuna inferenza continua incontrollata.
- IndexedDB per cache/coda per account; timestamp assegnati/verificati dal server. PWA con service worker generato e disabilitato in tutte le anteprime.
- Test concreti per privacy dei dati, permessi famiglia, idempotenza, arrotondamenti, ore di silenzio, soglie, timeout e sincronizzazione; metadata specifici per ogni pagina.

## Verifica e consegna
Realizzare e verificare ogni gruppo senza dichiarare tutti i 45 punti conclusi prima dei controlli. Provare con un account reale: profilo → lista → acquisto → transazione → risparmio/obiettivo → ricaricamento; poi duplicato e riconnessione. Verificare separatamente famiglia, chat e recupero credenziali. Eseguire test mirati, controlli di sicurezza e verifica visiva desktop/mobile. Lasciare nel riepilogo solo le dipendenze esterne realmente mancanti.